(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	/********* get comapanies ************/ 
	jQuery(document).ready(function($) 
	{
	
		/************* get company id ******************/ 
		$('#companies').on('change', function()
		{
			var get_company_name = $(this).val();

			$.ajax({
					url: ajax_object.ajaxurl,	
					method: 'POST',
					data: {
							action: 'get_facility',
							'get_company_name': get_company_name
						  },
					success: function(response) 
					{
						var res = JSON.parse(response);

						if(res.success == true)
						{
							var facility_data = res.data;
							var html = '';
							html += '<option value="0">Select Facility</option>';
							$.each(facility_data, function(index, facilityData) 
							{
								html += '<option value="'+facilityData+'">'+facilityData+'</option>';
							});

							$('#facility').html(html);	
							$('#myModal #get_emp_company').val(get_company_name);					
						}

					},
					error: function(xhr, status, error) 
					{
						console.log(error);
					}
			       });
		})

		/************* get company id ******************/ 
		$('#facility').on('change', function()
		{
			var get_facility_name = $(this).val();

			$.ajax({
					url: ajax_object.ajaxurl,	
					method: 'POST',
					data: {
							action: 'get_employees',
							'get_facility_name': get_facility_name
						  },
					success: function(response) 
					{
						// Handle the response data
						var res = JSON.parse(response);

						if(res.success == true)
						{
							var emp_data = res.data;
							var html = '';
							html += '<option value="0">Select Name</option>';
							$.each(emp_data, function(index, employee_data) 
							{
								html += '<option value="'+employee_data.ID+'">'+employee_data.Name+'</option>';
							});

							$('#employee').html(html);
							$('#myModal #get_emp_facility').val(get_facility_name);		
											
						}

					},
					error: function(xhr, status, error) 
					{
						// Handle the error
						console.log(error);
					}
			       });
		})

		/************* show enter emp id modal ********************/ 
		$('#employee').on('change', function()
		{
			var get_emp_verify_id= $(this).val();
			$('#myModal #get_emp_verify_id').val(get_emp_verify_id);	
			jQuery('#myModal').addClass('shown');
			jQuery('#myModal').show(100);
		})

		/***************** get employee id ********************/ 
		$('#save_id').on('click', function()
		{
			var get_emp_id = $('#get_emp_id').val();
			var get_emp_verify_id = $('#get_emp_verify_id').val();
			var get_emp_company = $('#get_emp_company').val();
			var get_emp_facility = $('#get_emp_facility').val();


			$.ajax({
						url: ajax_object.ajaxurl,	
						method: 'POST',
						datatype : 'json',
						data: {
								action: 'match_emp_data',
								'get_emp_id': get_emp_id,
								'get_emp_facility': get_emp_facility,
								'get_emp_verify_id': get_emp_verify_id
							  },
						success: function(response) 
						{
							var data1 = JSON.parse(response)
							
							if(data1.status)
							{
								jQuery('#myModal').removeClass('shown');
								jQuery('#myModal').hide(100);

								Swal.fire({
									title: "Thank You",
									text: data1.name+" you are successfully Check In ",
									icon: "success",
									buttons: false,
									timer: 3000 
								}).then(function() 
								{
									location.reload();
								},200);
							}
							else
							{
								Swal.fire({
									title: "Check-In Failed",
									text: "Unable To match "+data1.name+" with ID "+data1.data+" . Please Enter correct details",
									icon: "error",
									buttons: false,
									timer: 3000 
								}).then(function() 
								{
									//location.reload();
								},200);
							}
						},
						error: function(xhr, status, error) 
						{
							console.log(error);
						}
			       })
		});

		$("#myModal .close").on('click', function(){
			$('#myModal').removeClass('shown');
			$('#myModal').hide(100);
		});
	});
	

})( jQuery );


