<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://opaquesmokeschool.com/
 * @since      1.0.0
 *
 * @package    Wp_Checkon
 * @subpackage Wp_Checkon/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wp_Checkon
 * @subpackage Wp_Checkon/includes
 * @author     Trions <testingemailer1212@gmail.com>
 */
class Wp_Checkon_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
