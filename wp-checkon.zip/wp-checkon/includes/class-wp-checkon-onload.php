<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://http://localhost/googlesheet/
 * @since      1.0.0
 *
 * @package    Google_sheet
 * @subpackage Google_sheet/admin/partials
 */
?>

<?php 

function wp_checkon_shortcode() {
    ob_start(); // Start output buffering

    global $wpdb;
    $table_name = 'ecos1';

    $query = "SELECT DISTINCT Company FROM $table_name ORDER BY Company ASC";
    $results = $wpdb->get_results($query);

?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<!--**************** get all companies*************** -->
<div class="wp-checkon-main">
    <div class ="main-div">
        <label>Select Company</label>
        <select id="companies">
        <option value="0">Select Company</option>
            <?php
            // $query = "SELECT DISTINCT emp_company_name, company_id  FROM $table_name";
            $query = "SELECT DISTINCT Company FROM $table_name ORDER BY Company ASC";
            $results = $wpdb->get_results($query);


            $uniqueCompanyNames = array();

            foreach($results as $key => $data)
            {
                if(!in_array($data->Company, $uniqueCompanyNames)) 
                {
                    $uniqueCompanyNames[] = $data->Company;
                ?>
                    <option value="<?php echo $data->Company ?>"><?php echo $data->Company; ?></option>
                <?php }
            }
            ?>
        </select>
    </div>

    <!--*************** get employee data ************-->
    <div class ="main-facility-div">
        <label>Select Facility</label>
        <select id="facility">
            <option value="0">Select Facility</option>
        </select>
    </div>

    <!--*************** get employee data ************-->
    <div class ="main-emp-div">
        <label>Select Name</label>
        <select id="employee">
            <option value="0">Select Name</option>
        </select>
    </div>

    <div class="container model-constainer">
        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    <h4 class="modal-title">Check In</h4>
                    </div>
                    <div class="modal-body">
                        <label>Enter Your Id :</label>
                        <input type ="text" name="emp_id" id="get_emp_id">
                        <input type ="hidden" name="get_emp_verify_id" id="get_emp_verify_id" value="">
                        <input type ="hidden" name="get_emp_company" id="get_emp_company" value="">
                        <input type ="hidden" name="get_emp_facility" id="get_emp_facility" value="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="save_id">Check In</button>
                        <button type="button" class="btn btn-default close" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>	
    </div>
</div>
<?php

return ob_get_clean(); // Return the output buffer contents and clear the buffer
}
add_shortcode('wp_checkon', 'wp_checkon_shortcode');


/*************** get all facility from company name ***************/ 

add_action('wp_ajax_nopriv_get_facility', 'get_facility');
add_action('wp_ajax_get_facility', 'get_facility');

function get_facility()
{
   if(isset($_POST['get_company_name']))
   {
		$get_company_name = $_POST['get_company_name'];
   }
   /************ get employees******************/   
   global $wpdb;

   	$table_name = 'ecos1';

   	$query = "SELECT DISTINCT * FROM $table_name Where company = '".$get_company_name."' ORDER BY Facility ASC";
   	$results = $wpdb->get_results($query);

    $uniqueCompanyNames = array();

    foreach($results as $key => $data)
    {
        if(!in_array($data->Facility, $uniqueCompanyNames)) 
        {
            $uniqueCompanyNames[] = $data->Facility;
        }
    }

	if($uniqueCompanyNames)
	{  
		$response = array('success' => true, 'data' => $uniqueCompanyNames );
	}

	else
	{
		$response = array('success' => true, 'data' => $uniqueCompanyNames );
	}	
	echo json_encode($response);
	die();

}


/*************** get all facility from company name ***************/ 

add_action('wp_ajax_nopriv_get_employees', 'get_employees');
add_action('wp_ajax_get_employees', 'get_employees');

function get_employees()
{
   if(isset($_POST['get_facility_name']))
   {
		$get_facility_name = $_POST['get_facility_name'];
   }
   /************ get employees******************/   
   global $wpdb;

   	$table_name = 'ecos1';

   	$query = "SELECT DISTINCT * FROM $table_name Where Facility = '".$get_facility_name."'";
   	$results = $wpdb->get_results($query);

    $uniqueCompanyNames = array();

    foreach($results as $key => $data)
    {
        $my_array = array(
                            'ID' => $data->ID,
                            'Name' => $data->Name,
        );
        if(!in_array($my_array, $uniqueCompanyNames)) 
        {
            $uniqueCompanyNames[] = $my_array;
        }
    }

	if($uniqueCompanyNames)
	{  
		$response = array('success' => true, 'data' => $uniqueCompanyNames );
	}

	else
	{
		$response = array('success' => true, 'data' => $uniqueCompanyNames );
	}	
	echo json_encode($response);
	die();

}


/************** match data in the database ****************/ 
add_action('wp_ajax_nopriv_match_emp_data', 'match_emp_data');
add_action('wp_ajax_match_emp_data',  'match_emp_data');

function match_emp_data()
{
	if(isset($_POST['get_emp_id']))
	{
        global $wpdb;
		$table_name = 'ecos1';
		$get_emp_id = $_POST['get_emp_id'];
		$get_emp_facility = $_POST['get_emp_facility'];
		$get_emp_verify_id = $_POST['get_emp_verify_id'];
        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $get_emp_verify_id);
        $result = $wpdb->get_row($query);
        $name = $result->Name;

        if($get_emp_id == $get_emp_verify_id){
            // Check if the employee ID exists in the database
            $query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d AND facility = %s", $get_emp_id, $get_emp_facility);
            $result = $wpdb->get_var($query);
            
            // Update the "emp_data_exist" column based on the existence of the employee ID
            if($result) 
            {

                $current_date_time = date('Y-m-d H:i:s');
                $timestampInMilliseconds = strtotime($current_date_time);

                $wpdb->update($table_name, array('updated' => $timestampInMilliseconds ), array('ID' => $get_emp_id));
                $response = array('status' => true, 'data' => $get_emp_id, 'name' => $name);
                echo json_encode($response);
                wp_die();
            }
        }else{
            $response = array('status' => false, 'data' => $get_emp_id,  'name' => $name);
            echo json_encode($response);
            wp_die();
        } 
	}
}



