<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://opaquesmokeschool.com/
 * @since      1.0.0
 *
 * @package    Wp_Checkon
 * @subpackage Wp_Checkon/admin/partials
 */
?>

<div class="card1">
    <div class="container ">
        <div class="row inner-card">
            <div class="col-lg-8 col-md-8 col-sm-12 card-content">            
                <?php 
                $shortcode = "[wp_checkon]";
                echo "<h3>Shortcode</h3>";
                echo "<p>".$shortcode."</p>";
                ?>
            </div>
        </div>
    </div>
</div>