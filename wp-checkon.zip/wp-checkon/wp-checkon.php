<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://https://opaquesmokeschool.com/
 * @since             1.0.0
 * @package           Wp_Checkon
 *
 * @wordpress-plugin
 * Plugin Name:       WP CheckOn
 * Plugin URI:        https://https://opaquesmokeschool.com/
 * Description:       Plugin for check students sign in on website for courses
 * Version:           1.0.0
 * Author:            Trions
 * Author URI:        https://https://opaquesmokeschool.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wp-checkon
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WP_CHECKON_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wp-checkon-activator.php
 */
function activate_wp_checkon() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-checkon-activator.php';
	Wp_Checkon_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wp-checkon-deactivator.php
 */
function deactivate_wp_checkon() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-checkon-deactivator.php';
	Wp_Checkon_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wp_checkon' );
register_deactivation_hook( __FILE__, 'deactivate_wp_checkon' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wp-checkon.php';

require plugin_dir_path( __FILE__ ) . 'includes/class-wp-checkon-onload.php';

/**** craete custom post type ******/ 
add_action('admin_menu', 'wp_checkon_cpt');

function wp_checkon_cpt() 
{
    add_menu_page(
        'WP CheckOn',      
        'WP CheckOn',       
        'manage_options',    
        'wp_checkon',        
        'wp_checkon_admin_page', 
        'dashicons-media-spreadsheet',
		25   
    );
}

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

function wp_checkon_admin_page() 
{
   include plugin_dir_path(__FILE__) . '/admin/partials/wp-checkon-admin-display.php';
}


/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wp_checkon() {

	$plugin = new Wp_Checkon();
	$plugin->run();

}
run_wp_checkon();
