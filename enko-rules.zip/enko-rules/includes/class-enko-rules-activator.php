<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://enkoeducation.com/
 * @since      1.0.0
 *
 * @package    Enko_Rules
 * @subpackage Enko_Rules/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Enko_Rules
 * @subpackage Enko_Rules/includes
 * @author     Trions <testingemailer1212@gmail.com>
 */
class Enko_Rules_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		global $wpdb;
		$menu_table_name = $wpdb->prefix . 'trion_menu_rules_meta';
		$role_table_name = $wpdb->prefix . 'trion_role_rules_meta';

		// // // Delete the table
		// // $query = "DROP TABLE IF EXISTS {$menu_table_name}";
		// // $wpdb->query($query);

		// Create the tables if it doesn't exist

		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE IF NOT EXISTS $menu_table_name (
			id INT(11) NOT NULL AUTO_INCREMENT,
			menu_id TEXT NOT NULL,
			role_id TEXT NOT NULL,
			footer_1_menu_id TEXT NULL,
			footer_2_menu_id TEXT NULL,
			footer_3_menu_id TEXT NULL,
			menu_role TEXT NULL,
			PRIMARY KEY (id)
		) $charset_collate;";
		$wpdb->query($sql);

		$sql1 = "CREATE TABLE IF NOT EXISTS $role_table_name (
			id INT(11) NOT NULL AUTO_INCREMENT,
			role_name TEXT NOT NULL,
			role_description TEXT NOT NULL,
			PRIMARY KEY (id)
		) $charset_collate;";
		$wpdb->query($sql1);
	}

}
