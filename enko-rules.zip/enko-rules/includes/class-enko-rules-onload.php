<?php
/*************** roles section **********************/
add_action('wp_ajax_restaurant_roles_ajax', 'restaurant_roles_callback');
add_action('wp_ajax_nopriv_restaurant_roles_ajax', 'restaurant_roles_callback');

function restaurant_roles_callback()
{
    global $wpdb; 

    if(isset($_POST['role_name']))
    {
        $role_name = $_POST['role_name'];
        $role_description = $_POST['role_description'];

        $role_table_name = $wpdb->prefix . 'trion_role_rules_meta';

        // Insert a new row
        $result = $wpdb->insert($role_table_name, array(
                'role_name' => $role_name,
                'role_description' => $role_description,
            ),
            array('%s', '%s')
        );

        if ($result === false) 
        {
            $response = array('success' => false , 'error' => $wpdb->last_error);
        } 
        else 
        {
            $response = array('success' => true);
        }
    }
    else
    {
        $response = array('success' => false,  'error' => $wpdb->last_error);
    }

    echo json_encode($response);
    wp_die();
}

/*************** dishes section **********************/
add_action('wp_ajax_get_role_form', 'get_role_form_callback');
add_action('wp_ajax_nopriv_get_role_form', 'get_role_form_callback');

function get_role_form_callback()
{

    global $wpdb;
    $table_name = $wpdb->prefix . 'trion_role_rules_meta';
    $res_roles = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    $html = '';
    if($res_roles){

        if (count($res_roles) > 0) 
        {
            $html .= '<div class="role-buttons-outer">';
            foreach ($res_roles as $res_roles_data) 
            {
                $html .= '<div class="role_bttn"><button class="Rolebutton button--role button--round-s button--text-thick button--border-thin" data-id="'.$res_roles_data['id'].'" data-text="'.$res_roles_data['role_name'].'">'.$res_roles_data['role_name'].'</button></div>';
            }
            $html .= '</div>';
            $response = array("success" => true, "data" => $html);
        }
        else
        {
            $response = array("success" => false, "data" => "No");
            echo json_encode($response);
            die;
        }
    }else{
        $response = array("success" => false, "message" => "No");
        echo json_encode($response);
        die;
    }
    echo json_encode($response);
    die;
}


/*************** dishes section **********************/
add_action('wp_ajax_set_cookie_on_Role', 'set_cookie_on_Role_callback');
add_action('wp_ajax_nopriv_set_cookie_on_Role', 'set_cookie_on_Role_callback');

function set_cookie_on_Role_callback()
{

    if ($_POST['roleId']) {
        $role_id = $_POST['roleId'];
        $expiration = time() + 86400 * 10;
        setcookie('role_ASSIGN_cokkie', $role_id, $expiration);
    }

    if ($_POST['roleId']) {
        $role_id = $_POST['roleId'];
        $expiration = time() + 86400 * 10;
        setcookie('role_ASSIGN_cokkie', $role_id, $expiration);
    }

    if ($_COOKIE['role_ASSIGN_cokkie']) {
        $data = array();
        $data['role_ASSIGN_cokkie'] = $_COOKIE['role_ASSIGN_cokkie'];
        $data['expiration_date'] = date('d M, Y', $_SERVER['REQUEST_TIME'] + 86400 * 10);
        $response = array("success" => true, "data" => $data);
    }else{
        $response = array("success" => false, "message" => "No");
    }
    echo json_encode($response);
    die;
}


function getCookieData() {
    $response = '';

    if ($_COOKIE['role_ASSIGN_cokkie']) {
        echo $_COOKIE['role_ASSIGN_cokkie'];
        $data = array();
        $data['role_ASSIGN_cokkie'] = $_COOKIE['role_ASSIGN_cokkie'];
        $data['expiration_date'] = date('d M, Y', $_SERVER['REQUEST_TIME'] + 86400 * 10);
        $response = array("success" => true, "data" => $data);
    }

    return $response;
}


