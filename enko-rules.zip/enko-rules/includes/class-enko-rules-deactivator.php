<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://enkoeducation.com/
 * @since      1.0.0
 *
 * @package    Enko_Rules
 * @subpackage Enko_Rules/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Enko_Rules
 * @subpackage Enko_Rules/includes
 * @author     Trions <testingemailer1212@gmail.com>
 */
class Enko_Rules_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
