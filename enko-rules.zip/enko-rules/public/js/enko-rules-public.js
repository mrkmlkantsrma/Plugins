(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	jQuery(document).ready(function() {
		jQuery('.cokieeButton').on('click', function(){
			jQuery.ajax({ 
				data: {action: 'get_role_form'},
				type: 'post',
				datatype: 'json',
				url: ajax_object.ajaxurl,
				success: function(response) {
					var res = JSON.parse(response);
					if(res.success){
						jQuery('#roleCokkieModal').remove();
						var model_html = '<div class="modal-popup overlay light" id="roleCokkieModal"><a class="cancel" href="#"></a><div class="rolemodel popup"> <div class="headerRoleOption mk-padding-wrapper wpb_row"><div class="role-image-wrapper "><img src="https://enkoeducation.com/wp-content/uploads/2018/04/enko-modern-logo.png" alt="dialog featured image"></div><div class="roleModal-header-body"><h4>Get In Enko School With Your Personalization!</h4><p><strong>Please choose your role in our school from These. </br> Discover whether you are complying with privacy laws relevant to our school 🗒️</strong></p></div></div><div class="content Roleoptions"></div></div></div>';
						jQuery('body').append(model_html);
						jQuery('#roleCokkieModal .Roleoptions').html('');
						jQuery('#roleCokkieModal .Roleoptions').html(res.data);
					}
				}
			});
		});


		jQuery(document).on("click", function(event) {
			if (jQuery(event.target).hasClass('Rolebutton')) {
				var dataId = jQuery(event.target).data('id');
				var dataText = jQuery(event.target).data('text');
				console.log(dataId);
				console.log(dataText);
				console.log(event.target);
		
				var clickCount = jQuery(event.target).data('clickCount') || 0;
				clickCount++;
		
				jQuery(event.target).data('clickCount', clickCount);
		
				jQuery.ajax({ 
					data: {action: 'set_cookie_on_Role', roleId:dataId, roleName: dataText},
					type: 'post',
					datatype: 'json',
					url: ajax_object.ajaxurl,
					success: function(response) {
						var res = JSON.parse(response);
						jQuery(event.target).click();
						console.log(clickCount);
						if (clickCount == 1) {
							jQuery('.spinner-wrapper').remove();
							jQuery('body').append('<div class="spinner-wrapper"><div class="spinner"></div></div>');
							location.reload();
							setTimeout(() => {
								jQuery('#roleCokkieModal').fadeOut(200);
								setTimeout(() => {
									jQuery('.spinner-wrapper').remove(200);
									location.reload();
								}, 1000);
							}, 1000);
						}
					}
				});
			}
		});
		

		// jQuery(document).on("click", function(event) {
		// 	if (jQuery(event.target).hasClass('Rolebutton')) {
		// 	  var dataId = jQuery(event.target).data('id');
		// 	  var dataText = jQuery(event.target).data('text');
		// 	  console.log(dataId);
		// 	  console.log(dataText);
		// 	  console.log(event.target);
		// 	  	jQuery.ajax({ 
		// 			data: {action: 'set_cookie_on_Role', roleId:dataId, roleName: dataText},
		// 			type: 'post',
		// 			datatype: 'json',
		// 			url: ajax_object.ajaxurl,
		// 			success: function(response) {
		// 				var res = JSON.parse(response);
		// 				jQuery(event).click();
		// 				jQuery('.spinner-wrapper').remove();
		// 				jQuery('body').append('<div class="spinner-wrapper"><div class="spinner"></div></div>');
		// 				setTimeout(() => {
		// 					location.reload();
		// 					jQuery('#roleCokkieModal').fadeOut();
		// 					setTimeout(() => {
		// 						location.reload();
		// 						jQuery('.spinner-wrapper').remove();
		// 					}, 2000);
		// 				}, 3000);
		// 			}
		// 		});
		// 	}
		// });

	});

})( jQuery );
