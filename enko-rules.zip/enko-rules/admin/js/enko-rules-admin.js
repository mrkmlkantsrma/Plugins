(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */


	/************** call ajax for role sec *******************/ 
	$(document).ready(function() 
	{
		$('#rest_roles').submit(function(event) 
		{
			event.preventDefault();
			var role_name = $('.role_name').val();
			var role_description = $('.roles_des').val();
			if(role_name.length > 0 ){
				$.ajax({
					url: ajax_object.ajaxurl,
					method: 'POST',
					dataType: 'json',
					data: {
							action: 'restaurant_roles_ajax',
							'role_name' : role_name,
							'role_description' : role_description,
						},
					success: function(response) 
					{
						console.log(response);

					if(response.success === true)
					{
							Swal.fire({
								title: "Success",
								text: "Role added sccessfully",
								icon: "success",
								buttons: false,
								timer: 2000 
							}).then(function() 
							{
								location.reload();
							},200);
					}
					else
					{
							Swal.fire({
								title: "Error",
								text: "Unable to add Role",
								icon: "error",
								buttons: false,
								timer: 2000 
							}).then(function() 
							{
								location.reload();
							},200);
					}	

					},
					error: function(xhr, status, error) 
					{
						console.log(xhr.responseText);
						Swal.fire({
							title: "Error",
							text: "An error occurred while processing the request",
							icon: "error",
							buttons: false,
							timer: 2000 
						}).then(function() 
						{
							location.reload();
						},200);
					}
					
				});
			}else{
				Swal.fire({
					title: "Error",
					text: "Enter Role ",
					icon: "error",
					buttons: false,
					timer: 2000 
				});
			}
		});
	});

	/******** update role sec data ***********/ 
	jQuery(function() 
	{
		jQuery('#cancel_update_role_btn').on('click', function() {
			jQuery('.update-role-sec').toggle(500);
			jQuery('.add-new-role-sec').toggle(500);
			history.pushState({}, document.title, window.location.pathname+'?page=trion-enko-rules-plugin');
		});
	});

})( jQuery );
