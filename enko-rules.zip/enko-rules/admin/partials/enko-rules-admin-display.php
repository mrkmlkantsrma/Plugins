<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://enkoeducation.com/
 * @since      1.0.0
 *
 * @package    Enko_Rules
 * @subpackage Enko_Rules/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->


<div class="trion-menu-craft-main">
    <?php
    global $wpdb;
    $table_name = $wpdb->prefix . 'trion_role_rules_meta';
    $menus_table = $wpdb->prefix . 'trion_menu_rules_meta';

    ?>
    <div class="trion-menu-craft-outer-admin">
        
        <!-- ************* roles form *************** -->
        <div class="trion-menu-craft-inner-admin add-new-role-sec">
            <form method="POST" id="rest_roles">
                <div class="trion-role-craft-inner-content-admin">
                    <div class="trion-role-craft-admin-label">
                        <label for="trion-role-craft-lbl">Enter Role</label>
                    </div>
                    <div class="trion-menu-craft-input">
                        <input class="role_name" type="text" name="role_name" placeholder="eg: Student"></input>
                    </div>
                    <div class="trion-role-craft-admin-label">
                        <label for="trion-role-craft-lbl">Enter Role Description</label>
                    </div>
                    <div class="trion-menu-craft-input">
                        <textarea name="role_description" rows="4" class="roles_des" placeholder="eg: Instruction for this Role"></textarea>
                    </div>
                </div>
                <div class="trion-role-craft-admin-foter">
                    <input type="submit" class="craft_button_addon craft_green" value="Add role">
                </div>
            </form>
        </div>

        <!--************* update roles form  ***************-->
        <?php
        if(isset($_GET['action']))
        {
            if($_GET['action'] == 'edit_role')
            {
                $style = 'style="display: block;"'; 
                ?><script>
                    jQuery('.add-new-role-sec').toggle(500);
                </script><?php
                
                $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
                $menu_items = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
                ?>

                <div class="trion-menu-craft-inner-admin update-role-sec" <?php echo $style ;?>>
                    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=trion-enko-rules-plugin')); ?>">
                        <div class="trion-menu-craft-inner-content-admin">
                            <input type="hidden" name="action" value="update_role">
                            <input type="hidden" name="menu_id" value="<?php echo $id; ?>">
                            <div class="trion-role-craft-admin-label">
                                <label for="trion-menu-craft-lbl">Update Role</label>
                            </div>
                            <div class="trion-menu-craft-input">
                                <input class="update_role_name" type="text" name="update_role_name"
                                    value="<?php echo $menu_items->role_name; ?>"></input>
                            </div>
                            <div class="trion-role-craft-admin-label">
                                <label for="trion-menu-craft-lbl">Update Role Description</label>
                            </div>
                            <div class="trion-menu-craft-input">
                                <textarea name="update_role_description"
                                    rows="4"><?php if( $menu_items->role_description) {echo $menu_items->role_description; } ?></textarea>
                            </div>
                        </div>
                        <div class="trion-role-craft-admin-foter">
                            <input type="submit" name="submit" class="craft_button_addon craft_green" value="Update role">
                            <button type="button" class="craft_button_addon craft_green"
                                id="cancel_update_role_btn">Cancel</button>
                        </div>
                    </form>
                </div>
            <?php  }
        } ?>
    </div>

    <!-- ************* fetch roles data  *************** -->
    <?php
    $res_roles = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    ?>

    <div class="trion-menu-craft-outer-admin rolelist">
        <div class="trion-menu-craft-inner-admin">
            <div class="trion-menu-craft-inner-content-admin">
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Roles</label>
                </div>
                <div class="trion-menu-craft-admin-invite-emails"> 
                    <?php
                    if (count($res_roles) > 0) 
                    {
                        foreach ($res_roles as $res_roles_data) 
                        {
                            echo '<div class="trion-menu-craft-content-outer">';
                            echo '<div class="trion-role-list-content">';
                            echo '<p class="trion-menu-craft-name"><b>Role Name :   </b> ' . $res_roles_data['role_name'] . '</p>';
                            if($res_roles_data['role_description']){
                                echo '<p class="trion-menu-craft-description"><b>Role Description :   </b> ' . $res_roles_data['role_description'] . '</p>';
                            }else{
                                echo '<p class="trion-menu-craft-description"><b>Role Description :   </b> - </p>';
                            }
                            echo '</div>';
                            echo '<div class="trion-menu-craft-btns">';
                            echo '<a class="trion-menu-craft-delete-btn" href="' . esc_url(admin_url('admin.php?page=trion-enko-rules-plugin&action=delete_role&id=' . $res_roles_data['id'])) . '">Delete</a>';
                            echo '<a class="trion-menu-craft-edit-btn" href="' . esc_url(admin_url('admin.php?page=trion-enko-rules-plugin&action=edit_role&id=' . $res_roles_data['id'])) . '">Edit</a>';
                            echo '</div>';
                            echo '</div>';

                        }
                    } 
                    else 
                    {
                        echo '<div class=""trion-menu-craft-menuList">';
                        echo '<p>No role found.</p>';
                        echo '</div>';
                    } ?>
                </div>
            </div>
        </div>
    </div>
    <?php
    /***********update role data *************/
    if ($_SERVER['REQUEST_METHOD'] === 'POST') 
    {
        if(isset($_POST['action']))
        {
            if($_POST['action'] == 'update_role')
            {

                $id = isset($_POST['menu_id']) ? intval($_POST['menu_id']) : 0;
                $menuDescription = null;
                $menuDescription = isset($_POST['update_role_description']) ? sanitize_textarea_field($_POST['update_role_description']) : '';
                $menuName = isset($_POST['update_role_name']) ? sanitize_textarea_field($_POST['update_role_name']) : '';
                if($menuName != '')
                {
                    $wpdb->update($table_name, array('role_name' => $menuName, 'role_description' =>$menuDescription), array('id' => $id));     
                    ?>
                    <script>
                        Swal.fire({
                        title: "Success",
                        text: "role updated sccessfully",
                        icon: "success",
                        buttons: false,
                        timer: 2000 
                        }).then(function() 
                        {
                            location.reload();
                        },200);
                    </script>
                    <?php
                }
                else
                { ?>
                    <script>
                        Swal.fire({
                        title: "Error",
                        text: "Unable to update role",
                        icon: "error",
                        buttons: false,
                        timer: 2000 
                        }).then(function() 
                        {
                            location.reload();
                        },200);
                    </script>
                    <?php
                }
            }
        }
    }

    /************* Delete role sec **************/ 
    if(isset($_GET['action']))
    {  
        if($_GET['action'] == 'delete_role')
        {
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            $wpdb->delete($table_name, array('id' => $id));
            ?>
            <script>
                Swal.fire({
                        title: "Success",
                        text: "role deleted sccessfully",
                        icon: "success",
                        buttons: false,
                        timer: 2000 
                        }).then(function() 
                        {
                            //location.reload();
                            location.href = "<?php echo esc_url(admin_url('admin.php?page=trion-enko-rules-plugin')); ?>";
                        },100);
            </script>
            <?php
        }
    }

    ?>

    <div class="trion-menu-craft-outer-admin">
        <!-- ************* roles form *************** -->
        <div class="trion-menu-craft-inner-admin assign-role-sec">
            <form method="POST" id="assign_roles">
                <div class="add-on-form-admin-foter mg-top-25">
                    <input type="submit" class="craft_button_addon craft_green" value="Assign Menus On Role">
                </div>
                <div class="trion-role-craft-inner-content-admin">
                    <div class="add-on-form-admin">
                        <label>Select Header Menu</label>
                        <select name="get_nav_menu_id" id="get_nav_menu_id">
                            <option value="">Select Header Menu</option>
                            <!--************* Get the menu names and IDs ***************-->
                            <?php
                            $query = "SELECT t.term_id, t.name
                                    FROM {$wpdb->terms} AS t
                                    INNER JOIN {$wpdb->term_taxonomy} AS tt ON t.term_id = tt.term_id
                                    WHERE tt.taxonomy = 'nav_menu'";
                            $menu_results = $wpdb->get_results( $query );
                            if(count($menu_results) > 0)
                            {
                                foreach($menu_results as $data) 
                                { ?>
                                    <option value="<?php echo $data->term_id; ?>"><?php echo $data->name; ?></option>
                                <?php }
                            }?>
                        </select>
                    </div>
                    <div class="add-on-form-admin">
                        <label>Select Footer First Menu</label>
                        <select name="get_footer_1_menu_id" id="get_footer_1_menu_id">
                            <option value="">Select Footer First Menu</option>
                            <!--************* Get the menu names and IDs ***************-->
                            <?php
                            $query = "SELECT t.term_id, t.name
                                    FROM {$wpdb->terms} AS t
                                    INNER JOIN {$wpdb->term_taxonomy} AS tt ON t.term_id = tt.term_id
                                    WHERE tt.taxonomy = 'nav_menu'";
                            $menu_results = $wpdb->get_results( $query );
                            if(count($menu_results) > 0)
                            {
                                foreach($menu_results as $data) 
                                { ?>
                                    <option value="<?php echo $data->term_id; ?>"><?php echo $data->name; ?></option>
                                <?php }
                            }?>
                        </select>
                    </div>
                    <div class="add-on-form-admin">
                        <label>Select Footer Second Menu</label>
                        <select name="get_footer_2_menu_id" id="get_footer_2_menu_id">
                            <option value="">Select Footer Second Menu</option>
                            <!--************* Get the menu names and IDs ***************-->
                            <?php
                            $query = "SELECT t.term_id, t.name
                                    FROM {$wpdb->terms} AS t
                                    INNER JOIN {$wpdb->term_taxonomy} AS tt ON t.term_id = tt.term_id
                                    WHERE tt.taxonomy = 'nav_menu'";
                            $menu_results = $wpdb->get_results( $query );
                            if(count($menu_results) > 0)
                            {
                                foreach($menu_results as $data) 
                                { ?>
                                    <option value="<?php echo $data->term_id; ?>"><?php echo $data->name; ?></option>
                                <?php }
                            }?>
                        </select>
                    </div>
                    <div class="add-on-form-admin">
                        <label>Select Footer Third Menu</label>
                        <select name="get_footer_3_menu_id" id="get_footer_3_menu_id">
                            <option value="">Select Footer Third Menu</option>
                            <!--************* Get the menu names and IDs ***************-->
                            <?php
                            $query = "SELECT t.term_id, t.name
                                    FROM {$wpdb->terms} AS t
                                    INNER JOIN {$wpdb->term_taxonomy} AS tt ON t.term_id = tt.term_id
                                    WHERE tt.taxonomy = 'nav_menu'";
                            $menu_results = $wpdb->get_results( $query );
                            if(count($menu_results) > 0)
                            {
                                foreach($menu_results as $data) 
                                { ?>
                                    <option value="<?php echo $data->term_id; ?>"><?php echo $data->name; ?></option>
                                <?php }
                            }?>
                        </select>
                    </div>
                    <div class="add-on-form-admin">
                        <label>Select Role</label>
                        <select name="get_role_id" id="get_role_id">
                            <option value="">Select Role</option>
                            <?php
                            if (count($res_roles) > 0) 
                            {
                                foreach ($res_roles as $res_roles_data) 
                                {?>
                                    <option value="<?php echo $res_roles_data['id']; ?>"><?php echo $res_roles_data['role_name']; ?></option>
                                <?php }
                            }?>
                        </select>
                    </div>
                </div>
            </form>
        </div>

            <?php 
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                if(isset($_POST['get_nav_menu_id']) && isset($_POST['get_role_id']) && isset($_POST['get_footer_1_menu_id']) ){

                    // Retrieve the selected product ID from the form submission
                    $nav_menu_id = $_POST['get_nav_menu_id'];
                    if($_POST['get_footer_1_menu_id']){
                        $footer_1_menu_id = $_POST['get_footer_1_menu_id'];
                    }else{
                        $footer_1_menu_id = null;
                    }
                    if($_POST['get_footer_2_menu_id']){
                        $footer_2_menu_id = $_POST['get_footer_2_menu_id'];
                    }else{
                        $footer_2_menu_id = null;
                    }
                    if($_POST['get_footer_3_menu_id']){
                        $footer_3_menu_id = $_POST['get_footer_3_menu_id'];
                    }else{
                        $footer_3_menu_id = null;
                    }
                    $role_id = $_POST['get_role_id'];

                    // Check if the user_id exists in the table
                    $existing_row = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT * FROM $menus_table WHERE role_id = %d",
                            $role_id
                        )
                    );

                    if ($existing_row) {
                        // Row exists, update the data
                        $data = array(
                            'menu_id' => $nav_menu_id,
                            'footer_1_menu_id' => $footer_1_menu_id,
                            'footer_2_menu_id' => $footer_2_menu_id,
                            'footer_3_menu_id' => $footer_3_menu_id,
                        );

                        $where = array('role_id' => $role_id);

                        $wpdb->update($menus_table, $data, $where);
                        ?>
                        <script>
                            Swal.fire({
                                    title: "Success",
                                    text: "Nav Menu Assign sccessfully",
                                    icon: "success",
                                    buttons: false,
                                    timer: 2000 
                                    }).then(function() 
                                    {
                                        //location.reload();
                                        location.href = "<?php echo esc_url(admin_url('admin.php?page=trion-enko-rules-plugin')); ?>";
                                    },100);
                        </script>
                        <?php
                    } else {
                        // Row does not exist, insert new data
                        $data = array(
                            'menu_id' => $nav_menu_id,
                            'footer_1_menu_id' => $footer_1_menu_id,
                            'footer_2_menu_id' => $footer_2_menu_id,
                            'footer_3_menu_id' => $footer_3_menu_id,
                            'role_id' => $role_id,
                        );

                        $wpdb->insert($menus_table, $data);
                        ?>
                        <script>
                            Swal.fire({
                                    title: "Success",
                                    text: "Nav Menu Assign sccessfully",
                                    icon: "success",
                                    buttons: false,
                                    timer: 2000 
                                    }).then(function() 
                                    {
                                        //location.reload();
                                        location.href = "<?php echo esc_url(admin_url('admin.php?page=trion-enko-rules-plugin')); ?>";
                                    },100);
                        </script>
                        <?php
                    }
                }
        }  ?>

   
        <?php
        $data = $wpdb->get_results("SELECT * FROM $menus_table", ARRAY_A);
        ?>
        <div class="div-table trion-role-tbl-outer">
            <div class="title trion-role-tbl-title"></div>
            <div class="table trion-role-tbl">
                <div class="tr">
                <div class="td">Nav Menu ID</div>
                <div class="td">Nav Menu Name</div>
                <div class="td">Role ID</div>
                <div class="td">Role Name</div>
                <div class="td">Footer Menu 1</div>
                <div class="td">Footer Menu 2</div>
                <div class="td">Footer Menu 3</div>
                <div class="td">Action</div>
            </div>
        
            <?php foreach ($data as $item){
                if($item['menu_id']){ ?>
                    <?php
                    $MenuData = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->terms} WHERE term_id = %d", $item['menu_id']));
                    $footer_1_MenuData = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->terms} WHERE term_id = %d", $item['footer_1_menu_id']));
                    $footer_2_MenuData = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->terms} WHERE term_id = %d", $item['footer_2_menu_id']));
                    $footer_3_MenuData = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->terms} WHERE term_id = %d", $item['footer_3_menu_id']));
                    $RollData = $wpdb->get_row( $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d ", $item['role_id']));
                    ?> 
                        <div class="tr">
                            <div class="td"><?php echo $item['menu_id']; ?></div>
                            <div class="td"><?php echo $MenuData->name; ?></div>
                            <div class="td"><?php echo $item['role_id']; ?></div>
                            <div class="td"><?php echo $RollData->role_name; ?></div>
                            <div class="td"><?php echo $footer_1_MenuData->name; ?></div>
                            <div class="td"><?php echo $footer_2_MenuData->name; ?></div>
                            <div class="td"><?php echo $footer_3_MenuData->name; ?></div>
                            <div class="td trion-menu-craft-btns"><a class="trion-menu-craft-delete-btn" href="<?php echo esc_url(admin_url('admin.php?page=trion-enko-rules-plugin&action=delete_roll_assign&id='.$MenuData->term_id)) ?>">Delete</a></div>
                        </div>
                <?php
                }
            } ?>
            </div>
        </div>
    </div>

        
    <?php

    if(isset($_GET['action'])){  
        if($_GET['action'] == 'delete_roll_assign'){
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

            $wpdb->delete($menus_table, array('menu_id' => $id));

            ?> 
            <script>
                Swal.fire({
                        title: "Success",
                        text: "Role Removed Successfully From Menu",
                        icon: "success",
                        buttons: false,
                        timer: 2000 
                        }).then(function() 
                        {
                            //location.reload();
                            location.href = "<?php echo esc_url(admin_url('admin.php?page=trion-enko-rules-plugin')); ?>";
                        },100);
            </script>
            <?php
        }
        
    } 


    ?>
</div>
