<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://trion.com
 * @since      1.0.0
 *
 * @package    Tw_Reminder
 * @subpackage Tw_Reminder/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<?php

global $wpdb;
$table_name = $wpdb->prefix . 'tw_reminder_emails';
?>
<div class="div-tw-reminder-outer-admin rem-submit-contnt">
    <div class="div-tw-reminder-inner-admin">
        <form method="POST">
        <div class="tw-reminder-inner-content-admin">
            <div class="tw-reminder-admin-label">
                <label for="tw-reminder-lbl">輸入電子郵件名稱</label>
            </div>
            <div class="tw-reminder-admin-input">
                <input class="reminder_email_name" type="text" name="reminder_email_name"></input>
            </div>
            <div class="tw-reminder-admin-label">
                <label for="tw-reminder-lbl">输入电子邮件主题</label>
            </div>
            <div class="tw-reminder-admin-input">
                <input class="reminder_email_subject" type="text" name="reminder_email_subject"></input>
            </div>
            <div class="tw-reminder-admin-label">
                <label for="tw-reminder-lbl">输入邮件内容</label>
            </div>
            <div class="tw-reminder-admin-input">
                <textarea name="reminder_email_content" rows="8"></textarea>
            </div>
        </div>
        <div class="rem_error_message"></div> 
        <div class="rem_success_message"></div> 
        <div class="tw-reminder-admin-foter">
            <input type="submit" value="节省">
        </div>
        </form>
    </div>
</div>
<?php   
    if(isset($_GET['action'])){
        if($_GET['action'] == 'edit_reminder_email'){

            
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            ?><script>
                setTimeout(() => {
                    jQuery(".rem-submit-contnt").hide();
                    jQuery(".rem-update-contnt").show();
                }, 300);
            </script>
            <?php

            // Retrieve the reminder email
            $reminder_email = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));

            // Display the edit form
            ?>

            <div class="div-tw-reminder-outer-admin rem-update-contnt">
                <div class="div-tw-reminder-inner-admin">
                    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=tw-reminder-plugin')); ?>">
                    <div class="tw-reminder-inner-content-admin">
                        <input type="hidden" name="action" value="update_reminder_email">
                        <input type="hidden" name="reminder_email_id" value="<?php echo $id; ?>">
                        <div class="tw-reminder-admin-label">
                            <label for="tw-reminder-lbl">輸入電子郵件名稱</label>
                        </div>
                        <div class="tw-reminder-admin-input">
                            <input class="reminder_email_name" type="text" name="reminder_email_update_name" value="<?php echo $reminder_email->email_name; ?>"></input>
                        </div>
                        <div class="tw-reminder-admin-label">
                            <label for="tw-reminder-lbl">输入电子邮件主题</label>
                        </div>
                        <div class="tw-reminder-admin-input">
                            <input class="reminder_email_update_subject" type="text" name="reminder_email_update_subject" value="<?php echo $reminder_email->email_subject; ?>"></input>
                        </div>
                        <div class="tw-reminder-admin-label">
                            <label for="tw-reminder-lbl">输入邮件内容</label>
                        </div>
                        <div class="tw-reminder-admin-input">
                            <textarea name="reminder_email_update_content" rows="8"><?php echo $reminder_email->content; ?></textarea>
                        </div>
                    </div>
                    <div class="tw-reminder-admin-foter">
                        <input type="submit" name="submit" value="更新">
                    </div>
                    </form>
                </div>
            </div>
            <?php
        }
    }

   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if(isset($_POST['reminder_email_content'])){
                $content = isset($_POST['reminder_email_content']) ? sanitize_textarea_field($_POST['reminder_email_content']) : '';
                $email_subject = isset($_POST['reminder_email_subject']) ? sanitize_textarea_field($_POST['reminder_email_subject']) : '';
                $email_name = isset($_POST['reminder_email_name']) ? sanitize_textarea_field($_POST['reminder_email_name']) : '';
                if($content != '' && $email_name != '' && $email_subject != ''){

                    $column_name = 'email_subject';

                    // Check if the column exists in the table
                    $column_exists = $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE '$column_name'");

                    if ($column_exists === null) {
                        // Alter the table to add the new column
                        $wpdb->query("ALTER TABLE $table_name ADD $column_name VARCHAR(255) NOT NULL DEFAULT ''");
                    }
                    // Insert the reminder email
                    $wpdb->insert($table_name, array('email_name' => $email_name , 'email_subject' => $email_subject , 'content' => $content));
                ?>
                <script>
                    Swal.fire({
                        toast: true,
                        icon: 'success',
                        title: '数据保存成功 , Data Save successfully',
                        animation: false,
                        position: 'center',
                        showConfirmButton: false,
                        timer: '3000',
                        timerProgressBar: false,
                        didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    })
                </script>
                <?php
                }else{  ?>
                <script>
                    Swal.fire({
                        toast: true,
                        icon: 'error',
                        title: '数据未保存 , Data Not Saved',
                        animation: false,
                        position: 'center',
                        showConfirmButton: false,
                        timer: '4000',
                        timerProgressBar: false,
                        didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    })
                </script>
                    <?php
                }
                
        }
   }
?>


<?php


$reminder_emails = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
?>


<div class="div-tw-reminder-outer-admin">
    <div class="div-tw-reminder-inner-admin">
        <div class="tw-reminder-inner-content-admin">
            <div class="tw-reminder-admin-label">
                <label for="tw-reminder-lbl">提醒邮件列表</label>
            </div>
            <div class="tw-reminder-admin-reminder-emails"> <?php
                    if (count($reminder_emails) > 0) {
                    foreach ($reminder_emails as $reminder_email) {
                        echo '<div class="reminder-email-content-outer">';
                        echo '<div class="reminder-email">';
                        echo '<p class="rem-email-name"><b>Name : </b>' . $reminder_email['email_name'] . '</p>';
                        echo '<p class="rem-email-subject"><b>Subject : </b>' . $reminder_email['email_subject'] . '</p>';
                        echo '<p class="rem-email-cntent"><b style="font-size: 18px;">Email : </b>' . $reminder_email['content'] . '</p>';
                        echo '</div>';
                        echo '<div class="reminder-email-btns">';
                        echo '<a class="delete-rem-btn" href="' . esc_url(admin_url('admin.php?page=tw-reminder-plugin&action=delete_reminder_email&id=' . $reminder_email['id'])) . '">删除</a>';
                        echo '<a class="edit-rem-btn" href="' . esc_url(admin_url('admin.php?page=tw-reminder-plugin&action=edit_reminder_email&id=' . $reminder_email['id'])) . '">编辑</a>';
                        echo '</div>';
                        echo '</div>';

                    }
                } else {
                    echo '<div class="reminder-email">';
                    echo '<p>未找到提醒电子邮件。</p>';
                    echo '</div>';
                } ?>
            </div>

        </div>
    </div>
</div>

<?php

if(isset($_GET['action'])){  
    if($_GET['action'] == 'delete_reminder_email'){
        echo $_GET['action'];
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Delete the reminder email
        $wpdb->delete($table_name, array('id' => $id));
        wp_redirect(admin_url('admin.php?page=tw-reminder-plugin'));

    }
    
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_POST['action'])){
        if($_POST['action'] == 'update_reminder_email'){
            $id = isset($_POST['reminder_email_id']) ? intval($_POST['reminder_email_id']) : 0;
            $content = isset($_POST['reminder_email_update_content']) ? sanitize_textarea_field($_POST['reminder_email_update_content']) : '';
            $email_subject = isset($_POST['reminder_email_update_subject']) ? sanitize_textarea_field($_POST['reminder_email_update_subject']) : '';
            $email_name = isset($_POST['reminder_email_update_name']) ? sanitize_textarea_field($_POST['reminder_email_update_name']) : '';
            if($content != '' && $email_name != '' && $email_subject != ''){
                $column_name = 'email_subject';

                // Check if the column exists in the table
                $column_exists = $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE '$column_name'");

                if ($column_exists === null) {
                    // Alter the table to add the new column
                    $wpdb->query("ALTER TABLE $table_name ADD $column_name VARCHAR(255) NOT NULL DEFAULT ''");
                }
                // Update the reminder email
                $wpdb->update($table_name, array('email_name' => $email_name, 'email_subject' => $email_subject , 'content' => $content), array('id' => $id));

                ?>
                <script>
                    Swal.fire({
                        toast: true,
                        icon: 'success',
                        title: '数据保存成功 , Data Save successfully',
                        animation: false,
                        position: 'center',
                        showConfirmButton: false,
                        timer: '3000',
                        timerProgressBar: false,
                        didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    })
                </script>
                <?php
                                // wp_redirect(admin_url('admin.php?page=tw-reminder-plugin'));
                }else{  ?>
                <script>
                    Swal.fire({
                        toast: true,
                        icon: 'error',
                        title: '数据未保存 , Data Not Saved',
                        animation: false,
                        position: 'center',
                        showConfirmButton: false,
                        timer: '4000',
                        timerProgressBar: false,
                        didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    })
                </script>
            <?php
            }
        }
    }
}