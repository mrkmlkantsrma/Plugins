<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://trion.com
 * @since      1.0.0
 *
 * @package    Tw_Reminder
 * @subpackage Tw_Reminder/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="evt-admin-custom-addon-main ">

<?php
global $wpdb;
$table_name = $wpdb->prefix . 'tw_reminder_email_meta';
$query = "SELECT order_id, product_id, user_email, course_date, after_purchase_reminder_sent, one_week_before_reminder_date, one_week_before_reminder_sent, one_day_before_reminder_date, one_day_before_reminder_sent, course_status, order_date FROM $table_name";
$result = $wpdb->get_results($query, ARRAY_A);


?>
        <div class="evt-invite-admin-label">
        </div>
            <?php 
                    if($result){
                    ?>

                        <div class="div-table evt-addon-tbl-outer inviter-lists-tbl">
                            <div class="title evt-addon-tbl-title">List for Emails Status</div>
                            <div class="table evt-addon-tbl">
                                <div class="tr heaad">
                                    <div class="td">Order Id</div>
                                    <div class="td">Product Id</div>
                                    <div class="td">User Email</div>
                                    <div class="td">Course Date</div>
                                    <div class="td">After Purchase Email</div>
                                    <div class="td">One Week Before Date</div>
                                    <div class="td">One Week Before Email</div>
                                    <div class="td">One Day Before Date</div>
                                    <div class="td">One Day Before Email</div>
                                    <div class="td">Course Status</div>
                                    <div class="td">Order Date</div>
                                </div>

                                <?php foreach ($result as $item) {
                                    echo '<div class="tr">';
                                    foreach ($item as $key =>  $column_value) {
                                        $cls = '';
                                        if($key == 'user_email'){$cls = 'emaail';}
                                        $clas = '';
                                        if($column_value == 'sent' || $column_value == 'active'){$clas = 'grn';}
                                        if($column_value == 'pending'){$clas = 'orng';}
                                        if($column_value == 'expired'){$clas = 'red';}
                                        echo '<div class="td '.$cls.''.$clas.'">' . $column_value . '</div>';
                                    }
                                    echo '</div>';
                                }
                                ?>
                            </div>
                        </div>                
           <?php  }else{
                    echo '<div class="invite-users-list">';
                    echo '<p>No match found.</p>';
                    echo '</div>';
                }
            ?>
</div>
