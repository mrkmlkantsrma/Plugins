<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://https://trion.com
 * @since             1.0.0
 * @package           Tw_Reminder
 *
 * @wordpress-plugin
 * Plugin Name:       TW Reminder
 * Plugin URI:        https://https://trion.com
 * Description:       This is a short description of TW Reminder plugin does. It's displayed in the WordPress admin area for email content and also sent emails with product variation to customers.
 * Version:           1.0.0
 * Author:            Trions
 * Author URI:        https://https://trion.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       tw-reminder
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'TW_REMINDER_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-tw-reminder-activator.php
 */
function activate_tw_reminder() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-tw-reminder-activator.php';
	Tw_Reminder_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-tw-reminder-deactivator.php
 */
function deactivate_tw_reminder() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-tw-reminder-deactivator.php';
	Tw_Reminder_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_tw_reminder' );
register_deactivation_hook( __FILE__, 'deactivate_tw_reminder' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-tw-reminder.php';


/**
 *
 * Register Admin Menus
 *
 */
add_action('admin_menu', 'Tw_reminder_plugin_menu');

function Tw_reminder_plugin_menu() {
    add_menu_page(
        'TW Reminder',      // Page title
        'TW Reminder',      // Menu title
        'manage_options',    // Capability required to access the page
        'tw-reminder-plugin',  // Menu slug
        'Tw_reminder_plugin_page',   // Callback function to render the page
        'dashicons-calendar' // Icon for the menu
    );
}

// Render the main menu page
function Tw_reminder_plugin_page() {

  require plugin_dir_path( __FILE__ ) . 'admin/partials/tw-reminder-admin-display.php';

}

// // Register the Export page
add_action('admin_menu', 'Tw_reminder_plugin_submenu');

function Tw_reminder_plugin_submenu() {
    add_submenu_page(
        'tw-reminder-plugin',  // Parent menu slug
        'Emails Status',      // Page title
        'Emails Status',      // Menu title
        'manage_options',    // Capability required to access the page
        'tw-reminder-plugin-email', // Menu slug
        'Tw_reminder_plugin_email_page' // Callback function to render the page
    );
}

// Render the Export page
function Tw_reminder_plugin_email_page() {

    require plugin_dir_path( __FILE__ ) . 'admin/partials/tw-reminder-admin-email-status.php';
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_tw_reminder() {

	$plugin = new Tw_Reminder();
	$plugin->run();

}
run_tw_reminder();

// Get products and variations in a custom plugin

// Include WooCommerce plugin file
// require_once ABSPATH . 'wp-content/plugins/woocommerce/woocommerce.php';



// Add variation custom fields
add_action( 'woocommerce_variation_options_pricing', 'add_variation_custom_option_pricing', 10, 3 );
function add_variation_custom_option_pricing( $loop, $variation_data, $variation ) {
    global $wpdb;

    // Get the dropdown options from the database table
    $dropdown_options = $wpdb->get_results( "SELECT id, email_name FROM " . $wpdb->prefix . "tw_reminder_emails" );
    $options = array();
    foreach ( $dropdown_options as $option ) {
        $options[ $option->id ] = $option->email_name;
    }

    $variation_id = $variation->ID;

    // Add text field for course date
    woocommerce_wp_text_input( array(
        'id'                => '_course_date[' . $variation_id . ']',
        'label'             => __( '<span class="course_req">Course Date </span><span class="course_req1">(only support like 24/06/2023)</span><span class="course_req2">* without course date emails are not work for this product</span> ', 'woocommerce' ),
        'class'             => 'short courseDate_product',
        'placeholder'       => 'dd/mm/yyyy', 
        'wrapper_class'     => 'course_req-top form-row form-row-first',
        'value'             => get_post_meta( $variation_id, '_course_date', true ),
        'custom_attributes' => array( 'step' => 'any' ),
    ) );

    // Add dropdown field for "Just After purchase Email"
    woocommerce_wp_select( array(
        'id'                => '_reminder_email_after_purchase[' . $variation_id . ']',
        'label'             => __( 'Just After purchase Email', 'woocommerce' ),
        'class'             => 'short',
        'wrapper_class'     => 'form-row form-row-last',
        'options'           => $options,
        'value'             => get_post_meta( $variation_id, '_reminder_email_after_purchase', true ),
    ) );

    // Add dropdown field for "1 Week Before Reminder Email"
    woocommerce_wp_select( array(
        'id'                => '_reminder_email_before_1_week[' . $variation_id . ']',
        'label'             => __( '1 Week Before Reminder Email', 'woocommerce' ),
        'class'             => 'short',
        'wrapper_class'     => 'form-row form-row-first',
        'options'           => $options,
        'value'             => get_post_meta( $variation_id, '_reminder_email_before_1_week', true ),
    ) );

    // Add dropdown field for "1 Day Before Reminder Email"
    woocommerce_wp_select( array(
        'id'                => '_reminder_email_before_1_day[' . $variation_id . ']',
        'label'             => __( '1 Day Before Reminder Email', 'woocommerce' ),
        'class'             => 'short',
        'wrapper_class'     => 'form-row form-row-last',
        'options'           => $options,
        'value'             => get_post_meta( $variation_id, '_reminder_email_before_1_day', true ),
    ) );
}

add_action( 'woocommerce_save_product_variation', 'save_variation_custom_option_pricing', 10, 2 );
function save_variation_custom_option_pricing( $variation_id, $i ){

    if( isset($_POST['_course_date'][$variation_id]) ){
        // Create a DateTime object using the specified format
        $date = DateTime::createFromFormat('d/m/Y', $_POST['_course_date'][$variation_id]);

        // Check if the date matches the specified format
        if ($date && $date->format('d/m/Y') === $_POST['_course_date'][$variation_id]) {
            update_post_meta( $variation_id, '_course_date', wc_clean( wp_unslash( str_replace( ',', '.', $_POST['_course_date'][$variation_id]) ) ) ); 
        } else { ?>
            <script>
                console.log("if else");
                Swal.fire({
                    toast: true,
                    icon: 'error',
                    title: '如果課程日期未以 <b>(dd/mm/yyyy)</b> 格式輸入，這些提醒電子郵件將不起作用 </br> These reminder emails will not work if course date is not entered in the format <b>(dd/mm/yyyy)</b>',
                    animation: false,
                    position: 'center',
                    showConfirmButton: false,
                    timer: '4000',
                    timerProgressBar: false,
                    didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })
            </script> <?php
        }
    }else{
        ?>
            <script>
                console.log("else");
                Swal.fire({
                    toast: true,
                    icon: 'error',
                    title: '如果沒有輸入課程日期，這些提醒電子郵件將不起作用 </br> These reminder emails will not work if no course dates have been entered',
                    animation: false,
                    position: 'center',
                    showConfirmButton: false,
                    timer: '4000',
                    timerProgressBar: false,
                    didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })
            </script>
        <?php
    }
    if( isset($_POST['_reminder_email_after_purchase'][$variation_id]) ){
        update_post_meta( $variation_id, '_reminder_email_after_purchase', wc_clean( wp_unslash( str_replace( ',', '.', $_POST['_reminder_email_after_purchase'][$variation_id]) ) ) );
    }
    if( isset($_POST['_reminder_email_before_1_week'][$variation_id]) ){
        update_post_meta( $variation_id, '_reminder_email_before_1_week', wc_clean( wp_unslash( str_replace( ',', '.', $_POST['_reminder_email_before_1_week'][$variation_id]) ) ) );
    }
    if( isset($_POST['_reminder_email_before_1_day'][$variation_id]) ){
        update_post_meta( $variation_id, '_reminder_email_before_1_day', wc_clean( wp_unslash( str_replace( ',', '.', $_POST['_reminder_email_before_1_day'][$variation_id]) ) ) );
    }
}


// Hook into the 'woocommerce_order_status_completed' action
add_action('woocommerce_thankyou', 'create_evt_event_group_purchase', 10, 1);
function create_evt_event_group_purchase($order_id) {
    global $wpdb;
    
    // Get the order object
    $order = wc_get_order($order_id);
    
    // Get the user ID, email, and name
    $user_id = $order->get_user_id();
    $user_email = $order->get_billing_email();
    $user_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
    
    // Get the current date
    $current_date = date('d/m/Y');
    
    // Loop through the order items
    foreach ($order->get_items() as $item) {
        $product_id = $item->get_product_id();
        $variation_id = $item->get_variation_id();
        
        // Check if the variation has the meta keys
        if (metadata_exists('post', $variation_id, '_course_date') &&
            metadata_exists('post', $variation_id, '_reminder_email_after_purchase') &&
            metadata_exists('post', $variation_id, '_reminder_email_before_1_week') &&
            metadata_exists('post', $variation_id, '_reminder_email_before_1_day')
        ) {
            // Get the meta values
            $course_date = get_post_meta($variation_id, '_course_date', true);
            if($course_date){
                $reminder_email_after_purchase = get_post_meta($variation_id, '_reminder_email_after_purchase', true);
                $reminder_email_before_1_week = get_post_meta($variation_id, '_reminder_email_before_1_week', true);
                $reminder_email_before_1_day = get_post_meta($variation_id, '_reminder_email_before_1_day', true);

                $courseDateFormatted = DateTime::createFromFormat('d/m/Y', $course_date)->format('Y-m-d');
                $courseTimestamp = strtotime($courseDateFormatted);
            
                // Calculate one-week before reminder date
                $oneWeekBeforeTimestamp = strtotime('-1 week', $courseTimestamp);
                $oneWeekBeforeReminderDate = date('Y-m-d', $oneWeekBeforeTimestamp);
            
                // Calculate one-day before reminder date
                $oneDayBeforeTimestamp = strtotime('-1 day', $courseTimestamp);
                $oneDayBeforeReminderDate = date('Y-m-d', $oneDayBeforeTimestamp);

                $table_name = $wpdb->prefix . 'tw_reminder_emails';
                $afterPrchaseReminderEmail = $reminder_email_after_purchase;

                // Retrieve the reminder email
                $after_purchase_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $afterPrchaseReminderEmail));

                // Retrieve the reminder email
                $after_purchase_content = $after_purchase_data->content;
                $after_purchase_subject= $after_purchase_data->email_subject;

                // Send the after purchase email
                $to = $user_email;
                $subject = $after_purchase_subject;
                $message = $after_purchase_content;
                wp_mail($to, $subject, $message);

                // Insert data into the custom table
                $wpdb->insert(
                    $wpdb->prefix . 'tw_reminder_email_meta',
                    array(
                        'order_id' => $order_id,
                        'product_id' => $product_id,
                        'variation_id' => $variation_id,
                        'user_id' => $user_id,
                        'user_email' => $user_email,
                        'user_name' => $user_name,
                        'course_date' => $course_date,
                        'reminder_email_after_purchase' => $reminder_email_after_purchase,
                        'after_purchase_reminder_sent' => 'sent',
                        'reminder_email_before_1_week' => $reminder_email_before_1_week,
                        'reminder_email_before_1_day' => $reminder_email_before_1_day,
                        'one_week_before_reminder_date' => $oneWeekBeforeReminderDate,
                        'one_week_before_reminder_sent' => 'pending',
                        'one_day_before_reminder_date' => $oneDayBeforeReminderDate,
                        'one_day_before_reminder_sent' => 'pending',
                        'course_status' => 'active',
                        'order_date' => $current_date
                    ),
                    array(
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s'
                    )
                );
            }
        }
    }
}


// Schedule the cron job
// Define custom cron interval of 1 minute
function custom_course_reminder_cron_interval($schedules) {
    $schedules['one_minute'] = array(
        'interval' => 60, // 1 minute in seconds
        'display' => __('Every 1 Minute')
    );
    return $schedules;
}
add_filter('cron_schedules', 'custom_course_reminder_cron_interval');


// Schedule the cron job to run every minute
function custom_course_reminder_schedule_cron() {

    if (!wp_next_scheduled('custom_course_reminder_cron')) {
        wp_schedule_event(time(), 'one_minute', 'custom_course_reminder_cron');
    }
}
add_action('init', 'custom_course_reminder_schedule_cron');

// Process the cron job
function custom_course_reminder_process() {
    global $wpdb;

    // Get the current date
    $currentDate = date('Y-m-d');

    // Create a log entry for the cron job execution
    $logMessage = 'Inside Cron job executed at ' . date('Y-m-d H:i:s') . "\n";
    file_put_contents(__DIR__ . '/cron_log.txt', $logMessage, FILE_APPEND);

    // Fetch the course reminders from the table
    $tableName = $wpdb->prefix . 'tw_reminder_email_meta';
    $query = "SELECT * FROM $tableName";
    $results = $wpdb->get_results($query);

    // Iterate through the results
        foreach ($results as $result) {

        $courseDateFormatted = $result->course_date;
        if($courseDateFormatted){
            $courseDate = DateTime::createFromFormat('d/m/Y', $courseDateFormatted)->format('Y-m-d');
            $oneWeekBeforeReminderDate = $result->one_week_before_reminder_date;
            $oneDayBeforeReminderDate = $result->one_day_before_reminder_date;
            $courseStatus = $result->course_status;
            $oneWeekBeforeReminderSent = $result->one_week_before_reminder_sent;
            $oneDayBeforeReminderSent = $result->one_day_before_reminder_sent;
            $user_email = $result->user_email;

            $table_name = $wpdb->prefix . 'tw_reminder_emails';
            $oneWeekBeforeReminderemail = $result->reminder_email_before_1_week;
            $oneDayBeforeReminderemail = $result->reminder_email_before_1_day;
        
            // Retrieve the reminder email
            $one_Week_Before_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $oneWeekBeforeReminderemail));
            $one_Day_Before_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $oneDayBeforeReminderemail));
        
            // Retrieve the reminder email
            $one_Week_Before_content = $one_Week_Before_data->content;
            $one_Week_Before_subject= $one_Week_Before_data->email_subject;

            $one_Day_Before_content = $one_Day_Before_data->content;
            $one_Day_Before_subject= $one_Day_Before_data->email_subject;


            // Check if the course is expired
            if ($courseStatus != 'expired') {

                // Check if the current date matches the one-week before reminder date
                if ($currentDate == $oneWeekBeforeReminderDate && $oneWeekBeforeReminderSent != 'sent') {
                    // Update the row in the table to mark the reminder as sent
                    $wpdb->update(
                        $tableName,
                        array('one_week_before_reminder_sent' => 'sent'),
                        array('id' => $result->id),
                        array('%s'),
                        array('%d')
                    );

                    // Create a log entry for the match
                    $logMessage = 'Match found for one-week before reminder on ' . $currentDate . "\n";
                    file_put_contents(__DIR__ . '/cron_log.txt', $logMessage, FILE_APPEND);


                    // Send the one-week before reminder email
                    $to = $user_email ;
                    $subject = $one_Week_Before_subject;
                    $message = $one_Week_Before_content;
                    wp_mail($to, $subject, $message);

                }

                // Check if the current date matches the one-day before reminder date
                if ($currentDate == $oneDayBeforeReminderDate && $oneDayBeforeReminderSent != 'sent') {
                    // Update the row in the table to mark the reminder as sent
                    $wpdb->update(
                        $tableName,
                        array('one_day_before_reminder_sent' => 'sent'),
                        array('id' => $result->id),
                        array('%s'),
                        array('%d')
                    );

                    // Create a log entry for the match
                    $logMessage = 'Match found for one-day before reminder on ' . $currentDate . "\n";
                    file_put_contents(__DIR__ . '/cron_log.txt', $logMessage, FILE_APPEND);
    

                    // Send the one-day before reminder email
                    $to = $user_email;
                    $subject = $one_Day_Before_subject;
                    $message = $one_Day_Before_content;
                    wp_mail($to, $subject, $message);

                }

                // Check if the current date is past the course date
                if ($currentDate > $courseDate) {
                    $wpdb->update(
                        $tableName,
                        array('course_status' => 'expired'),
                        array('id' => $result->id),
                        array('%s'),
                        array('%d')
                    );

                    // Update the row in the table to mark the course as expired
                }
            }
        }else{
            // Create a log entry for the match
            $logMessage = 'No course date found ';
            file_put_contents(__DIR__ . '/cron_log.txt', $logMessage, FILE_APPEND);
        }
    }
}

// Hook into the cron job event
add_action('custom_course_reminder_cron', 'custom_course_reminder_process');
