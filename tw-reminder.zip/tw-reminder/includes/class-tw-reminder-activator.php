<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://trion.com
 * @since      1.0.0
 *
 * @package    Tw_Reminder
 * @subpackage Tw_Reminder/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Tw_Reminder
 * @subpackage Tw_Reminder/includes
 * @author     Trions <testingemailer1212@gmail.com>
 */
class Tw_Reminder_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		
		global $wpdb;
		$table_name = $wpdb->prefix . 'tw_reminder_emails';
		$meta_table_name = $wpdb->prefix . 'tw_reminder_email_meta';

		// Create the table if it doesn't exist
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			id INT(11) NOT NULL AUTO_INCREMENT,
			email_name TEXT NOT NULL,
			email_subject TEXT NOT NULL,
			content TEXT NOT NULL,
			PRIMARY KEY (id)
		) $charset_collate;";
		$wpdb->query($sql);


		$meta_sql = "CREATE TABLE IF NOT EXISTS $meta_table_name (
			id INT(11) NOT NULL AUTO_INCREMENT,
			order_id varchar(255) NOT NULL,
			product_id varchar(255) NOT NULL,
			variation_id varchar(255) NOT NULL,
			user_id varchar(255) NOT NULL,
			user_email varchar(255) NOT NULL,
			user_name varchar(255) NOT NULL,
			course_date varchar(255) NOT NULL,
			reminder_email_after_purchase varchar(255) NOT NULL,
			after_purchase_reminder_sent varchar(255) NOT NULL,
			reminder_email_before_1_week varchar(255) NOT NULL,
			one_week_before_reminder_date varchar(255) NOT NULL,
			one_week_before_reminder_sent varchar(255) NOT NULL,
			reminder_email_before_1_day varchar(255) NOT NULL,
			one_day_before_reminder_date varchar(255) NOT NULL,
			one_day_before_reminder_sent varchar(255) NOT NULL,
			course_status varchar(255) NOT NULL,
			order_date varchar(255) NOT NULL,
			PRIMARY KEY (id)
		) $charset_collate;";
		$wpdb->query($meta_sql);	

	}

}
