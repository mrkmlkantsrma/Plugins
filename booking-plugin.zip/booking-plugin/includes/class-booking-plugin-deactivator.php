<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://wppb.me/
 * @since      1.0.0
 *
 * @package    Booking_Plugin
 * @subpackage Booking_Plugin/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Booking_Plugin
 * @subpackage Booking_Plugin/includes
 * @author     Rekha Gill <testingemailer1212@gmail.com>
 */
class Booking_Plugin_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
