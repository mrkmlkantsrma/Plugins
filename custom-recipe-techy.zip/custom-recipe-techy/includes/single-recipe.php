<?php
/*
 * Template Name: Single Recipe
 * Template Post Type: recipe
 */

get_header(); ?>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <?php  while (have_posts()) :  the_post();  ?>
        <?php $postID = get_the_ID();
        $recipe_product_id = get_post_meta($postID, 'recipe_product_id', true);
        $term = get_term($recipe_product_id, 'ingredient_category');
        $term_description = term_description($recipe_product_id, 'ingredient_category');
        $recipe_persons = get_post_meta($postID, 'recipe_persons', true);
        $recipe_cooking_time = get_post_meta($postID, 'recipe_cooking_time', true);
        $recipeContent = get_the_content();
        ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <div class="recipe-box">
                    <div class="recipe-heading">
                        <?php the_title('<h1>', '</h1>'); ?>
                    </div>
                    <div class="recipe-image-box">
                    <?php if (has_post_thumbnail($postID)) {
                        $thumbnail_url = get_the_post_thumbnail_url($postID, 'large');
                        echo '<div class="recipe-image" style="background-image: url('.$thumbnail_url.');"><h2>'.get_the_title().'</h2></div>';
                    } ?>
                    
    				</div>
                    <div class="recipe-main-content-box">
                        <div class="recipe-top-content-box">
							<div class="recipe-category-overview">
                                <div class="category_box">
                                    <?php echo $term_description; ?>
                                </div>
                            </div>
                            <div class="recipe-top-overview">
                                <div class="overview_box cooking_time">
                                    <h4><?php esc_html_e('Cooking time', 'crg'); ?></h4>
                                    <p><?php echo $recipe_cooking_time; ?></p>
                                </div>
                                <div class="overview_box person_serving">
                                    <h4><?php esc_html_e('Number of servings', 'crg'); ?></h4>
                                    <p><?php echo $recipe_persons; ?> <?php esc_html_e('Persons', 'crg'); ?></p>
                                </div>
                            </div>
                            
                            <div class="recipe-top-content">
                                <?php $pattern = '/<div class="overview">(.*?)<\/div>.*<div class="how-to-cook">.*<\/div>/s';
                                    preg_match($pattern, $recipeContent, $matches);
                                    if (isset($matches[0])) {
                                        $recipeContent = $matches[0];
                                    }
                                $recipeContent = trim($recipeContent);
                                echo $recipeContent; ?>
                            </div>
                        </div>
                        <div class="recipe-bottom-content-box">
                            <div class="recipe-bottom-heading">
            					<h2><?php esc_html_e('Creatpea Recipe Instruction', 'crg'); ?></h2>
        					</div>
        					<div class="recipe-bottom-content">
        					    <p><?php esc_html_e('To prepare 500 g of ready mass, mix 130 g of dry powder with 300 ml of cold water and 70 ml of oil. Mix until a homogeneous mass is obtained and store in the refrigerator for 10 minutes. Divide into 5 portions (100 grams per portion) and prepare your favorite meal (hamburgers, meatballs, kebabs, etc.). You can cook/fry/bake and add spices and vegetables in any way you want.', 'crg'); ?></p>
        					</div>
                        </div>
                    </div>
                </div>
            </article>
        <?php endwhile; ?>
    </main>
</div>
<style>
/*    .recipe-top-overview {
    display: flex;
    gap: 40px;
}
.recipe-category-overview p {
    width: max-content;
    background: #e48200;
    border-radius: 8px;
    padding: 5px 15px;
    color: #fff;
}
.recipe-top-content {
    display: flex;
    flex-wrap: wrap;
}
.recipe-top-content p:nth-child(1) {
    width: 100%;
}
.recipe-top-content p:nth-child(2) {
    width: 40%;
}
.recipe-top-content p:nth-child(3) {
    width: 50%;
}
.recipe-image-box .recipe-image {
    background-size: cover;
    height: 400px;
    background-position: center center;
}
*/
</style>
<?php get_footer();
