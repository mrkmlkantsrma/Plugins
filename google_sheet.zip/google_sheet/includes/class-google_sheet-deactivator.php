<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://http://localhost/googlesheet/
 * @since      1.0.0
 *
 * @package    Google_sheet
 * @subpackage Google_sheet/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Google_sheet
 * @subpackage Google_sheet/includes
 * @author     Techy Trion <testingemailer1212@gmail.com>
 */
class Google_sheet_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
