<?php

/**
 * Fired during plugin activation
 *
 * @link       https://http://localhost/googlesheet/
 * @since      1.0.0
 *
 * @package    Google_sheet
 * @subpackage Google_sheet/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Google_sheet
 * @subpackage Google_sheet/includes
 * @author     Techy Trion <testingemailer1212@gmail.com>
 */
class Google_sheet_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() 
	{
		/*********** create table emp data *****************/ 
		global $wpdb;
		$table_name = 'employee_records';

		// Check if table exists
		if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) 
		{
			// Table does not exist, so create it
			$sql = "CREATE TABLE $table_name (
				id INT PRIMARY KEY AUTO_INCREMENT,
				emp_id INT,
				emp_fname VARCHAR(255),
				emp_lname VARCHAR(255),
				emp_company_name VARCHAR(255),
				company_id INT,
				emp_email VARCHAR(255),
				emp_join_date DATE,
				emp_data_exist VARCHAR(50),
				updated_at	DATE
			);";

			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		}
	}

}
