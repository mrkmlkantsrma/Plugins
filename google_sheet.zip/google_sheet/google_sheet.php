<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://http://localhost/googlesheet/
 * @since             1.0.0
 * @package           Google_sheet
 *
 * @wordpress-plugin
 * Plugin Name:       Google Sheet 
 * Plugin URI:        https://http://localhost/googlesheet/wp-admin/plugins.php
 * Description:       To update data in a Google Sheet
 * Version:           1.0.0
 * Author:            Techy Trion
 * Author URI:        https://http://localhost/googlesheet/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       google_sheet
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'GOOGLE_SHEET_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-google_sheet-activator.php
 */
function activate_google_sheet() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-google_sheet-activator.php';
	Google_sheet_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-google_sheet-deactivator.php
 */
function deactivate_google_sheet() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-google_sheet-deactivator.php';
	Google_sheet_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_google_sheet' );
register_deactivation_hook( __FILE__, 'deactivate_google_sheet' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-google_sheet.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */

/**** craete custom post type ******/ 
add_action('admin_menu', 'google_sheet_cpt');

function google_sheet_cpt() 
{
    add_menu_page(
        'Google Sheet',      
        'Google Sheet',       
        'manage_options',    
        'google_sheet',        
        'google_sheet_admin_page', 
        'dashicons-media-spreadsheet'   
    );

	add_submenu_page(
        'google_sheet',             
        'Google Details',           
        'Google Details',          
        'manage_options',          
        'google_sheet_details',    
        'google_sheet_detail_page'  
    );
}
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

function google_sheet_admin_page() 
{
   include plugin_dir_path(__FILE__) . '/admin/partials/google_sheet-admin-display.php';
}

function google_sheet_detail_page() 
{
   include plugin_dir_path(__FILE__) . '/admin/partials/google_sheet-admin-details.php';
}



/************* run google sheet ****************/ 
function run_google_sheet() 
{
	$plugin = new Google_sheet();
	$plugin->run();
}
run_google_sheet();

/*************** get all employess from company name ***************/ 

add_action('wp_ajax_nopriv_get_employees', 'get_employees');
add_action('wp_ajax_get_employees', 'get_employees');

function get_employees()
{
   if(isset($_POST['get_company_id']))
   {
		$get_company_id = $_POST['get_company_id'];
   }
   /************ get employees******************/   
   global $wpdb;

   	$table_name = $wpdb->prefix . 'tablesome_table_24560';

   	$query = "SELECT column_4 FROM $table_name Where id = '".$get_company_id."'";

	$results = $wpdb->get_row($query);

   	$query = "SELECT * FROM $table_name Where column_4 = '".$results->column_4."'";
   	$results = $wpdb->get_results($query);
	if($results)
	{  
		$response = array('success' => true, 'data' => $results );
	}

	else
	{
		$response = array('success' => true, 'data' => $results );
	}	
	echo json_encode($response);
	die();

}

/****************** bootstrap modal********************/ 
add_action('admin_footer', 'enter_emp_id_modal');
function enter_emp_id_modal()
{?>
	<div class="container">
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h4 class="modal-title">Form</h4>
					</div>
					<div class="modal-body">
						<label>Enter Employee Id :</label>
						<input type ="text" name="emp_idd" id="get_emp_id">
					</div>
					<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary" id="save_id">Save</button>
					</div>
				</div>
			</div>
		</div>	
		</div>
<?php }

/************** match data in the database ****************/ 
add_action('wp_ajax_nopriv_match_emp_data', 'match_emp_data');
add_action('wp_ajax_match_emp_data',  'match_emp_data');

function match_emp_data()
{
	if(isset($_POST['get_emp_id']))
	{
		$get_emp_id = $_POST['get_emp_id'];
		
		global $wpdb;
		$table_name = $wpdb->prefix . 'tablesome_table_24560';

		// Check if the employee ID exists in the database
        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $get_emp_id);
        $result = $wpdb->get_var($query);
        

		$column_name = 'emp_data_exist';
		// Check if the column already exists
		$column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_name LIKE '$column_name'");

		if (empty($column_exists)) {
			// Alter table to add the new column
			$wpdb->query("ALTER TABLE $table_name ADD COLUMN $column_name VARCHAR(255) DEFAULT 'FALSE'");
		}

        // Update the "emp_data_exist" column based on the existence of the employee ID
        if($result) 
		{
            $wpdb->update($table_name, array('emp_data_exist' => 'Yes'), array('id' => $get_emp_id));
			$response = array('status' => true, 'data' => $get_emp_id);
			echo json_encode($response);
			wp_die();
        } 
	}
}

/************** match data in the database ****************/ 
add_action('wp_ajax_nopriv_update_google_sheet_data', 'update_google_sheet_data');
add_action('wp_ajax_update_google_sheet_data',  'update_google_sheet_data');

function update_google_sheet_data()
{
	if(isset($_POST['get_emp_id']))
	{
		$get_emp_id = $_POST['get_emp_id'];
		
		global $wpdb;
		$table_name = $wpdb->prefix . 'tablesome_table_24560';

		// Check if the employee ID exists in the database
        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = '$get_emp_id' AND emp_data_exist = 'Yes'");
        $result = $wpdb->get_row($query);

		$column_name = 'sheet_entry_date';
		// Check if the column already exists
		$column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_name LIKE '$column_name'");

		if (empty($column_exists)) {
			// Alter table to add the new column
			$wpdb->query("ALTER TABLE $table_name ADD COLUMN $column_name VARCHAR(255) DEFAULT 'FALSE'");
		}

        if($result) 
		{
			$updated_data = array(
				'sheet_entry_date'	=> date('Y-m-d'),
            );

			$where = array('id' => $get_emp_id);

			$wpdb->update($table_name, $updated_data, $where);

			// Check if the employee ID exists in the database
			$query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = '$get_emp_id'");
			$resultdata = $wpdb->get_row($query);

			 // Return the updated data as the response
			 $response = array(
				'status' => true,
                'data'   => $resultdata
            );

			echo json_encode($response);
        } 
	}
}

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);	
/*********** handle google sheet *****************/ 
add_action('wp_ajax_nopriv_updateGoogleSheet', 'updateGoogleSheet');
add_action('wp_ajax_updateGoogleSheet',  'updateGoogleSheet');

function updateGoogleSheet()
{
	// scope : https://www.googleapis.com/auth/spreadsheets

	if(isset($_POST['emp_data']))
	{
		$emp_data = $_POST['emp_data'];

		// Remove the trailing "0" at the end of the string
        $emp_data = rtrim($emp_data, "0");

		 // Remove unnecessary backslashes from the JSON string
		 $emp_data = stripslashes($emp_data);

		 // Parse the JSON string
		 $data = json_decode($emp_data, true);
		global $wpdb;
		 $google_table_name = $wpdb->prefix . 'google_details_collect'; 
		 $detail_items = $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM $google_table_name"),
			ARRAY_A
		);



		// Usage example
		$spreadsheetId = $detail_items['sheet_id'];
		$range = 'Sheet1!A2:E';

		// Fetch the existing data from the Google Sheet
		$accessToken = $detail_items['access_token'];

		$sheet_data = getGoogleSheetData($spreadsheetId, $range, $accessToken);

		// Get the last ID from the fetched data
		$lastsheetID = getLastID($sheet_data);

		// Increment the ID for the new entry
		$newID = $lastsheetID + 1;

		$updatedData = array(
			'ID'                                                          => $data['data']['column_1'],
			'Todays Date'                                                 => date('d/m/Y'), 
			'Name'                                                        => $data['data']['column_3'], 
			'Company Name (that you work for, not our company name)'      => $data['data']['column_4'],
			'Facility Name / Mine'                                        => $data['data']['column_5'],
			'Initial or Re-certification?'                                => $data['data']['column_6'],
			'Event Location City (City name only)'                        => $data['data']['column_7'],
			'State'                                                       => $data['data']['column_8'],
			'Email Address'                                               => $data['data']['column_9'],
			'Phone Number (no dashes, numbers only)'                      => $data['data']['column_10'],
			'CC Email Address (Send copy to primary contact or your boss)'=> $data['data']['column_11'],
			'Created'                                                     => $data['data']['created_at'],
			'updated_at'	                                              => date('d-m-Y')
		);

		$values =  [
			$updatedData['ID'],
			$updatedData['Todays Date'],
			$updatedData['Name'],
			$updatedData['Company Name (that you work for, not our company name)'],
			$updatedData['Facility Name / Mine'],
			$updatedData['Initial or Re-certification?'],
			$updatedData['Event Location City (City name only)'],
			$updatedData['State'],
			$updatedData['Email Address'],
			$updatedData['Phone Number (no dashes, numbers only)'],
			$updatedData['CC Email Address (Send copy to primary contact or your boss)'],
			$updatedData['Created'],
			$updatedData['updated_at'],
	   ];		   

		addEntryToGoogleSheet($spreadsheetId, $range, $values, $accessToken);
	}

}
/************* get google sheet data *****************/ 
function getGoogleSheetData($spreadsheetId, $range, $accessToken)
{
    // Prepare the request URL
    $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheetId}/values/{$range}";

    // Prepare the headers
    $headers = [
        "Authorization: Bearer {$accessToken}",
        'Content-Type: application/json'
    ];

    // Initialize cURL
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute the request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Check the response and return the data
    if ($httpCode == 200) 
	{
        $data = json_decode($response, true);
        return $data;
    } 
	else 
	{
        echo 'Error fetching data from the Google Sheet: ' . $response;
        exit();
    }
}

/************* get last id******************/ 
function getLastID($data)
{
    // Extract the ID values from the fetched data
    $ids = array_column($data['values'], 0);

    // Sort the IDs in descending order
    rsort($ids);

    // Return the first ID in the sorted array (highest ID)
    return $ids[0];
}

/************* add entry in google sheet *******************/ 
function addEntryToGoogleSheet($spreadsheetId, $range, $values, $accessToken)
{
    // Prepare the request URL
    $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheetId}/values/{$range}:append?valueInputOption=USER_ENTERED";

    // Prepare the headers
    $headers = [
					"Authorization: Bearer {$accessToken}",
					'Content-Type: application/json'
               ];

    // Prepare the data payload
    $data = [
        		'values' => [$values]
            ];

    // Convert the data to JSON
    $jsonData = json_encode($data);

    // Initialize cURL
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

    // Execute the request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Check the response and display appropriate message
    if ($httpCode == 200) 
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'tablesome_table_24560';

		$column_name = 'google_sheet_entry';
		// Check if the column already exists
		$column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_name LIKE '$column_name'");

		if (empty($column_exists)) {
			// Alter table to add the new column
			$wpdb->query("ALTER TABLE $table_name ADD COLUMN $column_name VARCHAR(255) DEFAULT 'FALSE'");
		}

		$updated_data = array(
			'google_sheet_entry'	=> 'success',
		);

		$where = array('id' => $get_emp_id);

		$wpdb->update($table_name, $updated_data, $where);

        echo 'Entry added to the Google Sheet.';
    } 
	else 
	{
        echo 'Error adding entry to the Google Sheet: ' . $response;
    }

    // Close cURL
    curl_close($ch);
}



