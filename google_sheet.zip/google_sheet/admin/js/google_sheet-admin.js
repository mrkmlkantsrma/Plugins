(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	/********* get comapanies ************/ 
	jQuery(document).ready(function($) 
	{

		/************* get company id ******************/ 
		$('#companies').on('change', function()
		{
			var get_company_id = $(this).val();

			$.ajax({
					url: ajax_object.ajaxurl,	
					method: 'POST',
					data: {
							action: 'get_facility',
							'get_company_id': get_company_id
						  },
					success: function(response) 
					{
						// Handle the response data
						console.log(response);
						var res = JSON.parse(response);

						if(res.success == true)
						{
							var facility_data = res.data;
							//console.log(facility_data);
							var html = '';
							html += '<option value="0">Select Facility Name</option>';
							$.each(facility_data, function(index, facilityData) 
							{
								var facility_name = facilityData.column_5;
								html += '<option value="'+facilityData.id+'">'+facility_name+'</option>';
							});

							$('#facility').html(html);		
											
						}

					},
					error: function(xhr, status, error) 
					{
						// Handle the error
						console.log(error);
					}
			       });
		})

		/************* get company id ******************/ 
		$('#facility').on('change', function()
		{
			var get_company_id = $(this).val();

			$.ajax({
					url: ajax_object.ajaxurl,	
					method: 'POST',
					data: {
							action: 'get_employees',
							'get_company_id': get_company_id
						  },
					success: function(response) 
					{
						// Handle the response data
						console.log(response);
						var res = JSON.parse(response);

						if(res.success == true)
						{
							var emp_data = res.data;
							//console.log(emp_data);
							var html = '';
							html += '<option value="0">Select Employee</option>';
							$.each(emp_data, function(index, employee_data) 
							{
								var emp_name = employee_data.column_3;
								html += '<option value="'+employee_data.id+'">'+emp_name+'</option>';
							});

							$('#employee').html(html);		
											
						}

					},
					error: function(xhr, status, error) 
					{
						// Handle the error
						console.log(error);
					}
			       });
		})

		/************* show enter emp id modal ********************/ 
		$('#employee').on('change', function()
		{
			//var get_emp_id = $(this).val();
			jQuery('#myModal').addClass('shown');
			jQuery('#myModal').show(100);
		})

		/***************** get employee id ********************/ 
		$('#save_id').on('click', function()
		{
			var get_emp_id = $('#get_emp_id').val();
			console.log(get_emp_id);

			$.ajax({
						url: ajax_object.ajaxurl,	
						method: 'POST',
						datatype : 'json',
						data: {
								action: 'match_emp_data',
								'get_emp_id': get_emp_id
							  },
						success: function(response) 
						{
							//console.log(response);
							var data1 = JSON.parse(response)
							
							if(data1.status)
							{
								// Swal.fire({
								// 	title: "Success",
								// 	text: "Data updated sucessfully",
								// 	icon: "success",
								// 	buttons: false,
								// 	timer: 2000 
								// }).then(function() 
								// {
									$.ajax({
										url: ajax_object.ajaxurl,	
										method: 'POST',
										datatype : 'json',
										data: {
												action: 'update_google_sheet_data',
												'get_emp_id': data1.data
											  },
										success: function(response) 
										{
											/******* google sheet handle ***********/ 
											console.log(response);
											$.ajax({
													url: ajax_object.ajaxurl,	
													method: 'POST',
													datatype : 'json',
													data: {
															action: 'updateGoogleSheet',
															'emp_data': response
														  },
													success: function(response) 
													{
														console.log(response);
														jQuery('#myModal').removeClass('shown');
														jQuery('#myModal').hide(100);
														alert("Data enter in google sheet");
													}
												})
										}
									});
									
									//location.reload();
								// },200);
							}
							else
							{
								Swal.fire({
									title: "Error",
									text: "Unable to updated sucessfully",
									icon: "error",
									buttons: false,
									timer: 2000 
								}).then(function() 
								{
									//location.reload();
								},200);
							}
						},
						error: function(xhr, status, error) 
						{
							console.log(error);
						}
			       })
		})
	});
	

})( jQuery );


