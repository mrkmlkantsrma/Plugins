<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://http://localhost/googlesheet/
 * @since      1.0.0
 *
 * @package    Google_sheet
 * @subpackage Google_sheet/admin/partials
 */
?>
<div class="trion-menu-craft-main">
<?php       
global $wpdb;
$table_name = $wpdb->prefix . 'google_details_collect'; 


// Create the table if it doesn't exist
if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id INT(11) NOT NULL AUTO_INCREMENT,
        client_id VARCHAR(255) NOT NULL,
        client_secret VARCHAR(255) NOT NULL,
        refresh_token VARCHAR(255) NOT NULL,
        access_token VARCHAR(255) NOT NULL,
        sheet_id VARCHAR(255) NOT NULL,
        token_time DATETIME NOT NULL,
        email_associated VARCHAR(255) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

    <div class="trion-menu-craft-outer-admin">
            <div class="trion-menu-craft-admin-foter">
                <a href="https://developers.google.com/oauthplayground/" target="_blank" class="craft_button_addon craft_green">Get Access Token</a>
            </div>
        <div class="trion-menu-craft-inner-admin add-new-menu-sec">
            <form method="POST">
            <div class="trion-menu-craft-inner-content-admin">
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Enter Client ID</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="client_id" type="text" name="client_id"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Enter Client Secret</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="client_secret" type="text" name="client_secret"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Enter Refresh Token</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="refresh_token" type="text" name="refresh_token"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Enter Access Token</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="access_token" type="text" name="access_token"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Enter Sheet ID</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="sheet_id" type="text" name="sheet_id"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Enter Email Associated</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="email_associated" type="text" name="email_associated"></input>
                </div>
            </div>
            <div class="craft_error_message"></div> 
            <div class="craft_success_message"></div> 
            <div class="trion-menu-craft-admin-foter">
                <input type="submit" class="craft_button_addon craft_green" value="Save">
            </div>

            </form>
        </div>
        



<?php  

    $detail_items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name"));

    if($detail_items){
        ?>
            <script>
                jQuery('.add-new-menu-sec').toggle();
                jQuery('.add-new-menu-sec').hide();
                jQuery('.add-new-menu-sec').remove();
            </script>
            <?php
    }

   if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        if (isset($_POST['client_id']) && isset($_POST['client_secret']) && isset($_POST['refresh_token']) && isset($_POST['access_token']) && isset($_POST['sheet_id']) && isset($_POST['email_associated'])) {
                global $wpdb;
                $table_name = $wpdb->prefix . 'google_details_collect';
            
                $client_id = $_POST['client_id'];
                $client_secret = $_POST['client_secret'];
                $refresh_token = $_POST['refresh_token'];
                $access_token = $_POST['access_token'];
                $sheet_id = $_POST['sheet_id'];
                $email_associated = $_POST['email_associated'];

                $current_time = current_time('mysql'); // Get the current timestamp in MySQL format
                $expiration_time = strtotime('+1 hour', strtotime($current_time)); // Add 1 hour to the current timestamp
                $token_time  = date('Y-m-d H:i:s', $expiration_time); // Format the new timestamp as per your table column
            
            
                $wpdb->insert(
                    $table_name,
                    array(
                        'client_id' => $client_id,
                        'client_secret' => $client_secret,
                        'refresh_token' => $refresh_token,
                        'access_token' => $access_token,
                        'sheet_id' => $sheet_id,
                        'token_time' => $token_time,
                        'email_associated' => $email_associated
                    ),
                    array(
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s'
                    )
                );
                echo 'Data inserted successfully!';
        } 
        
    }
    ?> 


    <?php
    if(isset($_GET['action'])){
        if($_GET['action'] == 'edit_details'){
        $style = 'style="display: block;"';
        ?>
        <script>
            jQuery('.trion-menu-craft-inner-content-admin-list').remove();
        </script>
        <?php
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $detail_items = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
        ?>
        <div class="trion-menu-craft-inner-admin update-new-menu-sec" <?php echo $style ;?>>
            <form method="POST">
            <div class="trion-menu-craft-inner-content-admin">
                <input type="hidden" name="action" value="update_details">
                <input type="hidden" name="detail_id" value="<?php echo $id; ?>">
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Edit Client ID</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="client_id" type="text" name="client_id" value="<?php echo $detail_items->client_id; ?>"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Edit Client Secret</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="client_secret" type="text" name="client_secret" value="<?php echo $detail_items->client_secret; ?>"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Edit Refresh Token</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="refresh_token" type="text" name="refresh_token" value="<?php echo $detail_items->refresh_token; ?>"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Edit Access Token</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="access_token" type="text" name="access_token" value="<?php echo $detail_items->access_token; ?>"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Edit Sheet ID</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="sheet_id" type="text" name="sheet_id" value="<?php echo $detail_items->sheet_id; ?>"></input>
                </div>
                <div class="trion-menu-craft-admin-label">
                    <label for="trion-menu-craft-lbl">Edit Email Associated</label>
                </div>
                <div class="trion-menu-craft-input">
                    <input class="email_associated" type="text" name="email_associated" value="<?php echo $detail_items->email_associated; ?>"></input>
                </div>
            </div>
            <div class="craft_error_message"></div> 
            <div class="craft_success_message"></div> 
            <div class="trion-menu-craft-admin-foter">
                <input type="submit" class="craft_button_addon craft_green" value="Update">
            </div>
            </form>
        </div>
<?php  }
    } ?>
<?php

// Retrieve all records from the table
$records = $wpdb->get_results("SELECT * FROM $table_name");

// Display the records
if (!empty($records)) {
    foreach ($records as $record) {
        $client_id = $record->client_id;
        $client_secret = $record->client_secret;
        $refresh_token = $record->refresh_token;
        $access_token = $record->access_token;
        $sheet_id = $record->sheet_id;
        $email_associated = $record->email_associated;
        $token_time = $record->token_time;
        echo '<div class="trion-menu-craft-inner-admin">';
        echo '<div class="trion-menu-craft-inner-content-admin-list">';
        // Display the record values
        echo '<p><strong>Client ID:</strong> ' . $client_id . '</p>';
        echo '<p><strong>Client Secret:</strong> ' . $client_secret . '</p>';
        echo '<p><strong>Refresh Token:</strong> ' . $refresh_token . '</p>';
        echo '<p><strong>Access Token:</strong> ' . $access_token . '</p>';
        echo '<p><strong>Sheet ID:</strong> ' . $sheet_id . '</p>';
        echo '<p><strong>Email Associated:</strong> ' . $email_associated . '</p>';
        echo '<p><strong>Token Time:</strong> ' . $token_time . '</p>';

        // Display the edit button
        echo '<a class="trion-menu-craft-edit-btn" href="'. esc_url(admin_url('admin.php?page=google_sheet_details&action=edit_details&id='  . $record->id )) .'">Edit</a>';

        echo '<hr>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo 'No records found.';
}

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if(isset($_POST['action'])){
            if($_POST['action'] == 'update_details'){
                $id = isset($_POST['detail_id']) ? intval($_POST['detail_id']) : 0;
                global $wpdb;
                $table_name = $wpdb->prefix . 'google_details_collect';
            
                $client_id = $_POST['client_id'];
                $client_secret = $_POST['client_secret'];
                $refresh_token = $_POST['refresh_token'];
                $access_token = $_POST['access_token'];
                $sheet_id = $_POST['sheet_id'];
                $email_associated = $_POST['email_associated'];

                $current_time = current_time('mysql'); // Get the current timestamp in MySQL format
                $expiration_time = strtotime('+1 hour', strtotime($current_time)); // Add 1 hour to the current timestamp
                $token_time  = date('Y-m-d H:i:s', $expiration_time); // Format the new timestamp as per your table column
                
                $wpdb->query("DELETE FROM $table_name");

                $wpdb->insert(
                    $table_name,
                    array(
                        'client_id' => $client_id,
                        'client_secret' => $client_secret,
                        'refresh_token' => $refresh_token,
                        'access_token' => $access_token,
                        'sheet_id' => $sheet_id,
                        'token_time' => $token_time,
                        'email_associated' => $email_associated
                    ),
                    array(
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s'
                    )
                ); 
                        wp_redirect(admin_url('admin.php?page=google_sheet_details'));
                ?>
                    <script>
                        location.reload
                        Swal.fire({
                            toast: true,
                            icon: 'success',
                            title: 'Details Updated Succsfully',
                            animation: false,
                            position: 'center',
                            showConfirmButton: false,
                            timer: 3500,
                            timerProgressBar: false,
                            didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal.stopTimer)
                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                    </script>
                <?php
            }else{ ?>
                    <script>
                        Swal.fire({
                            toast: true,
                            icon: 'error',
                            title: 'Details Not Updated!',
                            animation: false,
                            position: 'center',
                            showConfirmButton: false,
                            timer: 3500,
                            timerProgressBar: false,
                            didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal.stopTimer)
                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                    </script>
                <?php
            }
        }
    }

?>

    </div>
</div>

