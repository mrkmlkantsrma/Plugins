<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://http://localhost/googlesheet/
 * @since      1.0.0
 *
 * @package    Google_sheet
 * @subpackage Google_sheet/admin/partials
 */
?>
<div class="trion-menu-craft-main">
<?php       
global $wpdb;
$table_name = $wpdb->prefix . 'tablesome_table_24560';
// echo $table_name;
// $query = "SELECT * FROM $table_name";
// // $query = "SELECT DISTINCT column_4, id  FROM $table_name";
// $results = $wpdb->get_results($query);

// echo $wpdb->last_query;

// echo '<pre>';
// print_r($results);
// echo '</pre>'; die; 
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<!--**************** get all companies*************** -->
<div class ="main-div">
    <label>Select Company</label>
    <select id="companies">
    <option value="0">Select Company</option>
        <?php
        // $query = "SELECT DISTINCT emp_company_name, company_id  FROM $table_name";
        $query = "SELECT DISTINCT column_4, id  FROM $table_name";
        $results = $wpdb->get_results($query);

        $uniqueCompanyNames = array();

        foreach($results as $key => $data)
        {
            if(!in_array($data->column_4, $uniqueCompanyNames)) 
            {
                $uniqueCompanyNames[] = $data->column_4;
            ?>
                <option value="<?php echo $data->id ?>"><?php echo $data->column_4; ?></option>
            <?php }
        }
        ?>
    </select>
</div>

<!--*************** get employee data ************-->
<div class ="main-emp-div">
    <label>Select Employee</label>
    <select id="employee">
        <option value="0">Select Employee</option>
    </select>
</div>

<div class="container model-constainer">
    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                <h4 class="modal-title">Form</h4>
                </div>
                <div class="modal-body">
                    <label>Enter Employee Id :</label>
                    <input type ="text" name="emp_idd" id="get_emp_id">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="save_id">Save</button>
                </div>
            </div>
        </div>
    </div>	
</div>
</div>

