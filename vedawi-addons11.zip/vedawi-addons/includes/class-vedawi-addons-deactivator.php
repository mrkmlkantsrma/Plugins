<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://vedawi.com
 * @since      1.0.0
 *
 * @package    Vedawi_Addons
 * @subpackage Vedawi_Addons/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Vedawi_Addons
 * @subpackage Vedawi_Addons/includes
 * @author     vedawi <info@vedawi.com>
 */
class Vedawi_Addons_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
