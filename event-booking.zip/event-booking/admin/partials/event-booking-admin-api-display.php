<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/admin/partials
 */
?>
<?php
 if(isset($_POST['submit'])) {
    // Validate input fields
    $api_url = sanitize_text_field($_POST['api_url']);
    $api_key = sanitize_text_field($_POST['api_key']);
    // Perform validation
    if(empty($api_url) || empty($api_key)) {
        echo "API URL and API Key are required.";
    } elseif(!filter_var($api_url, FILTER_VALIDATE_URL)) {
        echo "Invalid API URL format.";
    } elseif(!preg_match('/^[a-zA-Z0-9]+$/', $api_key)) {
        echo "Invalid API Key format. It should contain only alphanumeric characters.";
    } else {
    //    echo "shgdfh";
        $valid_credentials = validate_api_credentials($api_url, $api_key);
        if(!$valid_credentials['success']) {
            echo "API URL or API Key is invalid or not accessible: " . $valid_credentials['message'];
        } else {
            update_option('api_url', $api_url);
            update_option('api_key', $api_key);
            echo "Settings saved successfully!";
        }
    }
}
?>
  <div class="wrap">
        <h1>My Custom Page</h1>
        <div class="custom-tabs">
            <ul class="tab-list">
                <li><a href="#tab-event"  class="active">Event</a></li>
                <li><a href="#tab-api">API</a></li>
                <li><a href="#tab-vendor">Vendor</a></li>
            </ul>
            <div id="tab-event" class="tab-content active" >
            <?php
            // Query to get all posts of the 'event' post type
            $events_query = new WP_Query(array(
            'post_type' => 'event',
            'post_status' => 'publish',
            'posts_per_page' => -1, // Retrieve all posts
            ));

            // Check if there are any events
            if ($events_query->have_posts()) {
            ?>
            <div class="event-listing-box"> 
            <table class="event-list-table">
                <thead>
                    <tr>
                        <th>Event Name </th>
                        <th>Event Link</th>
                        <th>Copy Link</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($events_query->have_posts()) : $events_query->the_post(); ?>
                        <tr class="event-list-items">
                            <td class="event-list-item title-item">
                                <a class="event-title" href="<?php echo esc_url(get_permalink()); ?>"><?php the_title(); ?></a>
                            </td>
                            <td class="event-list-item slug-item">
                                <span class="event-slug"><?php echo esc_url(get_permalink()); ?></span>
                            </td>
                            <td class="event-list-item copy-item">
                                <button class="copy-slug-button" data-slug="<?php echo esc_url(get_permalink()); ?>">❐</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            </div>
            <?php
            // Restore global post data
            wp_reset_postdata();
            }
            
            ?>
            </div>
            <div id="tab-api" class="tab-content">
                <div class="wrap">
                    <h2>Event Booking API Setting</h2>
                    <form method="post" action="">
                        <label for="api_url">API URL:</label><br><br>
                        <input type="text" id="api_url" name="api_url" value="<?php echo esc_attr(get_option('api_url')); ?>"><br><br>
                        <label for="api_key">API Key:</label><br><br>
                        <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr(get_option('api_key')); ?>"><br><br><br>
                        <input type="submit" name="submit" value="Save Settings">
                    </form>
                </div>
            </div>
            <div id="tab-vendor" class="tab-content">
                <div class="wrap">
                    <h2>Vendor registration Url</h2><br><br>
                    <div class="vender-url-reg">
                        <a class="event-title" href="<?php echo site_url(); ?>/vendor-registration">Vendor Registration</a>
                        <span class="event-slug"><?php echo site_url(); ?>/vendor-registration</span>
                        <button class="copy-slug-button" data-slug="<?php echo site_url(); ?>/vendor-registration">❐</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
   