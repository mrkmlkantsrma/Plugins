<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap">
<h2>Bookings</h2><br><br>
<div class="vender-url-reg">
    <a class="event-title" href="<?php echo site_url(); ?>/profile" target="_blank">Bookings</a>
    <span class="event-slug"><?php echo site_url(); ?>/Profile</span>
    <button class="copy-slug-button" data-slug="<?php echo site_url(); ?>/profile">❐</button>
</div>
</div>