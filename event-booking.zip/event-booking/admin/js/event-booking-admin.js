(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	jQuery(document).ready(function($) {
		
			// Show default tab
			$('.tab-content:first-child').addClass('active');
			$('.tab-list li:first-child a').addClass('active');
		
			// Tab click event
			$('.tab-list li a').on('click', function(e) {
				e.preventDefault();
				var targetTab = $(this).attr('href');
				$('.tab-list li a').removeClass('active');
				$(this).addClass('active');
				$('.tab-content').removeClass('active');
				$(targetTab).addClass('active');
		
		});
		
	});
	document.addEventListener('DOMContentLoaded', function () {
		// Format the date and time for the input field
		var now = new Date();
		var year = now.getFullYear();
		var month = String(now.getMonth() + 1).padStart(2, '0'); // Month starts from 0
		var day = String(now.getDate()).padStart(2, '0');
		var hour = String(now.getHours()).padStart(2, '0');
		var minute = String(now.getMinutes()).padStart(2, '0');
	
		var formattedDateTime = year + '-' + month + '-' + day + 'T' + hour + ':' + minute;
	
		// Set the min attribute of the input field to the current date and time
		var datepicker = document.getElementById('datepicker');
		if (datepicker) {
			datepicker.min = formattedDateTime;
		}
	
		// Add event listener to the container for dynamic rows
		var container = document.querySelector('.repeater-container');
		if (container) {
			container.addEventListener('click', function (e) {
				if (e.target.classList.contains('remove-row')) {
					e.target.parentNode.remove();
				}
			});
	
			var addBtn = container.querySelector('.add-row');
			if (addBtn) {
				addBtn.addEventListener('click', function () {
					var field = document.createElement('div');
					field.classList.add('repeater-field');
					field.innerHTML = `
						<label for="datepicker"><?php esc_html_e( 'Date & Time:', 'business-conference' ); ?></label>
						<input type="datetime-local" name="repeater_data[new_date][date][]" value="" required>
						<input type="number" name="repeater_data[new_date][min][]" placeholder="Min Persons">
						<input type="number" name="repeater_data[new_date][max][]" placeholder="Max Persons">
						<button class="remove-row">Remove</button>
					`;
					container.querySelector('.repeater-fields').appendChild(field);
				});
			}
		}
	});


	document.addEventListener('DOMContentLoaded', function () {
        var copyButtons = document.querySelectorAll('.copy-slug-button');

        copyButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                var slugToCopy = button.getAttribute('data-slug');
                copyToClipboard(slugToCopy);
            });
        });

        function copyToClipboard(text) {
            var textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            alert('Slug copied to clipboard: ' + text);
        }
    });
	
	
})( jQuery );
