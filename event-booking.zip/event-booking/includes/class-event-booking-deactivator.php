<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Event_Booking
 * @subpackage Event_Booking/includes
 * @author     Techy Trion <testingemailer1212@gmail.com>
 */
class Event_Booking_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
