<?php

/**
 * Register all actions and filters for the plugin
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/includes
 */

/**
 * Register all actions and filters for the plugin.
 *
 * Maintain a list of all hooks that are registered throughout
 * the plugin, and register them with the WordPress API. Call the
 * run function to execute the list of actions and filters.
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/includes
 * @author     Techy Trion <testingemailer1212@gmail.com>
 */

class Event_Booking_Onload{
/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
    public function __construct() {
        add_filter('single_template',array( $this,'custom_event_single_template'));      
        add_filter( 'wp_mail_content_type', array($this,'wpse27856_set_content_type' ) );
    }


    function wpse27856_set_content_type(){
        return "text/html";
    }
    
    function custom_event_single_template($single_template) {
        global $post;
    
        // Check if the post type is 'event'
        if ($post->post_type == 'event') {
            // Path to your custom single page template file
            $single_template =  require event_booking_path. 'public/partials/event-booking-event-display.php';

        }
    
        return $single_template;
    }

    

}

$onload_instance = new Event_Booking_Onload();