<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/**
 * Register all actions and filters for the plugin
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/includes
 */

/**
 * Register all actions and filters for the plugin.
 *
 * Maintain a list of all hooks that are registered throughout
 * the plugin, and register them with the WordPress API. Call the
 * run function to execute the list of actions and filters.
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/includes
 * @author     Techy Trion <testingemailer1212@gmail.com>
 */

class Event_Booking_Onload_2{
/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
    public function __construct() {

        add_shortcode('register-form',array( $this,'event_register_form_fuction'));     
        add_shortcode('customer-register-form',array( $this,'customer_register_form_fuction'));     
        add_action('init',array( $this,'add_vendor_role'));    
        add_action('admin_init',array( $this,'remove_vendor_role_dashbaord'),9999);    
        add_shortcode('vendor_profile_shortcode',array( $this,'vendor_profile_shortcode')); 
        add_shortcode('login_shortcode',array( $this,'vendor_login_shortcode'));
        add_filter('page_template', array( $this,'assign_profile_template'));


    }
    
    
    function remove_vendor_role_dashbaord(){
        if (current_user_can('vendor')) {
            $site_url = home_url(); 
        wp_enqueue_style('vendor-dashboard-style',plugin_dir_url( __FILE__ ) . 'css/vendor-admin-dashboard.css', array(), time(), 'all'); 
        wp_enqueue_script('jquery');
 
        // Add custom script to remove elements and show loading overlay
        wp_add_inline_script('jquery', '
            jQuery(document).ready(function($) {
                $("body").addClass("vendor-dashboard");
                $("#adminmenuback, .page-title-action, .edit-timestamp, #edit-slug-box, .edit-post-status, #screen-meta-links, #post-preview, .edit-visibility, #wpadminbar, #wpfooter, #adminmenuwrap, #adminmenushow, #wpadminbar div#wpbody-content, .update-nag").remove();
                var link = $("<a>", {
                    text: "Back ",
                    href: "' . esc_url($site_url) . '/profile/",
                    class: "custom-link"
                });
                // Append link before .wp-heading-inline element
                $(".wp-heading-inline").before(link);
   
            });
        ');
    
        }
    }
  

    function assign_profile_template($template) {
        // Check if we are on the page with the slug 'profile'
        if (is_page('profile')) {
            // Path to your custom template file
            $custom_template = event_booking_path . 'public/partials/event-booking-vendor-profile.php';
    
            // Use the custom template if it exists
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }
    
        // Return the original template for other pages
        return $template;
    }
    
    
    function add_vendor_role() {
        add_role('vendor', 'Vendor', array(
            'read' => true,
        ));
    }
    function customer_register_form_fuction() {

        if (isset($_POST['submit_registration'])) {
            // Get user data from the form
            $first_name = sanitize_text_field($_POST['first_name']);
            $last_name = sanitize_text_field($_POST['last_name']);
            $email = sanitize_email($_POST['email']);
            $phone = sanitize_text_field($_POST['phone']);
    
            $username = sanitize_user(strtolower($first_name . $last_name));
	
            // Check if the username already exists, if it does, append a number until a unique one is found
            $suffix = 1;
            while (username_exists($username)) {
                $username = sanitize_user(strtolower($first_name . $last_name)) . $suffix;
                $suffix++;
            }

            // Check if the user already exists
            if (email_exists($email)) {
                // User already exists, handle accordingly (display error message, redirect, etc.)
                echo "User already exists. Please choose a different email or name combination.";
            } else {
                // Generate a random password
                $password = wp_generate_password();
    
                // Create the user
                $user_id = wp_insert_user(array(
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'user_login' => $username,
                    'user_pass'  => $password,
                    'user_email' => $email,
                ));
    
                if (is_wp_error($user_id)) {
                    // Handle error during user creation
                    echo "Error creating user: " . $user_id->get_error_message();
                } else {

                    update_user_meta($user_id, 'phone_number', $phone);
                    $mail_type ="user_registration_mail";
					
					$mail_data =array(
						'email'=>$email,
						// 'cc_emails'=>array($vendor_email),
						'user_name'=>$username,
						'user_email'=>$email,
						'user_password'=>$password,

	
					);
                    // echo $email;
					$mail_result = send_booking_mail($mail_type,$mail_data);
                    // echo $mail_result;die;
					if (!$mail_result) {
                        echo "Failed to send registration email. Please contact support for assistance.";
                        // Log the error for further investigation
                        error_log("Failed to send registration email to $to");
					} else {
						$mail_type ="new_user_registration_mail";
						$fields = get_field('admin_details', 'option');
						$admin_email= $fields['admin_email'] ?? '';
						
					
						$mail_data =array(
							'email'=>$admin_email,
							// 'cc_emails'=>array($vendor_email),
							'user_name'=>$username,
							'user_email'=>$email,
							
	
		
						);
						$mail_result = send_booking_mail($mail_type,$mail_data);
                        if ($mail_result) {
                            // Email sent successfully
                            echo "User registered successfully. Check your email for login details.";
                        } else {
                            // Email sending failed
                            echo "Failed to send registration email. Please contact support for assistance.";
                            // Log the error for further investigation
                            error_log("Failed to send registration email ");
                        }
					}
                        
                        die; // Ensure the script stops execution after email sending attempt
                } 
            }
        }

        
        ob_start();
        require event_booking_path. 'public/partials/event-booking-customer-register-display.php';
        return ob_get_clean();
    }
    function event_register_form_fuction() {

        if (isset($_POST['submit_registration'])) {
            // Get user data from the form
            $first_name = sanitize_text_field($_POST['first_name']);
            $last_name = sanitize_text_field($_POST['last_name']);
            $email = sanitize_email($_POST['email']);
            $phone = sanitize_text_field($_POST['phone']);
    
            $username = sanitize_user(strtolower($first_name . $last_name));
	
            // Check if the username already exists, if it does, append a number until a unique one is found
            $suffix = 1;
            while (username_exists($username)) {
                $username = sanitize_user(strtolower($first_name . $last_name)) . $suffix;
                $suffix++;
            }

            // Check if the user already exists
            if (email_exists($email)) {
                // User already exists, handle accordingly (display error message, redirect, etc.)
                echo "User already exists. Please choose a different email or name combination.";
            } else {
                // Generate a random password
                $password = wp_generate_password();
    
                // Create the user
                $user_id = wp_insert_user(array(
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'user_login' => $username,
                    'user_pass'  => $password,
                    'user_email' => $email,
                    'role'       => 'vendor', // Assign the 'vendor' role
                ));
    
                if (is_wp_error($user_id)) {
                    // Handle error during user creation
                    echo "Error creating user: " . $user_id->get_error_message();
                } else {

                    update_user_meta($user_id, 'phone_number', $phone);

                    @$registartion_mail = get_field('registartion_mail', 'option'); 
                    $to = $email;
                
                    $message= $registartion_mail;
                     if(strpos($message, "!user_name!") !== false){
                       $message=str_replace("!user_name!",$username,$message);
                     }
                      if(strpos($message, "!user_email!") !== false){
                       $message=str_replace("!user_email!",$email,$message);
                     }
                     if(strpos($message, "!user_password!") !== false){
                        $message=str_replace("!user_password!",$password,$message);
                     }
            
                    $subject = 'Your account details';
                 
                    $headers[] = 'Content-Type: text/html; charset=UTF-8'; // Ensure HTML content type
                   
                    
                    // Send email
                    // Send email
                        if (wp_mail($to, $subject, $message, $headers)) {
                            // Email sent successfully
                            echo "User registered successfully. Check your email for login details.";
                        } else {
                            // Email sending failed
                            echo "Failed to send registration email. Please contact support for assistance.";
                            // Log the error for further investigation
                            error_log("Failed to send registration email to $to");
                        }
                        die; // Ensure the script stops execution after email sending attempt

     
                } 
            }
        }

        
        ob_start();
        require event_booking_path. 'public/partials/event-booking-register-display.php';
        return ob_get_clean();
    }

    function vendor_profile_shortcode() {
    
        if (isset($_POST['logout'])) {
            // Clear session variables
            unset($_SESSION['user_id']);
            unset($_SESSION['username']);
    
            // Log out
            wp_logout();
    
            // Redirect to the current page after logout
            wp_redirect(home_url('/profile'));
            exit;
        }
    
        ob_start();
        require event_booking_path . 'public/partials/event-booking-vendor-profile.php';
        return ob_get_clean();
    }

    function vendor_login_shortcode() {
        ob_start();
        if (isset($_POST['login'])) {
            // Retrieve user input
            $username_or_email = sanitize_text_field($_POST['username']);
            $password = sanitize_text_field($_POST['password']);
    
            // Prepare and execute a query to retrieve user information
            global $wpdb;
            $table_name = $wpdb->prefix . 'users'; // Assuming your users table has a WordPress-like prefix
    
            // Check if the input is a valid email address
            if (is_email($username_or_email)) {
                $user_data = $wpdb->get_row($wpdb->prepare("SELECT ID, user_login, user_pass FROM $table_name WHERE user_email = %s", $username_or_email));
            } else {
                $user_data = $wpdb->get_row($wpdb->prepare("SELECT ID, user_login, user_pass FROM $table_name WHERE user_login = %s", $username_or_email));
            }
    
            if ($user_data) {
                $dbUsername = $user_data->user_login;
                $dbPassword = $user_data->user_pass;
    
                if (wp_check_password($password, $dbPassword)) {
                    // Set user as logged in
                    $user = wp_signon(array(
                        'user_login'    => $dbUsername,
                        'user_password' => $password,
                        'remember'      => true,
                    ), false);
    
                    if (!is_wp_error($user)) {
                        // Redirect to the profile page after successful login
                        // You may want to set a specific URL for redirection
                        wp_redirect(home_url('/profile'));
                        exit;
                    } else {
                        echo "Error during login";
                    }
                } else {
                    echo "Invalid password";
                }
            } else {
                echo "Invalid username or email";
            }
        }
    

        require event_booking_path . 'public/partials/event-booking-login-display.php';
        return ob_get_clean();
    }
    

 

}

$onload_instance = new Event_Booking_Onload_2();

