<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://https://techytrion.com/
 * @since             1.0.0
 * @package           Event_Booking
 *
 * @wordpress-plugin
 * Plugin Name:       Event Booking
 * Plugin URI:        https://https://wppb.me/
 * Description:       This is a description of the plugin.
 * Version:           1.0.0
 * Author:            Techy Trion
 * Author URI:        https://https://techytrion.com//
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       event-booking
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
define('event_booking_version', '1.0.0' );
define('event_booking_url', plugin_dir_url(__FILE__));
define('event_booking_path', plugin_dir_path(__FILE__));
define('event_booking_plugin', plugin_basename(__FILE__));

class Event_Booking_Plugin {

    public function __construct() {
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
		add_action('admin_menu', array( $this,'calculator_plugin_menu'));
		add_action('init', array( $this,'onload_fuction'));
		add_action('init', array( $this,'create_custom_post'));	
		add_filter('wp_insert_post_data',array( $this,'custom_validate_unique_field'), 10, 3);
		add_action('init', array( $this, 'custom_rewrite_rules'));
		add_filter('query_vars',  array( $this,'custom_query_vars'));
		add_filter('post_type_link',  array( $this,'custom_post_permalink'), 10, 2);	
		add_filter('template_include', array( $this,'load_custom_template'), 10, 2);
		add_filter('template_include', array( $this,'load_reset_template'), 10, 2);
		// add_shortcode('email_function_code',array( $this, 'email_function_code'));
		// add_action('add_meta_boxes',array( $this, 'add_event_city_meta_box'));
		add_action('wp_ajax_vandor_data_call',array( $this, 'vandor_data_call'));
		add_action('wp_ajax_nopriv_vandor_data_call',array( $this, 'vandor_data_call')); 
		//vendor ajax call
		add_action('wp_ajax_custom_logout', array( $this,'custom_logout'));
		add_action('wp_ajax_nopriv_custom_logout', array( $this,'custom_logout'));
		add_action('wp_ajax_event_data_ajax_call',array( $this, 'event_data_ajax_call'));
		add_action('wp_ajax_nopriv_event_data_ajax_call',array( $this, 'event_data_ajax_call')); 
		add_action('wp_ajax_private_attarction_call',array( $this, 'private_attarction_callback'));
		add_action('wp_ajax_nopriv_private_attarction_call',array( $this, 'private_attarction_callback')); 
		add_action( 'template_redirect',array($this, 'my_page_template_redirect') );
		add_filter( 'cron_schedules', array( $this, 'reminder_email_fuction_cron_hook' ) );

        if ( ! wp_next_scheduled( 'reminder_email_fuction_cron_hook' ) ) {
            wp_schedule_event( time(), 'every_five_minutes', 'reminder_email_fuction_cron_hook' );
        }
		// add_shortcode('test_reminder_email_fuction', array( $this,'reminder_email_fuction'));	

        add_action( 'reminder_email_fuction_cron_hook', array( $this, 'reminder_email_fuction' ) );

        require_once plugin_dir_path( __FILE__ ) . 'includes/class-event-booking-activator.php';
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-event-booking-deactivator.php';
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-event-booking.php';
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-event-booking-onload.php';
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-event-booking-onload-2.php';

        $this->run_event_booking();
		
    }

	function my_page_template_redirect() {
		if (is_front_page()  && is_user_logged_in() ) {
		   wp_redirect( '/profile/');
		   exit;
	   }
	}

	public function reminder_email_fuction_cron_hook( $schedules ) {
        $schedules['every_five_minutes'] = array(
                'interval'  => 60 * 5,
                'display'   => __( 'Every 5 Minutes', 'textdomain' )
        );
        return $schedules;
    }

    // Function that will be called every five minutes
	public function reminder_email_fuction() {
		global $wpdb;
		date_default_timezone_set('Asia/Riyadh');
		$registration_data = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}booking_events WHERE (isstatus = %s OR isstatus = %s) AND reminder IS NULL",
				'approved',
				'Approved'
			)
		);

		$today = new DateTime();
		foreach ($registration_data as $registration) {
			$selected_date = new DateTime($registration->selectedDate);
			$current_date = new DateTime('today');

			$post_id = $registration->post_id;
			$language_type= $wpdb->get_results($wpdb->prepare("SELECT language_type FROM {$wpdb->prefix}booking_events WHERE id = %d",$registration->id));
			
			if($language_type){

				if($language_type[0]->language_type == 'arabic'){
						$email_reminders =	get_field("arabic_email_reminders", $post_id);
						$email_reminder_timing =$email_reminders['arabic_email__reminder_timing'];
						$email_reminder_text =$email_reminders['arabic_email_reminder_text'];

				}else{

						$email_reminders =	get_field("email_reminders", $post_id);
						$email_reminder_timing =$email_reminders['email_reminder_timing'];
						$email_reminder_text =$email_reminders['email_reminder_text'];
				
				}

			}else{
						$email_reminders =	get_field("email_reminders", $post_id);
						$email_reminder_timing =$email_reminders['email_reminder_timing'];
						$email_reminder_text =$email_reminders['email_reminder_text'];
			}
			
			// if ($selected_date->format('Y-m-d') === $current_date->format('Y-m-d')) {
				preg_match('/(\d+) (\w+)/', $email_reminder_timing, $matches);

				$numeric_value = (int) $matches[1];
				$unit = $matches[2];
				
				// Convert unit to DateInterval format
				if ($unit === 'minute' || $unit === 'minutes') {
					$interval = 'PT' . $numeric_value . 'M'; // Minutes
				} elseif ($unit === 'hour' || $unit === 'hours') {
					$interval = 'PT' . $numeric_value . 'H'; // Hours
				} elseif ($unit === 'day' || $unit === 'days') {

					   $hours = $numeric_value * 24; // Convert days into hours
    					$interval = 'PT' . $hours . 'H'; // Hours
				}

				$interval = new DateInterval($interval);

				$currentTime = new DateTime();

				$reminderTime = (clone $currentTime)->add($interval);


				$selected_date = new DateTime($registration->selectedDate); 
				$time_formatted = DateTime::createFromFormat('g:i a', $registration->start_event)->format('H:i:s'); 
				$dateTimeString = $selected_date->format('Y-m-d') . ' ' . $time_formatted;
				$startEventTime = new DateTime($dateTimeString);

			

					// Compare the reminder time with the start event time
					// if ($reminderTime->format('H:i:s') >= $startEventTime->format('H:i:s')) {
				if ($reminderTime >= $startEventTime) {
						$to = $registration->email;
						$subject = 'Reminder Email';
						$event_english = get_post_meta($registration->post_id,'event_name_english');
					    $data =array(
								'user_email'=>$registration->email,
								'user_name'=>$registration->fname.' '.$registration->lname,
								'event_name'=>$registration->event_name,
								'event_english_name'=>$event_english[0],
								'time'=>$email_reminder_timing
							);
						foreach ($data as $key => $value) {
								$placeholder = "!$key!";
								if (strpos($email_reminder_text, $placeholder) !== false) {
									$email_reminder_text = str_replace($placeholder, $value, $email_reminder_text);
								}
							}
						$message = $email_reminder_text;

						// Send the email
						if (wp_mail($to, $subject, $message)) {
							$sql = $wpdb->prepare(
								"UPDATE  {$wpdb->prefix}booking_events
								SET reminder = %s
								WHERE id = %d",
								'sent',
								$registration->id
							);
							$result = $wpdb->query($sql);
						}
					} 
			// }

		}

		$log_file = WP_CONTENT_DIR . '/cron.txt';
		$message = 'cron is hit: ' . date('Y-m-d H:i:s') . PHP_EOL;
		file_put_contents($log_file, $message, FILE_APPEND | LOCK_EX);

	}

	
	public function test_reminder_email_fuction() {
		global $wpdb;
		$registration_data = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}booking_events WHERE (isstatus = %s OR isstatus = %s) AND reminder IS NULL",
				'approved',
				'Approved'
			)
		);		
		$today = new DateTime();
	
		foreach ($registration_data as $registration) {
			$selected_date = new DateTime($registration->selectedDate);
			$current_date = new DateTime('today');

			$post_id = $registration->post_id;
			$language_type= $wpdb->get_results($wpdb->prepare("SELECT language_type FROM {$wpdb->prefix}booking_events WHERE id = %d",$registration->id));


			if($language_type){

				if($language_type[0]->language_type == 'arabic'){
						$email_reminders =	get_field("arabic_email_reminders", $post_id);
						$email_reminder_timing =$email_reminders['arabic_email__reminder_timing'];
						$email_reminder_text =$email_reminders['arabic_email_reminder_text'];

				}else{

						$email_reminders =	get_field("email_reminders", $post_id);
						$email_reminder_timing =$email_reminders['email_reminder_timing'];
						$email_reminder_text =$email_reminders['email_reminder_text'];
				
					}

			}else{
						$email_reminders =	get_field("email_reminders", $post_id);
						$email_reminder_timing =$email_reminders['email_reminder_timing'];
						$email_reminder_text =$email_reminders['email_reminder_text'];
			}


			if ($selected_date->format('Y-m-d') === $current_date->format('Y-m-d')) {
		
				preg_match('/(\d+) (\w+)/', $email_reminder_timing, $matches);
				// Extract the numeric value and unit
				$numeric_value = (int) $matches[1];
				$unit = $matches[2];

				if ($unit === 'minute' || $unit === 'minutes') {
					$interval = 'PT' . $numeric_value . 'M'; // Minutes
				} elseif ($unit === 'hour' || $unit === 'hours') {
					$interval = 'PT' . $numeric_value . 'H'; // Hours
				}
				$interval = new DateInterval($interval);
			
				$currentTime = new DateTime();
			
			
				
				$reminderTime = (clone $currentTime)->add($interval);
				$startEventTime = DateTime::createFromFormat('H:i:s', $registration->start_event);
			
				if ($reminderTime->format('H:i:s') >= $startEventTime->format('H:i:s')) {
				
					$to = $registration->email;
					$subject = 'Reminder Email';
					$message = $email_reminder_text;
					if (wp_mail($to, $subject, $message)) {
						$sql = $wpdb->prepare(
							"UPDATE  {$wpdb->prefix}booking_events
							SET reminder = %s
							WHERE id = %d",
							'sent',
							$registration->id
						);
						$result = $wpdb->query($sql);
					}
				} 
			}			
		}
	}
	
	function custom_logout() {

		wp_logout();

		wp_send_json_success(array('message' => 'Logout successful'));
	}
		// Add custom rewrite rules
	 function custom_rewrite_rules() {
		add_rewrite_rule('^events/([^/]+)/([0-9]+)/([^/]+)/?$', 'index.php?post_type=event&event_title=$matches[1]&event_id=$matches[2]&city=$matches[3]', 'top');
		flush_rewrite_rules(); // Flush rewrite rules after adding new rules
	}

	// Add custom query variables
	 function custom_query_vars($vars) {
		$vars[] = 'event_title';
		$vars[] = 'event_id';
		$vars[] = 'city';
		return $vars;
	}

	// Modify post permalink structure
	 function custom_post_permalink($permalink, $post) {
		if ($post->post_type === 'event') {
			$event_id = get_post_meta($post->ID, 'api_event_id', true);
			$event_id = str_replace(' ', '', $event_id); // Remove spaces from event_id
			
			$city = get_post_meta($post->ID, 'city', true);
			$city = str_replace(' ', '', $city); // Remove spaces from city
			$post_slug = sanitize_title($post->post_title);
		
			if ($event_id && $city && $post_slug) {
				$permalink = home_url("events/$post_slug/$event_id/$city");
			}
		}
		return $permalink;
	}

	// Load custom template for single event posts
	 function load_custom_template($template) {
		if (is_singular('event')) {
			$custom_template = plugin_dir_path(__FILE__) . 'public/partials/single-event.php';
			if (file_exists($custom_template)) {
				return $custom_template;
			}
		}
		return $template;
	}

	function load_reset_template($template) {
		if (is_page('reset-password')) {
			$custom_template = plugin_dir_path(__FILE__) . 'public/partials/template-reset-password.php';
			if (file_exists($custom_template)) {
				return $custom_template;
			}
		}
		return $template;
	}

	function activate() {
        Event_Booking_Activator::activate();
    }

    function deactivate() {
        Event_Booking_Deactivator::deactivate();
    }

	function onload_fuction() {
		$onload_instance = new Event_Booking_Onload();
	
	}
	function calculator_plugin_menu() {
		add_menu_page( 
			'Event Booking Setting', 
			'Event Booking Setting', 
			'manage_options', 
			'event_booking_api_setting', 
			array($this, 'event_booking_api_setting_function'),
			'dashicons-media-spreadsheet' 
		);
		
		// Add subpage for booking details
		add_submenu_page(
			'event_booking_api_setting', 
			'Booking Details', 
			'Booking Details', 
			'manage_options', 
			'booking_details', 
			array($this, 'booking_details_function') 
		);
	}
	function event_booking_api_setting_function() {
		require event_booking_path. 'admin/partials/event-booking-admin-api-display.php';
	}
	
	function booking_details_function() {
		require event_booking_path. 'admin/partials/event-booking-details-admin-display.php';
	}

    function run_event_booking() {
        $plugin = new Event_Booking();
        $plugin->run();
    }
	function private_attarction_callback(){

		global $wpdb;

		$selectedDate = $_POST['dataToSend']['selectedDate'];
		$start_event = $_POST['dataToSend']['start_event'];
		$min_person = $_POST['dataToSend']['min_person'];
		$max_person = $_POST['dataToSend']['max_person'];
		// Query to check for matching records
		$query = $wpdb->prepare("
			SELECT *
			FROM {$wpdb->prefix}booking_events
			WHERE selectedDate = %s
			AND start_event = %s
			AND min_person = %d
			AND max_person = %d
		", $selectedDate, $start_event, $min_person, $max_person);

		// Execute the query
		$result = $wpdb->get_results($query);
		// Check if any matching record is found
		if ($result) {
			$response = json_encode(array('match' => true));
			die($response); 
		} else {
			$response = json_encode(array('match' => false));
			die($response); 
		}
	}
	function event_data_ajax_call(){

		if($_POST['call_name']=='save_event_data'){
			global $wpdb;
			parse_str($_POST['formData'], $form_data);

			$charset_collate = $wpdb->get_charset_collate();
			
			$table_name = $wpdb->prefix . 'booking_events';
			
			if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
				// Table doesn't exist, create it
				$sql = "CREATE TABLE $table_name (
					id INT NOT NULL AUTO_INCREMENT,
					event_id INT NOT NULL,
					post_id INT NOT NULL,
					user_id INT NOT NULL,
					event_name VARCHAR(255) NOT NULL,
					fname VARCHAR(255) NOT NULL,
					lname VARCHAR(255) NOT NULL,
					email VARCHAR(255) NOT NULL,
					phone VARCHAR(255) NOT NULL,
					isstatus VARCHAR(255) NOT NULL,
					language_type VARCHAR(255) NOT NULL,
					selectedDate DATE NOT NULL,
					start_event VARCHAR(255) NOT NULL,
					-- end_event TIME NOT NULL,
					min_person INT NOT NULL,
					max_person INT NOT NULL,
					selectedpersons INT NOT NULL,
					otherPersons longtext DEFAULT NULL,
					question_answers longtext DEFAULT NULL,
					reminder varchar(500) NULL ,
					pass_name varchar(500) NULL ,
					additional_note` VARCHAR(255) NULL ,
					PRIMARY KEY (id)
				) $charset_collate;";
			
				require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
				dbDelta($sql);
			}

			// Assuming $form_data contains the necessary data
			$selectedDate = sanitize_text_field($form_data['selectedDate']);
			$start_event = sanitize_text_field($form_data['start_event']);
			// $end_event = sanitize_text_field($form_data['end_event']);
			$min_person = intval($form_data['min_person']);
			$max_person = intval($form_data['max_person']);
			$selectedpersons = intval($form_data['selectedpersons']);
			$event_id = intval($form_data['event_id']);
			$post_id = intval($form_data['post_id']);
			$fname = sanitize_text_field($form_data['fname']);
			$lname = sanitize_text_field($form_data['lname']);
			$email = sanitize_email($form_data['email']);
			$phone = sanitize_text_field($form_data['phone']);
			$language = sanitize_text_field($form_data['language']);
			$pass_name = '';
			if($language == 'arabic'){
				$pass_name = sanitize_text_field($form_data['pass_arabic_name']);
			}else{
				$pass_name = sanitize_text_field($form_data['pass_english_name']);
			}

			$additional_note = sanitize_text_field($form_data['additional_note']);
		    $question_answers = [];
			$otherPersons = [];
			for ($i = 1; $i <= 20; $i++) { 
				$otherFnameKey = "other_fname{$i}";
				$otherLnameKey = "other_lname{$i}";
				$othernamenoteKey = "other_custom_note{$i}";

				$question_anskey = "question_ans{$i}";
		         $question_name = "question_name{$i}";
				if (isset($form_data[$otherFnameKey]) && isset($form_data[$otherLnameKey])) {
					$otherPersons[] = [
						$form_data[$otherFnameKey],
						$form_data[$otherLnameKey],
						$form_data[$othernamenoteKey]
					];
				}
				if (isset($form_data[$question_anskey])) {
					$question_answers[] = [
						$form_data[$question_anskey],
						$form_data[$question_name]
					];
				}
			}
		
			$serializedOtherPersons = serialize($otherPersons);
			$searlizeanswers = serialize($question_answers);

			$dateTime = new DateTime($selectedDate);
			$weekDay = strtolower($dateTime->format('l')); 
			$post_name = '';
			$post = get_post($post_id);
			if ($post) {
				$post_name = $post->post_title;
			}
		
			$dayFieldKey = "time_slots_event_{$weekDay}_time_slot";
			$isstatus ="";
			$repeaterRows = get_field($dayFieldKey, $post_id);
			foreach ($repeaterRows as $key) {
				$start_event_repeater = $key['start_event'];
				// $end_event_repeater = $key['end_event'];
			
				// Convert time strings to DateTime objects
				$start_event_time = DateTime::createFromFormat('g:i a', $start_event_repeater);
				// $end_event_time = DateTime::createFromFormat('g:i a', $end_event_repeater);
			
				// Convert input time strings to DateTime objects
				$start_input_time = DateTime::createFromFormat('g:i a', $start_event);
				// $end_input_time = DateTime::createFromFormat('g:i a', $end_event);
				if ($start_event_time->format('H:i') == $start_input_time->format('H:i')) {
					$isstatus = $key['approval_type'];
			     }
		
				
			}
			// $numPersons = intval($_POST["selectedpersons"]);

			if($isstatus == 'auto'){
				$status = 'Approved';
			}else{
				$status = 'pending-pass-verify';
			}
    
			
			if($language == 'arabic'){
				$username = strstr($email, '@', true);
			}else{
				$username = sanitize_user(strtolower($fname . $lname));
				$suffix = 1;
				while (username_exists($username)) {
					$username = sanitize_user(strtolower($fname . $lname)) . $suffix;
					$suffix++;
				}
			}


            // Check if the user already exists
            if (email_exists($email)) {
				$user_id = email_exists($email);
				update_user_meta($user_id, 'phone_number', $phone);
            } else {
                // Generate a random password
                $password = wp_generate_password();
    
                // Create the user
                $user_id = wp_insert_user(array(
                    'first_name' => $fname,
                    'last_name'  => $lname,
                    'user_login' => $username,
                    'user_pass'  => $password,
                    'user_email' => $email,
                ));
    
                if (is_wp_error($user_id)) {
					$response = array(
						'success' => false,
						'message' => "Error creating user: " . $user_id->get_error_message()
					);
                } else {

                    update_user_meta($user_id, 'phone_number', $phone);

					$user = wp_signon(array(
                        'user_login'    => $username,
                        'user_password' => $password,
                        'remember'      => true,
                    ), false);
					
					$mail_type ="user_registration_mail";
					
					$mail_data =array(
						'email'=>$email,
						// 'cc_emails'=>array($vendor_email),
						'user_name'=>$username,
						'user_email'=>$email,
						'user_password'=>$password,

	
					);
					
					$mail_result = send_booking_mail($mail_type,$mail_data);
					if (!$mail_result) {
						$response = array(
							'success' => false,
							'message' => $mail_result
						);
					} else {
						$mail_type ="new_user_registration_mail";
						$fields = get_field('admin_details', 'option');
						$admin_email= $fields['admin_email'] ?? '';
						
					
						$mail_data =array(
							'email'=>$admin_email,
							// 'cc_emails'=>array($vendor_email),
							'user_name'=>$username,
							'user_email'=>$email,
							
	
		
						);
						$mail_result = send_booking_mail($mail_type,$mail_data);
						if (!$mail_result) {
							$response = array(
								'success' => false,
								'message' => $mail_result
							);
						}else{
							$response = array(
								'success' => true,
								'message' => 'تم تحديث الحالة بنجاح'
							);

						} 
					}
                   
                } 
            }

			$event_english = get_post_meta($post_id,'event_name_english');
			// Create the $data array for insertion
			$data = array(
				'isstatus' => $status, // You can set the default status or change it based on your requirements
				'language_type' => $language, // You can set the default status or change it based on your requirements
				'selectedDate' => $selectedDate,
				'start_event' => $start_event,
				'min_person' => $min_person,
				'max_person' => $max_person,
				'selectedpersons' => $selectedpersons,
				'otherPersons' => $serializedOtherPersons,
				'event_id' => $event_id,
				'post_id' => $post_id,
				'user_id' => $user_id,
				'event_name' => $post_name,
				'fname' => $fname,
				'lname' => $lname,
				'email' => $email,
				'phone' => $phone,
				'pass_name' => $pass_name,
				'additional_note'=>$additional_note,
				'question_answers' => $searlizeanswers,
			);

			if($language == 'arabic'){
				if($status == 'Approved'){
					$bookstatus = 'مؤكد';
				}
				if($status == 'pending-pass-verify'){
					$bookstatus = 'في انتظار التحقق من التصريح';
				}
			}else{
				$bookstatus = $status;
			}

			$selectedDateStr= new DateTime($selectedDate);
			$selectedDateformet= $selectedDateStr->format("l, d F ");

			if($language == 'arabic'){ 
				$MONTHS = array('يناير','فبراير ','مارس ','أبريل','مايو','يونيو ','يوليو','أغسطس','سبتمبر ','أكتوبر ','نوفمبر ','ديسمبر ');
				$DAYS = array('الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت');
				$english_months = array('January','February','March','April','May','June','July','August','September','October','November','December');
				$english_days = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
				$date_parts = explode(", ", $selectedDateformet);
				$english_day = $date_parts[0];
				$date_month_parts = explode(" ", $date_parts[1]);
				$english_month = $date_month_parts[1];
				$english_day_index = array_search($english_day, $english_days);
				$arabic_day = $DAYS[$english_day_index];
				$english_month_index = array_search($english_month, $english_months);
				$arabic_month = $MONTHS[$english_month_index];
				$selectedDateformet = $arabic_day . " , " . $date_month_parts[0] . " " . $arabic_month . " " . $date_month_parts[2];

				$time_arabic = str_replace(["pm", "am"], ["مساء","صباح"], $start_event);
			}else{
				$time_arabic = $data['start_event'];
			}

			$senddata = array(
				'isstatus' => $bookstatus, // You can set the default status or change it based on your requirements
				'language_type' => $language, // You can set the default status or change it based on your requirements
				'selectedDate' => $selectedDateformet,
				'start_event' => $time_arabic,
				'event_english_name'=>$event_english[0],
				'min_person' => $min_person,
				'max_person' => $max_person,
				'selectedpersons' => $selectedpersons,
				'otherPersons' => $serializedOtherPersons,
				'event_id' => $event_id,
				'post_id' => $post_id,
				'user_id' => $user_id,
				'event_name' => $post_name,
				'fname' => $fname,
				'lname' => $lname,
				'email' => $email,
				'phone' => $phone,
				'pass_name' => $pass_name,
				'additional_note'=>$additional_note,
				'question_answers' => $searlizeanswers,
			);

			// print_r($data); die;
			// Insert data into the table
		     $wpdb->insert($wpdb->prefix . 'booking_events', $data);
			// Get the ID of the inserted row
			$inserted_id = $wpdb->insert_id;
		
			if($inserted_id){
				$post_id = $data['post_id']; 
				$post_title = get_the_title($post_id);
				$vendor_user_id = get_field('vendor',$post_id);
				$vendor_info = get_userdata($vendor_user_id);
				$event_name_english = get_post_meta($post_id,'event_name_english');
				$username = $data['fname'] . ' ' . $data['lname'];
				$vendor_email = '';
				if ($vendor_info) {
					$vendor_email = $vendor_info->user_email;
				
				} 

				if($isstatus == 'auto'){
					if($language == 'arabic'){
						$mail_type ="arebic_booking_sucessfull_auto_approval_mail";
					}else{
						$mail_type ="booking_sucessfull_auto_approval_mail";
					}
				}else{
					if($language == 'arabic'){
						$mail_type ="arebic_booking_sucessfull_manual_approval_mail";
					}else{
						$mail_type ="booking_sucessfull_manual_approval_mail";
					}
				}
					
								
				$selectedDateStr= new DateTime($data['selectedDate']);
				$selectedDateformet= $selectedDateStr->format("l, d F ");

				if($language == 'arabic'){ 
					$MONTHS = array('يناير','فبراير ','مارس ','أبريل','مايو','يونيو ','يوليو','أغسطس','سبتمبر ','أكتوبر ','نوفمبر ','ديسمبر ');
					$DAYS = array('الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت');
					$english_months = array('January','February','March','April','May','June','July','August','September','October','November','December');
					$english_days = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
					$date_parts = explode(", ", $selectedDateformet);
					$english_day = $date_parts[0];
					$date_month_parts = explode(" ", $date_parts[1]);
					$english_month = $date_month_parts[1];
					$english_day_index = array_search($english_day, $english_days);
					$arabic_day = $DAYS[$english_day_index];
					$english_month_index = array_search($english_month, $english_months);
					$arabic_month = $MONTHS[$english_month_index];
					$selectedDateformetted = $arabic_day . " , " . $date_month_parts[0] . " " . $arabic_month . " " . $date_month_parts[2];

					$time_arabic = str_replace(["pm", "am"], ["مساء","صباح"], $data['start_event']);
				}else{
					$selectedDateformetted = $selectedDateformet;
					$time_arabic = $data['start_event'];
				}

				$mail_data =array(
					'email'=>$email,
					// 'cc_emails'=>array($vendor_email),
					'event_name'=>$post_title,
					'event_english_name'=>$event_name_english[0],
					'user_name'=>$username,
					'user_email'=>$email,
					'selectedpersons'=>$selectedpersons,
					'user_phone'=>$data['phone'],
					'event_status'=>$bookstatus,
					'selected_date'=>$selectedDateformetted,
					'start_time'=>$time_arabic,
					'pass_name'=>$pass_name,
					'note'=>$additional_note
				);
				
				$mail_result = send_booking_mail($mail_type,$mail_data);
				if (!$mail_result) {
					$response = array(
						'success' => false,
						'message' => $mail_result
					);
				} else {
					if($isstatus == 'auto'){
						$mail_type ="admin_booking_sucessfull_auto_approval_mail";
					}else{
						$mail_type ="admin_booking_sucessfull_manual_approval_mail";
					}
					$fields = get_field('admin_details', 'option');
					$admin_email= $fields['admin_email'] ?? '';
					
				
					$mail_data =array(
						'email'=>$admin_email,
						// 'cc_emails'=>array($vendor_email),
						'event_name'=>$post_title,
						'event_english_name'=>$event_name_english[0],
						'user_name'=>$username,
						'selectedpersons'=>$selectedpersons,
						'user_email'=>$email,
						'user_phone'=>$data['phone'],
						'event_status'=>$status,
						'selected_date'=>$selectedDateformet,
						'start_time'=>$data['start_event'],
						'pass_name'=>$pass_name,
						'note'=>$additional_note
					);
					$mail_result = send_booking_mail($mail_type,$mail_data);
					$mail_data =array(
						'email'=>$vendor_email,
						// 'cc_emails'=>array($vendor_email),
						'event_name'=>$post_title,
						'event_english_name'=>$event_name_english[0],
						'user_name'=>$username,
						'selectedpersons'=>$selectedpersons,
						'user_email'=>$email,
						'user_phone'=>$data['phone'],
						'event_status'=>$status,
						'selected_date'=>$selectedDateformet,
						'start_time'=>$data['start_event'],
						'pass_name'=>$pass_name,
						'note'=>$additional_note
					);
					$mail_result = send_booking_mail($mail_type,$mail_data);
					if (!$mail_result) {


						$response = array(
							'success' => false,
							'message' => $mail_result
						);
					}else{
						$response = array(
							'success' => true,
							'message' =>$senddata 
						);
					}
				}
			} else {
				print_r($response); die;
			$response = array(
				'success' => false,
				'message' => 'فشل تقديم النموذج. الرجاء معاودة المحاولة في وقت لاحق.'
			);
			}
		}else{
			$response = array(
				'success' => false,
				'message' => 'فشل تقديم النموذج. الرجاء معاودة المحاولة في وقت لاحق.'
			);
		}

		$json = json_encode($response); 
		echo $json;
		die;
	
	}

	function create_custom_post(){
	
		if (!post_type_exists('event')) {
			register_post_type('event', array(
				'labels' => array(
					'name' => __('Attraction'),
					'singular_name' => __('Event'),
				),
				'public' => true,
				'has_archive' => true,
				'rewrite' => array('slug' => 'events'),
				'supports' => array('title', 'editor', 'custom-fields', 'thumbnail', 'featured_image', 'excerpt'),
			));
			
		}

		if (is_admin() && isset($_GET['post_type']) && $_GET['post_type'] === 'event' && basename($_SERVER['PHP_SELF']) === 'edit.php') {

			$args = array(
				'post_type'      => 'event',
				'post_status'    => 'draft',
				'posts_per_page' => -1, // Retrieve all posts
			);
			
			$query = new WP_Query( $args );
			
			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
					$query->the_post();
					$post_id = get_the_ID();
					$current_city_name = get_field('event_city', $post_id);
					$current_excursion_name_en = get_field('event_name_english', $post_id);
					$current_excursion_ID = get_field('event_api_id', $post_id);

					// Check if $city_name is null or empty
						if (empty($city_name) && empty($current_city_name) && empty($excursion_name_en) && empty($current_excursion_name_en) && empty($excursion_ID) && empty($current_excursion_ID)) {
							wp_delete_post( $post_id, true );
						}

				}
				wp_reset_postdata();
			} 
		} 
		// $api_url =get_option('api_url');// 'https://sightscape.com/API/booking_system_API.php';
		// $auth_key =get_option('api_key'); //'c37e2cf8241123dc716a18c97f74c685dd2731132d6b72950d20f022c97fcceb';
		// $api_response = validate_api_credentials($api_url, $auth_key);
		// // echo"<pre>";print_r($api_response);die;
		
		// if ($api_response && $api_response['success']) {
		// 	$excursions_data = $api_response['data']['data']['city'];
			
		// // Loop through cities and excursions
		// 		foreach ($excursions_data as $city_data) {
		// 			$city_name = $city_data['name_ar'];
					
		// 			foreach ($city_data['excursions'] as $excursion) {
		// 				$excursion_name = $excursion['name_ar'];
		// 				$excursion_name_en = $excursion['name_en'];
		// 				$excursion_ID = $excursion['exc_id'];
		// 				$excursion_Slug = sanitize_title($excursion_name_en).'/'.$city_name.'/'.$excursion_ID; 
						
		// 				// Check if event_api_id already exists in any post
		// 				$existing_post_with_api_id = get_posts(array(
		// 					'post_type' => 'event',
		// 					'meta_query' => array(
		// 						array(
		// 							'key' => 'event_api_id',
		// 							'value' => $excursion_ID,
		// 							'compare' => '='
		// 						)
		// 					),
		// 					'posts_per_page' => 1, // Set to 1 to minimize database load, as we only need to know if any post exists
		// 					'fields' => 'ids', // Only retrieve post IDs to minimize database load
		// 				));

		// 				if ($existing_post_with_api_id) {
		// 					// Skip creating a new post if event_api_id already exists in any post
		// 					continue;
		// 				}
						
		// 				// Create new post
		// 				$event_post = array(
		// 					'post_title' => $excursion_name,
		// 					'post_name' => $excursion_Slug,
		// 					'post_type' => 'event',
		// 					'post_status' => 'publish',
		// 				);

		// 				// Insert post
		// 				$post_id = wp_insert_post($event_post);

		// 				// Add city as post meta and update event_api_id field
		// 				if ($post_id) {
		// 					// Add city as post meta
		// 					update_field('event_city', $city_name, $post_id);

		// 					// Update event_api_id field
							
		// 					update_field('event_name_english', $excursion_name_en, $post_id);
		// 					update_field('event_api_id', $excursion_ID, $post_id);
		// 				}
		// 			}
		// 		}

		// }
	
	}
	function custom_validate_unique_field($data, $postarr, $unsanitized_postarr) {

		if ($data['post_type'] == 'event') {
			$event_api_id = isset($postarr['acf']['field_65c4d880fbc7c']) ? $postarr['acf']['field_65c4d880fbc7c'] : '';
			if (!empty($event_api_id)) {
				$existing_posts = get_posts(array(
					'post_type' => 'event',
					'meta_query' => array(
						array(
							'key' => 'event_api_id',
							'value' => $event_api_id,
						),
					),
				));
	
				if (empty($existing_posts)) {

					$city_name = $postarr['acf']['field_65c4d878fbc7b'];
					$excursion_name_en = $postarr['acf']['field_65d34c526e277'];
					$excursion_ID = $postarr['acf']['field_65c4d880fbc7c'];
					$excursion_Slug = sanitize_title($excursion_name_en.'/'.$city_name.'/'.$excursion_ID); 
					$data['post_name'] = $excursion_Slug;
	
				} else {

					if($postarr['original_post_status'] == 'auto-draft'){
						$redirect_url = admin_url('post-new.php?post_type=event'); // Adjust 'event' to your custom post type slug
						wp_redirect($redirect_url);
						exit;
					}
				}
			}
		}


		return $data;
	}
	
	function vandor_data_call(){
		global $wpdb;
		if (isset($_POST['call_name']) && $_POST['call_name'] === 'edit_event') {
		
			$postId = isset($_POST['event_id']) ? intval($_POST['event_id']) : 0;
			if (function_exists('get_field')) {
				$daysOfWeek = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');

				// Array to store the week's values
				$time_slots_data = array();
				$lead_time = get_field('lead_time', $postId);
				$max_lead_time= $lead_time['maximum_lead_time'] ?? '';
				$min_lead_time= $lead_time['minimum_lead_time'] ?? '';
				
				// Loop through each day of the week
				foreach ($daysOfWeek as $day) {
					// Construct repeater field name based on the day
					$repeaterField = "time_slots_event_{$day}_time_slot";
				
					// Retrieve ACF repeater values for the specified post and day
					$repeaterRows = get_field($repeaterField, $postId);
				
					// Initialize an array to store time slot data for the day
					$dayValues = array();
				
					if ($repeaterRows) {
						// Loop through each row of the repeater
						foreach ($repeaterRows as $key => $row) {
							// Retrieve values from each row with keys 0 and 1
							$avaliable = $row["avaliable"];
							$minPerson = $row["min_person"];
							$maxPerson = $row["max_person"];
							$startEvent = $row["start_event"];
							$approval_type = $row["approval_type"];
							
							// $endEvent = $row["end_event"];
				
							// Store values for the time slot in the dayValues array
							$dayValues[] = array(
								'avaliable' => $avaliable,
								'min_person' => $minPerson,
								'max_person' => $maxPerson,
								'start_event' => $startEvent,
								'approval_type'=>$approval_type,
								// 'end_event' => $endEvent,
							);
						}
					}
				
					// Store time slot data for the day in the weekValues array
					$time_slots_data[$day] = $dayValues;
				}
				$time_slots_data['lead_time']= array(
					'max_lead_time' => $max_lead_time,
					'min_lead_time' => $min_lead_time,
				);
			   
				// $time_slots_data = get_field('time_slots_event', $event_id);
				// echo "<pre>";print_r($time_slots_data);
				if($time_slots_data){
					$response = array(
						'success' => true,
						'message' => $time_slots_data
					);
				}else{
					$response = array(
						'success' => false,
						'message' => 'لاتوجد بيانات'
					);
				}
			}else{
				$response = array(
					'success' => false,
					'message' => 'حدث خطأ ما'
				);
			}
		}elseif(isset($_POST['call_name']) && $_POST['call_name'] === 'save_event_slot_data'){ 
			parse_str($_POST['formData'], $formData);
			$post_id = $_POST['event_id_edit'];

			// Get the new repeater data
			$new_repeater_data = $formData['repeater_data'];
			// $leadtime = $formData['repeater_data'];
			
			$minimum_lead_time = isset($formData['minimum_lead_time']) ? $formData['minimum_lead_time'] : '';
			$maximum_lead_time = isset($formData['minimum_lead_time']) ? $formData['maximum_lead_time'] : '';
			$minimum_lead_time =  $minimum_lead_time.' hour';
			$maximum_lead_time = $maximum_lead_time.' day';
		
			$minimum_lead_time = update_field('lead_time_minimum_lead_time', $minimum_lead_time, $post_id);
			$maximum_lead_time = update_field('lead_time_maximum_lead_time', $maximum_lead_time, $post_id);
			
			// Weekday names
			$daysOfWeek = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');
			foreach ($daysOfWeek as $day) {
				// Construct the ACF field key for the day
				$dayFieldKey = "time_slots_event_{$day}_time_slot";
			
				// Get the new data for this day
				$dayData = $new_repeater_data[$day];
			
				// Initialize an array to store the rows for this day
				$rows = array();
			
				// Check if the day data is an array
				if (is_array($dayData)) {
					// Iterate over each time slot for this day
					foreach ($dayData as $timeSlot) {
						// Extract time slot values
						$avaliable = isset($timeSlot['avaliable']) ? $timeSlot['avaliable'][0] : '';
						$minPerson = isset($timeSlot['min_person']) ? $timeSlot['min_person'][0] : '';
						$maxPerson = isset($timeSlot['max_person']) ? $timeSlot['max_person'][0] : '';
						$startEvent = isset($timeSlot['start_event']) ? $timeSlot['start_event'][0] : '';
						$approval_type = isset($timeSlot['approval_type']) ? $timeSlot['approval_type'][0] : '';
						
						// $endEvent = isset($timeSlot['end_event']) ? $timeSlot['end_event'][0] : '';
			
						// Construct a row array with time slot values
						$row = array(
							'avaliable' => $avaliable,
							'min_person' => $minPerson,
							'max_person' => $maxPerson,
							'start_event' => $startEvent,
							'approval_type' => $approval_type,
							// 'end_event' => $endEvent
						);
			
						// Add the row to the rows array
						$rows[] = $row;
					}
				}
				
				$result=update_field($dayFieldKey, $rows, $post_id);
			}
		
	
				$response = array(
					'success' => true,
					'message' => 'تم تحديث البيانات بنجاح'
				);
	    }elseif(isset($_POST['call_name']) && $_POST['call_name'] === 'event_register_data'){ 
				$post_id = $_POST['event_id_edit'];
				
			
				$registration_data = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}booking_events WHERE post_id = %d", $post_id));

				if (!empty($registration_data)) {
					$response = array(
						'success' => true,
						'message' => $registration_data // Decode HTML entities before sending the response
					);
				} else {
					$response = array(
						'success' => false,
						'message' => 'لم يتم العثور على نتائج'
					);
				}
		}elseif(isset($_POST['call_name']) && $_POST['call_name'] === 'selectedpersons_details'){ 
			$booking_id = $_POST['booking_id'];
			$registration_data = $wpdb->get_results($wpdb->prepare("SELECT otherPersons, fname, lname, additional_note FROM {$wpdb->prefix}booking_events WHERE id = %d", $booking_id));
			$otherPersons = array();
		
			// Add primary guest information
			$primaryGuest = array(
				'name' => $registration_data[0]->fname . ' ' . $registration_data[0]->lname . ' (Primary Guest)',
				'additional_note' => $registration_data[0]->additional_note
			);
			$otherPersons[] = $primaryGuest;
		
			// Add additional guests information
			$otherpersondata = unserialize($registration_data[0]->otherPersons);

			foreach ($otherpersondata as $names) {
				$otherpersonNames = '';
				$firtname = '';
				$familyname = '';
				$note = '';
				$length = count($names);

				if($names[0]){
					$firtname = $names[0];
				}
				if($names[1]){
					$familyname = $names[1];
				}
				if($length > 2){
					if($names[2]){
						$note = $names[2];
					}
				}
				$otherpersonNames = $firtname . ' '. $familyname;
				$additionalGuest = array(
					'name' => $otherpersonNames,
					'additional_note' => $note // You may need to fetch additional notes for additional guests from the database
				);
				$otherPersons[] = $additionalGuest;
			}
		
				if (is_array($otherPersons) && !empty($otherPersons)) {
					$response = array(
						'success' => true,
						'message' => $otherPersons // Decode HTML entities before sending the response
					);
				} else {
					$response = array(
						'success' => false,
						'message' => 'لم يتم العثور على نتائج'
					);
				}
			


		}elseif(isset($_POST['call_name']) && $_POST['call_name'] === 'editbooking_details'){ 
			$booking_id = $_POST['booking_id'];
			$booking_data = $wpdb->get_results($wpdb->prepare("SELECT selectedDate, start_event FROM {$wpdb->prefix}booking_events WHERE id = %d", $booking_id));
			
		
			if (is_array($booking_data) && !empty($booking_data)) {
				$response = array(
					'success' => true,
					'message' => $booking_data // Decode HTML entities before sending the response
				);
			} else {
				$response = array(
					'success' => false,
					'message' => 'لم يتم العثور على نتائج'
				);
			}


		}elseif(isset($_POST['call_name']) && $_POST['call_name'] === 'updatebooking_details'){ 
			$booking_id = $_POST['booking_id'];
			$booking_date = $_POST['booking_date'];
			$booking_time = $_POST['booking_time'];
			global $wpdb;
			$table_name = $wpdb->prefix . 'booking_events';
			$booking_data = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}booking_events WHERE id = %d", $booking_id));
			
			if (is_array($booking_data) && !empty($booking_data)) {
				$sql = $wpdb->prepare(
					"UPDATE $table_name
					SET selectedDate = %s, start_event = %s
					WHERE id = %d",
					$booking_date,
					$booking_time,
					$booking_id
				);

				$wpdb->query($sql);

				$response = array(
					'success' => true,
					'message' => "Updated"
				);

			} else {
				$response = array(
					'success' => false,
					'message' => 'Data not updated'
				);
			}


		}elseif(isset($_POST['call_name']) && $_POST['call_name'] === 'update_user_status'){ 
		// }elseif(isset($_POST['call_name']) && $_POST['call_name'] === 'update_user_status'){                                                                                                                        '){ 
			$booking_id =  $_POST['booking_id']; 
			global $wpdb;
			$table_name = $wpdb->prefix . 'booking_events';
			$registration_data = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}booking_events WHERE id = %d", $booking_id));
		
			$start_event =$registration_data[0]->start_event;
			$start_event_admin =$registration_data[0]->start_event;
			$selectedDate =$registration_data[0]->selectedDate;
			$language =$registration_data[0]->language_type;
			$phone =$registration_data[0]->phone;
			$selectedpersons =$registration_data[0]->selectedpersons;
			$additional_note =$registration_data[0]->additional_note;

			$user_id =  $_POST['user_id'];
			$user_info = get_userdata($user_id);
			if ($user_info) {
				$user_email = $user_info->user_email;
				$user_name = $user_info->user_login;
			
			} 
			
			$post_id =$_POST['post_id']; 
			$post_title = get_the_title($post_id);
			$event_name_english = get_post_meta($post_id,'event_name_english');
			$vendor_user_id = get_field('vendor',$post_id);
			$new_status =  $_POST['status'];
			if($new_status == 'Canceled'){
				$new_status = 'cancel-not-avaliable';
			}
			$post_title = get_the_title($post_id);
			$vendor_info = get_userdata($vendor_user_id);
			
			$vendor_email="";

			if ($vendor_info) {
				$vendor_email = $vendor_info->user_email;
			
			} 
			if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name) {
				// Table exists, update the status
				$sql = $wpdb->prepare(
					"UPDATE $table_name
					SET isstatus = %s
					WHERE id = %d",
					$new_status,
					$booking_id
				);
				
					$result = $wpdb->query($sql);
				
					$bookstatus = '';
					if ($result !== false) {

						if(strtolower($new_status) =='approved'){
							if($language == 'arabic'){
								$mail_type ="arebic_booking_approved_mail";
								$bookstatus = 'مؤكد';
							}else{
								$mail_type ="booking_approved_mail";
								$bookstatus = 'Approved';
							}
						}elseif(strtolower($new_status) =='pending-pass-verify'){
							if($language == 'arabic'){
								$mail_type ="arebic_booking_pending_mail";
								$bookstatus = 'في انتظار التحقق من اجتياز الملكية';
							}else{
								$mail_type ="booking_pending_mail";
								$bookstatus = 'Pending verification of pass ownership';
							}
						}elseif(strtolower($new_status) =='cancel-not-avaliable'){
							if($language == 'arabic'){ 
								$mail_type ="arebic_booking_cancel_mail";
								$bookstatus = 'تم الإلغاء لأن الفتحة غير متوفرة';
							}else{
								$mail_type ="booking_cancel_mail";
								$bookstatus = 'Canceled because the slot is unavailable';
							}
						}elseif(strtolower($new_status) =='cancel-no-pass'){
							if($language == 'arabic'){ 
								$mail_type ="arebic_booking_cancel_no_pass_mail";
								$bookstatus = 'تم الإلغاء ليس لديك تصريح';
							}else{
								$mail_type ="booking_cancel_no_pass_mail";
								$bookstatus = 'Canceled You do not have a pass';
							}
						}

						$selectedDateStr= new DateTime($selectedDate);
						$selectedDateformet= $selectedDateStr->format("l, d F Y");
						if($language == 'arabic'){ 
							$MONTHS = array('يناير','فبراير ','مارس ','أبريل','مايو','يونيو ','يوليو','أغسطس','سبتمبر ','أكتوبر ','نوفمبر ','ديسمبر ');
							$DAYS = array('الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت');
							$english_months = array('January','February','March','April','May','June','July','August','September','October','November','December');
							$english_days = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
							$date_parts = explode(", ", $selectedDateformet);
							$english_day = $date_parts[0];
							$date_month_parts = explode(" ", $date_parts[1]);
							$english_month = $date_month_parts[1];
							$english_day_index = array_search($english_day, $english_days);
							$arabic_day = $DAYS[$english_day_index];
							$english_month_index = array_search($english_month, $english_months);
							$arabic_month = $MONTHS[$english_month_index];
							$selectedDateformet = $arabic_day . " , " . $date_month_parts[0] . " " . $arabic_month . " " . $date_month_parts[2];
							$start_event = str_replace(["pm", "am"], ["مساء","صباح"], $start_event);
						}
						if(strtolower($new_status) != 'pending-to-attraction'){

							$mail_data =array(
								'email'=>$user_email,
								'user_name'=> $user_name,
								'user_email'=>$user_email,
								'user_phone'=>$phone,
								'selectedpersons'=>$selectedpersons,
								'event_status'=>$bookstatus,
								'event_name'=>$post_title,
								'event_english_name'=>$event_name_english[0],
								'selected_date'=>$selectedDateformet,
								'start_time'=>$start_event,
								'note'=> $additional_note
			
							);
							
							$mail_result = send_booking_mail($mail_type,$mail_data);
							if (!$mail_result) {
								$response = array(
									'success' => false,
									'message' => $mail_result
								);
							}
						}

						$fields = get_field('admin_details', 'option');
						$admin_email= $fields['admin_email'] ?? '';
					
						if(strtolower($new_status)=='approved'){
							$mail_type ="admin_booking_approved_mail";
							$bookstatus = 'Approved';
						}elseif(strtolower($new_status)=='pending-pass-verify'){
							$mail_type ="admin_booking_pending_mail";
							$bookstatus = 'Pending verification of pass ownership';
						}elseif(strtolower($new_status)=='pending-to-attraction'){
							$mail_type ="admin_booking_pending_to_attraction_mail";
							$bookstatus = 'Pending attraction availability approval';
						}elseif(strtolower($new_status)=='cancel-not-avaliable'){
							$mail_type ="admin_booking_cancel_mail";
							$bookstatus = 'Canceled because the slot is unavailable';
						}elseif(strtolower($new_status)=='cancel-no-pass'){
							$mail_type ="admin_booking_cancel_no_pass_mail";
							$bookstatus = 'Canceled You do not have a pass';
						}

						$mail_data =array(
							'email'=>$admin_email,
							'user_name'=> $user_name,
							'event_english_name'=>$event_name_english[0],
							'user_email'=>$user_email,
							'user_phone'=>$phone,
							'selectedpersons'=>$selectedpersons,
							// 'cc_emails'=>array($vendor_email),
							'event_status'=>$bookstatus,
							'event_name'=>$post_title,
							'selected_date'=>$selectedDate,
							'start_time'=>$start_event_admin,
							'note'=> $additional_note
						);
						
						$mail_result = send_booking_mail($mail_type,$mail_data);

						$mail_data =array(
							'email'=>$vendor_email,
							'user_name'=> $user_name,
							'event_english_name'=>$event_name_english[0],
							'user_email'=>$user_email,
							'user_phone'=>$phone,
							'selectedpersons'=>$selectedpersons,
							// 'cc_emails'=>array($vendor_email),
							'event_status'=>$bookstatus,
							'event_name'=>$post_title,
							'selected_date'=>$selectedDate,
							'start_time'=>$start_event_admin,
							'note'=> $additional_note
		
						);

						if(strtolower($new_status)=='approved'){
							$mail_type ="admin_booking_approved_mail";
							$bookstatus = 'Approved';
							$mail_result = send_booking_mail($mail_type,$mail_data);
						}elseif(strtolower($new_status)=='pending-to-attraction'){
							$mail_type ="admin_booking_pending_to_attraction_mail";
							$bookstatus = 'Pending attraction availability approval';
							$mail_result = send_booking_mail($mail_type,$mail_data);
						}elseif(strtolower($new_status)=='cancel-not-avaliable'){
							$mail_type ="admin_booking_cancel_mail";
							$bookstatus = 'Canceled because the slot is unavailable';
							$mail_result = send_booking_mail($mail_type,$mail_data);
						}

						if (!$mail_result) {
							$response = array(
								'success' => false,
								'message' => $mail_result
							);
						} else {
							$response = array(
								'success' => true,
								'message' => 'تم تحديث الحالة بنجاح'
							);
						}
						
					} else {
					
						// Query execution failed
						$response = array(
							'success' => false,
							'message' => $wpdb->last_error // Provide more detailed error information
						);

					}

			}else{
				$response = array(
					'success' => false,
					'message' => 'الطلب فشل '
				);
			}
				
		}else{
			$response = array(
				'success' => false,
				'message' => 'الطلب فشل '
			);
		}
	
		$json = json_encode($response); 
		echo $json;
		die;
	}

	
	
}
$event_booking_plugin = new Event_Booking_Plugin();

function validate_api_credentials($api_url, $api_key) {
    $data = array(
        'action' => 'get_all_excursions'
    );

    $headers = array(
        'Content-Type: application/x-www-form-urlencoded'
    );
	// echo $api_key;
    $url = $api_url . '?AUTH_KEY=' . $api_key;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
	$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE); // Get HTTP response code
	curl_close($ch);

	// var_dump($response);

	if ($response === false || $http_code !== 200) {
		return false; // API request failed or returned non-200 status code
	} else {
		$json_response = json_decode($response, true);

		if(isset($json_response['response']) && $json_response['response'] === 'FAIL') {
			return array('success' => false, 'message' => 'API request failed: '.$json_response['error']); // API response indicates failure
		} else {
			return array('success' => true, 'data' => $json_response); // API request successful
		}
	}

}
function send_booking_mail($mail_type, $data) {
    // Validate parameters
    if (empty($mail_type) || empty($data) || !is_array($data)) {
        return; // or throw an error
    }

    // Retrieve fields from options
    $fields = get_field($mail_type, 'option');
    if (!$fields) {
        echo "No template found";
        return;
    }

    // Extract email content from fields
    $subject = $fields[$mail_type . '_subject'] ?? '';
    $message = $fields[$mail_type . '_message'] ?? '';

    if (empty($subject) || empty($message)) {
        echo "Subject or message not found in template";
        return;
    }

    // Replace placeholders in the message
	foreach ($data as $key => $value) {
		$placeholder = "!$key!";
		if (strpos($message, $placeholder) !== false) {
			$message = str_replace($placeholder, $value, $message);
		}
	}
	$mail_result=0;
	$to = $data['email'] ?? '';
	if(!empty($to)){
			$cc_recipients = $data['cc_emails'] ?? [];
	
			$headers = array(
			    'Content-Type: text/html; charset=UTF-8'
			);

			if (!empty($cc_recipients)) {
				$cc_recipients_string = implode(', ', $cc_recipients);
			    $headers[] = 'Cc:'.$cc_recipients_string;
			}

			$mail_result = wp_mail($to, $subject, $message, $headers);   
		   
	}


    
    return $mail_result;
}
function get_persons_value($post_id){
    	$min_values = array(); 
		$max_values = array();
	
			$daysOfWeek = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');
			foreach ($daysOfWeek as $day) {
				$repeaterField = "time_slots_event_{$day}_time_slot";
				$repeaterRows = get_field($repeaterField,$post_id);
				
				if ($repeaterRows) {
					foreach ($repeaterRows as $key => $row) {
						if($row['avaliable']){
							$avalibility = $row['avaliable'][0]; // Accessing the first element directly
							
							if ($avalibility == 'yes' && $row['min_person'] !== '' && $row['max_person'] !== '') {
								
								if ($row['min_person'] !== null && $row['min_person'] !== '') {
									
									$min_values[] = intval($row['min_person']);   
								}
								$max_values[] = intval($row['max_person']);
							}
						}
					}
				}
			}
			if (!empty($max_values) && !empty($min_values)) {
				$min_value = min($min_values);
				$max_value = max($max_values);
				return array( 'min_value' => $min_value, 'max_value' => $max_value );
		     }
	
	
		
	
}
function dd($data){
 echo "<pre>";
 print_r($data);
}

function reset_password_ajax_handler() {
    // Get the email from the AJAX request
    $email = sanitize_email($_POST['email']);

    // Check if the email exists in the WordPress users
    $user = get_user_by('email', $email);

    if ($user) {
        // Generate a unique key for password reset
        $key = wp_generate_password(20, false);

        // Update user's meta with the reset key
        update_user_meta($user->ID, 'reset_password_key', $key);

        // Generate the reset password link
        $reset_link = site_url("/reset-password?key={$key}&email={$email}");

        // Send the password reset email
        $subject = 'Password Reset';
        $message = "Click the following link to reset your password: $reset_link";
        wp_mail($email, $subject, $message);

        echo json_encode(array('status' => 'success', 'message' => 'Password reset link sent successfully.'));
    } else {
        echo json_encode(array('status' => 'error', 'message' => 'Email not found.'));
    }

    // Make sure to exit
    wp_die();
}

add_action('wp_ajax_reset_password', 'reset_password_ajax_handler');
add_action('wp_ajax_nopriv_reset_password', 'reset_password_ajax_handler');


// AJAX callback function for updating the password
function update_password_ajax_handler() {
    // Get the parameters from the AJAX request
    $key = sanitize_text_field($_POST['key']);
    $email = sanitize_email($_POST['email']);
    $new_password = sanitize_text_field($_POST['new_password']);

    // Validate the reset key and email
    $user = get_user_by('email', $email);

    if ($user && get_user_meta($user->ID, 'reset_password_key', true) === $key) {
        // Reset the password
        wp_set_password($new_password, $user->ID);

        // Remove the reset key from user meta
        delete_user_meta($user->ID, 'reset_password_key');

        echo json_encode(array('status' => 'success', 'message' => 'Password updated successfully.'));
    } else {
        echo json_encode(array('status' => 'error', 'message' => 'Invalid reset key or email.'));
    }

    // Make sure to exit
    wp_die();
}

add_action('wp_ajax_update_password', 'update_password_ajax_handler');
add_action('wp_ajax_nopriv_update_password', 'update_password_ajax_handler');


// AJAX callback function for updating the password
function pass_reference_call_ajax_handler() {

	global $wpdb;
    $table_name = $wpdb->prefix . 'Pass_enquires';

    // Check if the table already exists
    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        // SQL to create the new table
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            pass_refer_start_time varchar(20) NOT NULL,
            pass_refer_end_time varchar(20) NOT NULL,
            pass_phone varchar(20) NOT NULL,
            pass_event_id bigint(20) NOT NULL,
            pass_post_id bigint(20) NOT NULL,
            language varchar(41) NOT NULL,
            post_name varchar(255) NOT NULL,
            event_name_english varchar(255) NOT NULL,
            entry_time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    $pass_refer_start_time = $_POST['pass_refer_start_time'];
    $pass_refer_end_time = $_POST['pass_refer_end_time'];
    $pass_phone = $_POST['pass_phone'];
    $pass_event_id = $_POST['pass_event_id'];
    $pass_post_id = $_POST['pass_post_id'];
    $language = $_POST['language'];

    $post = get_post($pass_post_id);
    $post_name = '';
    $event_name_english = '';

    if ($post) {
        $post_name = $post->post_title;
        $event_name_english = get_post_meta($pass_post_id, 'event_name_english', true);
    }

    $table_name = $wpdb->prefix . 'Pass_enquires';

    $wpdb->insert(
        $table_name,
        array(
            'pass_refer_start_time' => $pass_refer_start_time,
            'pass_refer_end_time' => $pass_refer_end_time,
            'pass_phone' => $pass_phone,
            'pass_event_id' => $pass_event_id,
            'pass_post_id' => $pass_post_id,
            'language' => $language,
            'post_name' => $post_name,
            'event_name_english' => $event_name_english,
        ),
        array(
            '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s'
        )
    );

	// if($language == 'arabic'){ 
	// 	$mail_type ="new_user_arabic_callback_submission_mail";
	// }else{
	// 	$mail_type ="new_user_english_callback_submission_mail";
	// }

	// $mail_data =array(
	// 	'callback_time'=>$pass_refer_time,
	// 	'callback_phone'=> $pass_phone,
	// 	'event_name'=>$post_name,
	// 	'event_english_name'=>$event_name_english,
	// );

	// $mail_result = send_booking_mail($mail_type,$mail_data);


	$vendor_user_id = get_field('vendor',$pass_post_id);
	$vendor_info = get_userdata($vendor_user_id);
	$vendor_email = '';
	if ($vendor_info) {
		$vendor_email = $vendor_info->user_email;
	} 

	$fields = get_field('admin_pass_mail', 'option');
	$admin_email= $fields['admin_pass_email'] ?? '';

	$mail_type ="new_user_callback_submission_admin_mail";
	

	$callback_time = $pass_refer_start_time . ' To ' . $pass_refer_end_time;

	if($admin_email){
		$mail_data =array(
			'email'=> $admin_email,
			'callback_time'=> $callback_time,
			'callback_phone'=> $pass_phone,
			'language' => $language,
			'event_name'=> $post_name,
			'event_english_name'=> $event_name_english,
		);
		
		$mail_result = send_booking_mail($mail_type,$mail_data);
	}

    // Return a response
    wp_send_json_success(array('message' => 'Data saved successfully'));
}

add_action('wp_ajax_pass_reference_call', 'pass_reference_call_ajax_handler');
add_action('wp_ajax_nopriv_pass_reference_call', 'pass_reference_call_ajax_handler');

add_action('admin_menu', 'pass_enquires_admin_menu');

function pass_enquires_admin_menu() {
    add_menu_page(
        'Pass Enquires',          // Page title
        'Pass Enquires',          // Menu title
        'manage_options',         // Capability
        'pass-enquires',          // Menu slug
        'display_pass_enquires',  // Function to display the page content
        'dashicons-list-view',    // Icon
        26                        // Position
    );
}

function display_pass_enquires() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'Pass_enquires';

    // Fetch the data
    $results = $wpdb->get_results("SELECT * FROM $table_name");

    echo '<div class="wrap">';
    echo '<h1>Pass Enquires</h1>';
    echo '<table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <th id="columnname" class="manage-column column-columnname" scope="col">ID</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Attraction Name</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Attraction Name English</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Contact Number</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Prefer Time</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Language</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Entry Time</th>
                </tr>
            </thead>
            <tbody>';

    // Display the data
    foreach ($results as $row) {
		$post_link = get_permalink($row->pass_post_id);
        echo '<tr>';
        echo '<td>' . esc_html($row->id) . '</td>';
        echo '<td><a href="'.$post_link.'" target="_blank">' . esc_html($row->post_name) . '</a></td>';
        echo '<td><a href="'.$post_link.'" target="_blank">' . esc_html($row->event_name_english) . '</a></td>';
        echo '<td>' . esc_html($row->pass_phone) . '</td>';
        echo '<td>' . esc_html($row->pass_refer_start_time) . ' To ' . esc_html($row->pass_refer_end_time) . '</td>';
        echo '<td>' . esc_html($row->language) . '</td>';
        echo '<td>' . esc_html($row->entry_time) . '</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
}




