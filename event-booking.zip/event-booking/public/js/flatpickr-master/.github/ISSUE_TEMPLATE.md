<!-- IF REPORTING A BUG, A REPRO LINK IS ABSOLUTELY NECESSARY -->
<!-- fork this -->
https://jsfiddle.net/tj2Lo4z7/

## Your Environment
<!-- Include the following details: -->
* flatpickr version used:
* Browser name and version:
* OS and version:
