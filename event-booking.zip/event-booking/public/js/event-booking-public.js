(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	
	jQuery(document).ready(function($) {
	toastr.options = {
	  "closeButton": true,
	  "debug": false,
	  "newestOnTop": false,
	  "progressBar": true,
	  "positionClass": "toast-top-center",
	  "preventDuplicates": false,
	  "onclick": null,
	  "showDuration": "300",
	  "hideDuration": "1000",
	  "timeOut": "5000",
	  "extendedTimeOut": "1000",
	  "showEasing": "swing",
	  "hideEasing": "linear",
	  "showMethod": "fadeIn",
	  "hideMethod": "fadeOut"
	}

  // toastr.success('Form submitted successfully!');
		$(document).ready(function() {
			$('html').attr('lang', 'ar');
			$('html').addClass('translated-rtl');
			
			// Set the selected value to 'en|ar' for the dropdown with class 'gt_selector'
			$('.gt_selector').val('ar|ar');
	
			// Trigger a change event to ensure any associated event handlers are executed
			$('.gt_selector').trigger('change');
		});

		setTimeout(() => {
				$('.gt_selector').val('ar|ar');
				$('.gt_selector').trigger('change');
		}, 400);


		$('.edit-event').click(function() {
			var eventId = $(this).data('event-id');
			openEditPopup(eventId);
		});

		function openEditPopup(eventId) {
			$.ajax({
				url: custom_script_vars.ajaxurl,
				type: 'POST',
				data: {
					event_id: eventId,
					action: 'vandor_data_call',
					call_name: 'edit_event',
				},
				success: function(response) {
					var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
					cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
					// Parse the cleaned JSON response
					var responseData = JSON.parse(cleanedResponse);
					if (responseData.success) {
						var eventData = responseData.message;
						populateFormFields(eventData, eventId);
						$('#edit-event-popup').show();
					} else {
						console.error('Failed to fetch event data: ' + JSON.stringify(responseData.message));
					}
				},
				error: function(xhr, status, error) {
					console.error('Error fetching event data');
				}
			});
		}

		function populateFormFields(eventData, eventId) {
			var fieldsContainer = $('.repeater-fields');
			fieldsContainer.empty();
		
			// Loop through eventData and generate HTML dynamically
			Object.keys(eventData).forEach(function(day) {
				var dayDataArray = eventData[day];
		
				// Check if dayDataArray is an array
				if (Array.isArray(dayDataArray)) {
					dayDataArray.forEach(function(dayData, index) {
						// Convert start event time
						var startTime = convertTimeTo24HourFormat(dayData.start_event);
		
						// Generate HTML for each event slot
						var fieldHtml = `
							<div class="repeater-field">
								<div class="repeater-field_item repeater-field_title">
									<h3 event_id_edit="${eventId}">${day.charAt(0).toUpperCase() + day.slice(1)} - Slot ${index + 1}</h3>
								</div>
								<div class="repeater-field_item repeater-field_avaliable">
									<label>Avaliable:</label>
									<input type="checkbox" name="repeater_data[${day}][${index}][avaliable][]" value="yes" ${dayData.avaliable[0] === 'yes' ? 'checked' : ''}>
								</div>
								<div class="repeater-field_item repeater-field_start">
									<label>Start Event:</label>
									<input type="time" class="timepicker" name="repeater_data[${day}][${index}][start_event][]" value="${startTime}">
								</div>
							
								<div class="repeater-field_item repeater-field_minperson">
									<label>Min Persons:</label>
									<input type="number" name="repeater_data[${day}][${index}][min_person][]" value="${dayData.min_person}">
								</div>
								<div class="repeater-field_item repeater-field_maxperson">
									<label>Max Persons:</label>
									<input type="number" name="repeater_data[${day}][${index}][max_person][]" value="${dayData.max_person}">
								</div>
								<div class="repeater-field_item repeater-field_approval_type">
									<label>Approval type:</label>
									<select name="repeater_data[${day}][${index}][approval_type][]">
										<option value="manual" ${dayData.approval_type === 'manual' ? 'selected' : ''}>Manual</option>
										<option value="auto" ${dayData.approval_type === 'auto' ? 'selected' : ''}>Auto</option>
									</select>
								</div>
							</div>`;
		
						// Append generated HTML to your container
						fieldsContainer.append(fieldHtml);
					});
				}
			});
			$('.lead-time-fields').remove();
			// Convert lead time values to appropriate units
			var minimumLeadTimeHours = convertLeadTimeToHours(eventData.lead_time.min_lead_time);
			var maximumLeadTimeDays = convertLeadTimeToDays(eventData.lead_time.max_lead_time);
		
			// Generate options for minimum lead time (hours)
			var minimumLeadTimeOptions = generateLeadTimeOptions(1, minimumLeadTimeHours,120, 'hour');
		
			// Generate options for maximum lead time (days)
			var maximumLeadTimeOptions = generateLeadTimeOptions(1, maximumLeadTimeDays,100, 'day');
		
			// Append lead time fields after the repeater fields container
			var leadTimeFieldsHtml = `
				<div class="lead-time-fields">
					<div class="lead-time-field">
						<label for="minimum_lead_time">Minimum Lead Time:</label>
						<select name="minimum_lead_time" id="minimum_lead_time">
							${minimumLeadTimeOptions}
						</select>
					</div>
					<div class="lead-time-field">
						<label for="maximum_lead_time">Maximum Lead Time:</label>
						<select name="maximum_lead_time" id="maximum_lead_time">
							${maximumLeadTimeOptions}
						</select>
					</div>
				</div>`;
			
			fieldsContainer.after(leadTimeFieldsHtml); // Append lead time fields after the repeater fields container
		
			// Set selected options for minimum and maximum lead times
			$('#minimum_lead_time').val(minimumLeadTimeHours);
			$('#maximum_lead_time').val(maximumLeadTimeDays);
		}
		
		function convertLeadTimeToHours(leadTime) {
			var value = parseInt(leadTime);
			if (leadTime.includes('days')) {
				value *= 24; // Convert days to hours
			}
			return value;
		}
		
		function convertLeadTimeToDays(leadTime) {
			var value = parseInt(leadTime);
			if (leadTime.includes('hours')) {
				value /= 24; // Convert hours to days
			}
			return value;
		}
		
		function generateLeadTimeOptions(start, selected, end, unit) {
			var optionsHtml = '';
			for (var i = start; i <= end; i++) {
				if(selected==i){
					optionsHtml += `<option value="${i}" selected>${i} ${unit}</option>`;
				}else{
					optionsHtml += `<option value="${i}">${i} ${unit}</option>`;
				}
				
			}
			return optionsHtml;
		}


		function convertTimeTo24HourFormat(timeString) {
			var time = timeString.split(' ');
			var hourMinute = time[0].split(':');
			var hour = parseInt(hourMinute[0]);
			var minute = parseInt(hourMinute[1]);
			if (time[1].toLowerCase() === 'pm' && hour !== 12) {
				hour += 12;
			} else if (time[1].toLowerCase() === 'am' && hour === 12) {
				hour = 0;
			}
			return ('0' + hour).slice(-2) + ':' + ('0' + minute).slice(-2);
		}
					
				
			
		$('#edit-event-form').submit(function(event) {
			event.preventDefault();
		
			var formData = $(this).serialize();
			var eventIdEdit = $('[event_id_edit]').attr('event_id_edit');
		
			$.ajax({
				url: custom_script_vars.ajaxurl,
				type: 'POST',
				data: {
					formData: formData,
					event_id_edit: eventIdEdit,
					action: 'vandor_data_call',
					call_name: 'save_event_slot_data',
				},
				success: function(response) {
					var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
					cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
					// Parse the cleaned JSON response
					var responseData = JSON.parse(cleanedResponse);

					Swal.fire({
						icon: 'success',
						title: 'نجاح',
						text: 'تم حفظ المعلومات بنجاح!',
						showConfirmButton: false, // Remove the "OK" button
							timer: 2000
					});
					jQuery('#edit-event-popup').hide();
					// You can perform additional actions here upon successful form submission
				},
				error: function(xhr, status, error) {
					console.error('Error saving form data:', error);
					// Show error message using Swal.fire
					Swal.fire({
						icon: 'error',
						title: 'خطأ',
						text: 'فشل في حفظ البيانات. الرجاء معاودة المحاولة في وقت لاحق.',
						showConfirmButton: false, // Remove the "OK" button
							timer: 2000
					});
					// You can perform additional error handling here
				}
			});
		});
			
		$('.title-item').click(function() {
			var eventId = $(this).data('event-id');
			Swal.fire({
				title: 'يعالج...',
				text: 'انتظر من فضلك...',
				allowOutsideClick: false,
				allowEscapeKey: false,
				allowEnterKey: false,
				showConfirmButton: false,
				onOpen: () => {
					Swal.showLoading();
				}
			});
			$.ajax({
				url: custom_script_vars.ajaxurl,
				type: 'POST',
				data: {
					event_id_edit: eventId,
					action: 'vandor_data_call',
					call_name: 'event_register_data',
				},
				success: function(response) {
					var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
					cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
					// Parse the cleaned JSON response
					var responseData = JSON.parse(cleanedResponse);
						if (responseData.success) {
							Swal.close();
						var userData = responseData.message;
						var tbody = document.getElementById('user-data-table').getElementsByTagName('tbody')[0];
						tbody.innerHTML = ''; // Clear the existing content
			
						userData.forEach(function(user) {
							if(user.user_id >0){
							var booking_id = user.id;

							var tr = document.createElement('tr');
							var status_data = user.isstatus;
							tr.className = status_data.toLowerCase();
							var td1 = document.createElement('td');
							td1.textContent = user.fname;
							var td2 = document.createElement('td');
							td2.textContent = user.lname;
							var td3 = document.createElement('td');
							td3.textContent = user.email;
							var td4 = document.createElement('td');
							td4.textContent = user.phone;
							var td5 = document.createElement('td');
							td5.textContent = user.selectedDate;
							var td6 = document.createElement('td');
							td6.textContent = user.start_event;
							// var td7 = document.createElement('td');
							// td7.textContent = user.end_event; // Corrected typo
							// var td8 = document.createElement('td');
							// td8.textContent = user.min_person;
							// var td9 = document.createElement('td');
							// td9.textContent = user.max_person;
							var td10 = document.createElement('td');
							td10.textContent = user.selectedpersons;
							td10.className = 'selectedpersons_details';
							td10.id = booking_id;
							
							// Create a <span> element for the Font Awesome icon
							var span = document.createElement('span');
							span.className = 'eye-open';
							span.innerHTML = '<i class="fa fa-eye"></i>';
							
							// Append the <span> element to the <td> element
							td10.appendChild(span);
					 // Corrected typo
							   
							const currentUser = user;
							var td11 = document.createElement('td');
							var select = document.createElement('select');
							select.name = 'status';
							select.dataset.userId = user.user_id;
							select.dataset.bookingId = booking_id;
							select.dataset.postId = user.post_id;
							var options = ['approved', 'cancel-not-avaliable'];

							if (user.isstatus == 'pending-to-attraction') {
								var optionfirstElement = document.createElement('option');
								optionfirstElement.value = '';
								optionfirstElement.textContent = 'Select Option';
								select.appendChild(optionfirstElement); // Append the first option element
							}
							options.forEach(function(option) {
								var optionElement = document.createElement('option');
								optionElement.value = option;
								optionElement.textContent = option.charAt(0).toUpperCase() + option.slice(1);
								if (option === user.isstatus) {
									optionElement.selected = true;
								}
								select.appendChild(optionElement);
							});
						
						
							td11.appendChild(select);
							tr.appendChild(td1);
							tr.appendChild(td2);
							tr.appendChild(td3);
							tr.appendChild(td4);
							tr.appendChild(td5);
							tr.appendChild(td6);
							// tr.appendChild(td7);
							// tr.appendChild(td8);
							// tr.appendChild(td9);
							tr.appendChild(td10);
							tr.appendChild(td11);


							tbody.appendChild(tr);
						}
						});
			
						// Show the event details container
						$('#event-details-container #user-data-table tbody .cancel-not-avaliable').hide();
						$('#event-details-container #user-data-table tbody .pending-to-attraction').hide();
						$('#event-details-container #user-data-table tbody .pending-pass-verify').hide();
						$('#event-details-container #user-data-table tbody .cancel-no-pass').hide();
						$('#event-details-container  .tabs li:First	').addClass('active');
						$('#event-details-container').show();
					} else {
						Swal.fire({
							icon: 'info',
							title: 'لم يتم العثور على نتائج',
							text: responseData.message,
							showConfirmButton: false, // Remove the "OK" button
							timer: 2000
						});
					
					}
				},
				error: function(xhr, status, error) {
					// Close processing modal
					Swal.close();
		
					// Display error message
					Swal.fire({
						icon: 'error',
						title: 'خطأ',
						text: 'حدث خطأ أثناء معالجة طلبك. الرجاء معاودة المحاولة في وقت لاحق.',
						showConfirmButton: false, // Remove the "OK" button
							timer: 2000
					});
				}
			});
		});

		jQuery('.closePopup').on('click', function() {
			jQuery('#edit-event-popup').hide();
		});

			
		var now = new Date();
		var year = now.getFullYear();
		var month = String(now.getMonth() + 1).padStart(2, '0'); // Month starts from 0
		var day = String(now.getDate()).padStart(2, '0');
		var hour = String(now.getHours()).padStart(2, '0');
		var minute = String(now.getMinutes()).padStart(2, '0');

		// Format the date and time for the input field
		var formattedDateTime = year + '-' + month + '-' + day + 'T' + hour + ':' + minute;

		// Set the min attribute of the input field to the current date and time
		if(document.getElementById('datepicker')){
			document.getElementById('datepicker').min = formattedDateTime;
			$('#city').change(function () {
			var selectedCityId = $(this).val();
			if (selectedCityId !== '') {
				$.ajax({
					url: custom_script_vars.ajaxurl,
					type: 'POST',
					data: {
						action: 'event_data_ajax_call',
						call_name:'get_city_events',
						city_id: selectedCityId
					},
					success: function(response) {
						var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
						cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
						// Parse the cleaned JSON response
						var data = JSON.parse(cleanedResponse);
						if (data.success) {

							var $eventDropdown = $('#eventId');
							$eventDropdown.empty();
							if (data.message.length > 0) {
								$.each(data.message, function(index, event) {
									$eventDropdown.append($('<option>', {
										value: event.exc_id,
										text: event.exc_name
									}));
								});
								$('#eventContainer').show();
							} else {
								$('#eventContainer').hide();
								console.log('No events found for this city.');
							}
						} else {
							console.error('Failed to fetch events data:', data.message || 'Unknown error');
						}
					},
					error: function(xhr, status, error) {
						console.error('AJAX request failed:', error);
					}
					
				});
			} else {
				$('#eventContainer').hide();
				$('#eventId').empty();
			}
			});
		}



		$('#eventForm').submit(function(event) {
			event.preventDefault();

			var selectedDate = $('#selectedDate').val();
			var startEvent = $('#start_event').val();
			var minPerson = $('#min_person').val();
			var maxPerson = $('#max_person').val();
			var selectedPersons = $('#selectedpersons').val();
			var languageCheck = $('[name="language"]').val();

			if(languageCheck == 'arabic'){
				var swaltitle = $('#request_label_arabic').val();
				var swaltext = $('#request_notification_arabic').val();
				var swalconfirmButtonText = 'نعم تأكيد!';
				var swalcancelButtonText = 'ألغى';
			}else{
				var swaltitle = $('#request_label_english').val();
				var swaltext = $('#request_notification_english').val();
				var swalconfirmButtonText = 'Yes confirm!';
				var swalcancelButtonText = 'Cancel';
			}
			Swal.fire({
				title: swaltitle,
				text: swaltext,
				icon: "warning",
				showCancelButton: true,
				confirmButtonColor: "#505ca4",
				cancelButtonColor: "#fff",
				cancelButtonText: swalcancelButtonText,
				confirmButtonText: swalconfirmButtonText
			  }).then((result) => {
				if (result.isConfirmed) {
					Swal.fire({
						title: 'يعالج...',
						text: 'انتظر من فضلك...',
						allowOutsideClick: false,
						allowEscapeKey: false,
						allowEnterKey: false,
						showConfirmButton: false,
						didOpen: () => {
							Swal.showLoading();
						}
					});

					if (selectedDate && startEvent && minPerson && maxPerson && selectedPersons) {
						var formData = $(this).serialize();
						var languageValue = $('[name="language"]').val();
						var event_name = $('#eventId').find(":selected").text();

		
						$.ajax({
							type: 'POST',
							url: custom_script_vars.ajaxurl,
							data: {
								action: 'event_data_ajax_call',
								call_name:'save_event_data',
								formData: formData,
								event_name:event_name
							},
							success: function(response) {
									Swal.close();
								var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
								cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
								// Parse the cleaned JSON response
								var data = JSON.parse(cleanedResponse);
								var formattedDateTime = new Date(data.message.date_time).toLocaleString();
	
								if (data.success) {
									Swal.fire({
										icon: 'success',
										title: 'نجاح',
										text: 'طلب الحجز الخاص بك تم تسلمه للمراجعة',
										showConfirmButton: false, // Remove the "OK" button
									timer: 2000
									}).then(function() {
										var resdata = data.message;
										var otherPersons = '';
										var formattedDateTime = resdata.selectedDate + " " + resdata.start_event;
										
										var answers = resdata.question_answers.match(/a:\d+:{.*?}/g).map(function(answer) {
											return answer.match(/s:\d+:"(.*?)";/g).map(function(match) {
												return match.match(/s:\d+:"(.*?)";/)[1];
											});
										});

										if(resdata.selectedpersons > 1){
											otherPersons = resdata.otherPersons.match(/a:\d+:{.*?}/g).map(function(person) {
												return person.match(/s:\d+:"(.*?)";/g).map(function(match) {
													return match.match(/s:\d+:"(.*?)";/)[1];
												});
											});
										}

										if(languageValue == 'arabic'){
											  toastr.success('تم إرسال النموذج');
											var parts = resdata.start_event.split(" ");
											var starttime = "<span class='tm_name'>" +parts[1]+"</span><span class='tm_nmbr'>"+ parts[0] + "</span>";
										// Create HTML structure with new object values and names
										var htmlContent = '<p class="details_head">تفاصيل الحجز الخاصة بك </p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :حالة  </span><span class="details-data notranslate"> ' + resdata.isstatus + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :اسم الفعالية  </span><span class="details-data notranslate"> ' + resdata.event_name + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :تاريخ  </span><span class="details-data notranslate"> ' + resdata.selectedDate + '</span></p>';
														if (answers.length > 0) {
															htmlContent += '<p class="details_head_ans"><span class="details-data-heading notranslate">أسئلة و أجوبة:</span></p><div class="question_list notranslate">';
															answers.forEach(function(answer) {
																if(answer[0]){
																	htmlContent += '<p>سؤال : <span>' +answer[1] + '</span></p><p>الإجابة : <span>'+ answer[0] +'</span></p>';
																}
															});
															htmlContent += '</div>';
														}
														htmlContent +='<p class="details_head arr"><span class="details-data-heading"> :وقت  </span><span class="details-data notranslate time_ara"> ' + starttime + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :عدد المشاركين  </span><span class="details-data notranslate"> ' + resdata.selectedpersons + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :الاسم الأول  </span><span class="details-data notranslate"> ' + resdata.fname + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :اسم العائلة  </span><span class="details-data notranslate"> ' + resdata.lname + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :بريد إلكتروني  </span><span class="details-data notranslate"> ' + resdata.email + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :رقم الجوال  </span><span class="details-data notranslate"> ' + resdata.phone + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :اجتياز  </span><span class="details-data notranslate"> ' + resdata.pass_name + '</span></p>' +
														'<p class="details_head arr"><span class="details-data-heading"> :ملاحظة إضافية  </span><span class="details-data notranslate"> ' + resdata.additional_note + '</span></p>';
														if (otherPersons.length > 0) {
																htmlContent += '<p class="details_head"><span class="details-data-heading notranslate">المرافقون: </span></p><div class="particpent_list notranslate">';
																otherPersons.forEach(function(person) {
																	htmlContent += '<p><span>' + person[1] + ' </span><span>' + person[0] + '</span><span>' + person[2] +'</span></p>';
																});
																htmlContent += '</div>';
														}
	
														var inputDetailsClasses = languageValue === 'english' ? 'english' : 'arabic';
										}else{
											  toastr.success('Form submitted successfully!');
											var htmlContent = '<p class="details_head">Your Booking Details:</p>' +
												'<p class="details_head">Status : <span class="details-data notranslate"> ' + resdata.isstatus + '</span></p>' +
												'<p class="details_head">Attraction Name : <span class="details-data notranslate"> ' + resdata.event_english_name + '</span></p>' +
												'<p class="details_head">Date : <span class="details-data notranslate"> ' + resdata.selectedDate + '</span></p>';
												if (answers.length > 0) {
													htmlContent += '<p class="details_head_ans"><span class="details-data-heading notranslate">Questions/Answers:</span></p><div class="question_list notranslate">';
													answers.forEach(function(answer) {
														if(answer[0]){
														htmlContent += '<p>Question : <span>'+ answer[1] + '</span></p><p> Answer : <span>'+ answer[0] +'</span></p>';
														}
													});
													htmlContent += '</div>';
												}
												htmlContent += '<p class="details_head">Time : <span class="details-data notranslate"> ' + resdata.start_event + '</span></p>' +
												'<p class="details_head">Number of participants : <span class="details-data notranslate"> ' +  resdata.selectedpersons + '</span></p>' +
												'<p class="details_head">First Name : <span class="details-data notranslate"> ' + resdata.fname + '</span></p>' +
												'<p class="details_head">Last Name : <span class="details-data notranslate"> ' + resdata.lname + '</span></p>' +
												'<p class="details_head">Email : <span class="details-data notranslate"> ' + resdata.email + '</span></p>' +
												'<p class="details_head">Phone : <span class="details-data notranslate"> ' + resdata.phone + '</span></p>' +
												'<p class="details_head">Pass : <span class="details-data notranslate"> ' + resdata.pass_name + '</span></p>' +
												'<p class="details_head">Additional note : <span class="details-data notranslate"> ' + resdata.additional_note + '</span></p>';
												if (otherPersons.length > 0) {
													htmlContent += '<p class="details_head"><span class="details-data-heading notranslate">Participants:</span></p><div class="particpent_list notranslate">';
													otherPersons.forEach(function(person) {
														htmlContent += '<p><span>' + person[1] + ' </span><span>' + person[0] + '</span><span>' + person[2] +'</span></p>';
													});
													htmlContent += '</div>';
												}
												
						
											var inputDetailsClasses = languageValue === 'english' ? 'english' : 'arabic';
										}
										$('#input_details').addClass(inputDetailsClasses);
										// Append HTML to #input_details
										$('#input_details').html(htmlContent);
										$('form#eventForm').hide();
										$('.gtranslate_wrapper').hide();
										$('#input_details').show();
									});
									
								} else {
									Swal.fire({
										icon: 'error',
										title: 'أُووبس...',
										text: data.message,
										showConfirmButton: false, // Remove the "OK" button
									timer: 2000
									});
								}
							},
							error: function(xhr, status, error) {
								Swal.fire({
									icon: 'error',
									title: 'أُووبس...',
									text: 'حدث خطأ!',
									showConfirmButton: false, // Remove the "OK" button
									timer: 2000
								});
								console.error('حدث خطأ: ' + error);
							}
						});
		
					} else {
						// Required fields are not filled, show an error message
						Swal.fire({
							icon: 'error',
							title: 'خطأ',
							text: 'يرجى تعبئة جميع الحقول المطلوبة!',
							showConfirmButton: false, // Remove the "OK" button
									timer: 2000
						});
					}
				}
			  });

		
			
	    });
	});

	jQuery(document).ready(function($) {

		$(document).on('click', '.cancel-booking-btn', function() {
			var bookingId = $(this).data('booking-id');
			var userId = $(this).data('user-id');
			var post_id = $(this).data('post-id');
			
			// Call the common function for both click and change events
			handleAction(bookingId, userId, post_id, 'Canceled');
		});

		// Change event handler for status change
		$("body").on('change', 'select[name="status"]', function() {
			var newStatus = $(this).val();
			var bookingId = $(this).data('booking-id');
			var post_id = $(this).data('post-id');
			var user_id = $(this).data('user-id');
			if(newStatus){
				handleAction(bookingId, user_id, post_id, newStatus);
			}
		});

		// Common function to handle both actions
		function handleAction(bookingId, userId, postId, action) {
			
			Swal.fire({
				title: 'يتأكد',
				text: action === 'Canceled' && custom_script_vars.customer_booking_cancellation_alert !== '' ? custom_script_vars.customer_booking_cancellation_alert : 'هل انت متأكد انك تريد المتابعة?',
				icon: 'question',
				showCancelButton: true,
				confirmButtonText: 'نعم',
				cancelButtonText: 'لا'
			}).then((result) => {
				if (result.isConfirmed) {
					Swal.fire({
						title: 'يعالج...',
						text: 'انتظر من فضلك...',
						allowOutsideClick: false,
						allowEscapeKey: false,
						allowEnterKey: false,
						showConfirmButton: false,
						onOpen: () => {
							Swal.showLoading();
						}
					});

					$.ajax({
						url: custom_script_vars.ajaxurl,
						type: 'POST',
						data: {
							booking_id: bookingId,
							user_id: userId,
							post_id: postId,
							status: action !== 'cancel' ? action : 'cancel',
							action: 'vandor_data_call', // Action name
							call_name: 'update_user_status', // Call name for updating user status
						},
						success: function(response) {
							var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
							cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
							// Parse the cleaned JSON response
							var responseData = JSON.parse(cleanedResponse);
							if (responseData.success) {
								Swal.fire({
									icon: 'success',
									title: 'Success',
									text: action === 'cancel' ? 'تم إلغاء الحجز بنجاح!' : 'تم تحديث الحالة بنجاح!',
									showConfirmButton: false, // Remove the "OK" button
							timer: 2000
								}).then(() => {
									location.reload(); // Reload or update booking list if needed
								});

							} else {
								Swal.fire({
									icon: 'error',
									title: 'أُووبس',
									text: responseData.message,
									showConfirmButton: false, // Remove the "OK" button
							timer: 2000
								});
							}
						},
						error: function(xhr, status, error) {
							Swal.fire({
								icon: 'error',
								title: 'أُووبس...',
								text: 'حدث خطأ أثناء معالجة الطلب. الرجاء معاودة المحاولة في وقت لاحق.',
								showConfirmButton: false, // Remove the "OK" button
								timer: 2000
							});
						}
					});
				}
			});
		}
		jQuery('body').on("click","#booking-selectedpersons-popup .close",function() {
			$('#booking-selectedpersons-popup').hide();
		});
		
		jQuery('body').on("click","#booking-edit-booking-popup .close",function() {
			$('#booking-edit-booking-popup').hide();
		});

		window.onclick = function(event) {
			var modal = document.getElementById("booking-selectedpersons-popup");
			if (event.target == modal) {
			  modal.style.display = "none";
			}
		}

		jQuery('body').on("click",".selectedpersons_details",function() {
			var bookingId = jQuery(this).attr('id'); // Get the ID attribute value

			Swal.fire({
				title: 'يعالج...',
				text: 'انتظر من فضلك...',
				allowOutsideClick: false,
				allowEscapeKey: false,
				allowEnterKey: false,
				showConfirmButton: false,
				onOpen: () => {
					Swal.showLoading();
				}
			});
			
			$.ajax({
				url: custom_script_vars.ajaxurl,
				type: 'POST',
				data: {
					booking_id: bookingId,
					action: 'vandor_data_call', // Action name
					call_name: 'selectedpersons_details', // Call name for updating user status
				},
				success: function(response) {
					var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
					cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
					// Parse the cleaned JSON response
					var responseData = JSON.parse(cleanedResponse);

					Swal.close();

					if (responseData.success) {
				
						if (responseData.message.length > 0) {

							var userData = responseData.message;

							var html = '<span class="close">&times;</span>';
							html += '<h2>Additional Person Info</h2>';
							html += '<table><thead><tr><th>S.No</th><th>Name</th><th>Additional Note</th></tr></thead><tbody>';
							for (var i = 0; i < userData.length; i++) {

								var additional_note = userData[i].additional_note !== null ? userData[i].additional_note : "";
								html += '<tr><td>' + (i + 1) + '</td><td>' + userData[i].name + '</td><td>' + additional_note + '</td></tr>';

							}
							html += '</tbody></table>';
							$('.booking-selectedpersons-modal-content').html(html);
							$('#booking-selectedpersons-popup').show();

						} else {
							Swal.fire({
								icon: 'error',
								title: 'أُووبس',
								text: responseData.message,
								showConfirmButton: false, // Remove the "OK" button
								timer: 2000
							});
						}
						
					} else {
						Swal.fire({
							icon: 'error',
							title: 'أُووبس',
							text: responseData.message,
							showConfirmButton: false, // Remove the "OK" button
							timer: 2000
						});
					}
				},
				error: function(xhr, status, error) {
					Swal.fire({
						icon: 'error',
						title: 'أُووبس',
						text: 'حدث خطأ أثناء معالجة الطلب. الرجاء معاودة المحاولة في وقت لاحق.',
						showConfirmButton: false, // Remove the "OK" button
							timer: 2000
					});
				}
			});
		});

		jQuery('body').on("click","#booking-edit-booking-popup .update_booking_information",function() {
			
			var bookingId = jQuery(this).attr('data-id');
			var bookingDate = jQuery('.booking-edit-booking-modal-content .booking_date').val();
			var bookingTime = jQuery('.booking-edit-booking-modal-content .booking_time').val();

			if(bookingId && bookingDate && bookingTime){
				$.ajax({
					url: custom_script_vars.ajaxurl,
					type: 'POST',
					data: {
						booking_id: bookingId,
						booking_date: bookingDate,
						booking_time: bookingTime,
						action: 'vandor_data_call', // Action name
						call_name: 'updatebooking_details', // Call name for updating user status
					},
					success: function(response) {
						$('#booking-edit-booking-popup').hide();
						Swal.fire({
							icon: 'success',
							title: 'success',
							text: 'Booking time & date updated successfully',
							showConfirmButton: false, // Remove the "OK" button
								timer: 2000
						});
						location.reload();
					},
					error: function(xhr, status, error) {
						Swal.fire({
							icon: 'error',
							title: 'error',
							text: 'Booking time & date not updated',
							showConfirmButton: false, // Remove the "OK" button
								timer: 2000
						});
					}
				});
			}else{
				Swal.fire({
					icon: 'error',
					title: 'information incorrect',
					text: 'Please check again. information is incorrect',
					showConfirmButton: false, // Remove the "OK" button
						timer: 2000
				});
			}
		});

		jQuery('body').on("click",".edit_timedate_event",function() {
			var bookingId = jQuery(this).attr('id'); // Get the ID attribute value

			Swal.fire({
				title: 'يعالج...',
				text: 'انتظر من فضلك...',
				allowOutsideClick: false,
				allowEscapeKey: false,
				allowEnterKey: false,
				showConfirmButton: false,
				onOpen: () => {
					Swal.showLoading();
				}
			});
			
			$.ajax({
				url: custom_script_vars.ajaxurl,
				type: 'POST',
				data: {
					booking_id: bookingId,
					action: 'vandor_data_call', // Action name
					call_name: 'editbooking_details', // Call name for updating user status
				},
				success: function(response) {
					var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
					cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
					// Parse the cleaned JSON response
					var responseData = JSON.parse(cleanedResponse);

					Swal.close();

					if (responseData.success) {
				
						if (responseData.message.length > 0) {

							var userData = responseData.message;

							var html = '<span class="close">&times;</span>';
							html += ' <h2>Edit Booking Info</h2>';
							html += '<table><thead><tr><th>Booking date</th><th>Booking Time</th><th>Action</th></tr></thead><tbody>';
							for (var i = 0; i < userData.length; i++) {

								html += '<tr><td><input class="booking_date" data-id="'+bookingId+'" value="' + userData[i].selectedDate + '"></td><td><input class="booking_time" data-id="'+bookingId+'" value="' + userData[i].start_event + '"></td><td><a href="javascript:void(0);" data-id="'+bookingId+'" class="update_booking_information">Update</a></td></tr>';

							}
							html += '</tbody></table>';
							$('.booking-edit-booking-modal-content').html(html);
							$('#booking-edit-booking-popup').show();

						} else {
							Swal.fire({
								icon: 'error',
								title: 'أُووبس',
								text: responseData.message,
								showConfirmButton: false, // Remove the "OK" button
								timer: 2000
							});
						}
						
					} else {
						Swal.fire({
							icon: 'error',
							title: 'أُووبس',
							text: responseData.message,
							showConfirmButton: false, // Remove the "OK" button
							timer: 2000
						});
					}
				},
				error: function(xhr, status, error) {
					Swal.fire({
						icon: 'error',
						title: 'أُووبس',
						text: 'حدث خطأ أثناء معالجة الطلب. الرجاء معاودة المحاولة في وقت لاحق.',
						showConfirmButton: false, // Remove the "OK" button
							timer: 2000
					});
				}
			});
		});
	});


	jQuery(document).ready(function($) {
		// Attach click event to the "Forgot Password" button
		$('.forget_btn').on('click', function(e) {
			e.preventDefault();
	
			// Get the user's email from the prompt
			var email = prompt('Enter your email:');
	
			// Perform AJAX request
			$.ajax({
				type: 'POST',
				url: custom_script_vars.ajaxurl,
				data: {
					action: 'reset_password',
					email: email,
				},
				success: function(response) {
					var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
					cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
					// Parse the cleaned JSON response
					var result = JSON.parse(cleanedResponse);
					alert(result.message);
				},
				error: function(error) {
					console.log(error);
				}
			});
		});
	});

	jQuery(document).ready(function($) {
		$('#reset-password-form').on('submit', function(e) {
			e.preventDefault();

			var newPassword = $('#new-password').val();
			var key = $('input[name="key"]').val();
			var email = $('input[name="email"]').val();

			// Perform AJAX request to update the password
			$.ajax({
				type: 'POST',
				url: custom_script_vars.ajaxurl,
				data: {
					action: 'update_password',
					key: key,
					email: email,
					new_password: newPassword,
				},
				success: function(response) {
					var cleanedResponse = response.replace(/<[^>]+>|<br \/>/g, '');
					cleanedResponse = cleanedResponse.replace(/Deprecated:.*AccessTokenInterface.php on line \d+/g, '');
					// Parse the cleaned JSON response
					var result = JSON.parse(cleanedResponse);
					window.location.href = 'https://bookings.sightscape.com';
				},
				error: function(error) {
					console.log(error);
				}
			});
		});
	});


	jQuery(document).ready(function () {

		// Initial update based on the initial selected value
		var initialSelectedValue = jQuery('.gt_selector').val();
	
		// Check if the selected value is 'en|ar' initially
		if (initialSelectedValue === 'ar|ar') {
			// Add 'arabic' class to elements with class 'translate-label' and 'translate-input'
			jQuery('body').find('div, label, input').addClass('arabic');
		}else{
			jQuery('body').find('div, label, input').addClass('english');

		}
	
		// Attach a change event listener to the language selector
		jQuery('.gt_selector').on('change', function () {
			// Get the selected value
			var selectedValue = jQuery(this).val();
	
			// Remove 'arabic' class from elements
			jQuery('body').find('div, label, input').removeClass('arabic');
	
			// Check if the selected value is 'en|ar'
			if (selectedValue === 'ar|ar') {
	
				// Add 'arabic' class to elements within the body
				jQuery('body').find('div, label, input').addClass('arabic');
			}else{
				jQuery('body').find('div, label, input').addClass('english');
	
			}
		});


		jQuery('.submit_pass_request').on('click', function() {
			// Clear previous error messages
			jQuery('span.error').remove();

			// Get input values
			var passReferStartTime = jQuery('#pass_refer_start_time').val();
			var passReferEndTime = jQuery('#pass_refer_end_time').val();
			var passPhone = jQuery('#pass_phone').val();
			var pass_event_id = jQuery('#pass_event_id').val();
			var pass_post_id = jQuery('#pass_post_id').val();
			var language = jQuery('#language').val();
			var valid = true;

			// Validate inputs
			if (passReferStartTime === "") {
				jQuery('<span class="error">This field is required</span>').insertAfter('#pass_refer_start_time');
				valid = false;
			}

			if (passReferEndTime === "") {
				jQuery('<span class="error">This field is required</span>').insertAfter('#pass_refer_end_time');
				valid = false;
			}

			if (passPhone === "") {
				jQuery('<span class="error">This field is required</span>').insertAfter('#pass_phone');
				valid = false;
			}
			// If valid, make AJAX request
			if (valid) {
				jQuery.ajax({
					url: custom_script_vars.ajaxurl,
					method: 'POST',
					data: {
						pass_refer_start_time: passReferStartTime,
						pass_refer_end_time: passReferEndTime,
						action: 'pass_reference_call',
						pass_phone: passPhone,
						pass_event_id: pass_event_id,
						pass_post_id: pass_post_id,
						language: language
					},
					success: function(response) {
						if(language == 'arabic'){
							var swaltitle = 'طلب معاودة الاتصال';
							var swaltext = 'تم إرسال طلب معاودة الاتصال إلى المالك';
						}else{
							var swaltitle = 'Callback Request';
							var swaltext = 'Your callback request has been sent to the owner';
						}

						Swal.fire({
							icon: 'success',
							title: swaltitle,
							text: swaltext,
							showConfirmButton: false,
						timer: 2000
						}).then(() => {
							location.reload();
						});
					},
					error: function(xhr, status, error) {
						if(language == 'arabic'){
							var swaltitle = 'طلب معاودة الاتصال';
							var swaltext = 'فشل طلب معاودة الاتصال بك';
						}else{
							var swaltitle = 'Callback Request';
							var swaltext = 'Your callback request failed';
						}
						Swal.fire({
							icon: 'error',
							title: swaltitle,
							text: swaltext,
							showConfirmButton: false,
								timer: 2000
						});
					}
				});
			}
		});
	});
	

})( jQuery );
