<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/public
 * @author     Techy Trion <testingemailer1212@gmail.com>
 */
class Event_Booking_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Booking_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Booking_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/event-booking-public.css', array(), time(), 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Booking_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Booking_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
			
		 if ( ! wp_script_is( 'jquery.min.js', 'enqueued' )) {
			wp_enqueue_script('jquery-min-mjs','https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js?v=' . time());
        }
		wp_enqueue_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js', array(), time(), true);
		wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', array(), null, true);
		wp_enqueue_style('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css');
		wp_enqueue_style('toastr', 'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css' ,array(), time(), 'all');
		wp_enqueue_script('sweetalertJS', 'https://cdn.jsdelivr.net/npm/sweetalert2@11.10.5/dist/sweetalert2.all.min.js', array(), time(), true);wp_enqueue_script('toastrJS', 'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js', array(), time(), true);

		wp_enqueue_script('jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js', array(),time(), true);
		wp_enqueue_script('jquery-timepicker', 'https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js', array(),time(), true);

		// Enqueue SweetAlert
	
		wp_enqueue_script('timepikerjs', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.14.1/jquery.timepicker.js', array(), null, true);
		wp_enqueue_style('timepikercss', 'https://cdnjs.cloudflare.com/ajax/libs/datepicker/0.6.5/datepicker.min.css');
		// https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js
		
		
		// Enqueue jQuery UI
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
		// Enqueue the script
		wp_enqueue_script('custom-script', plugin_dir_url( __FILE__ ) . 'js/event-booking-public.js', array( 'jquery' ), time(), false );

		// Check if the option exists and is not empty
		if ($customer_booking_cancellation_alert = get_field('customer_booking_cancellation_alert', 'option')) {
			// Localize the script with the alert message
			wp_localize_script('custom-script', 'custom_script_vars', array(
				'ajaxurl' => admin_url('admin-ajax.php'),
				'siteurl' => site_url(),
				'customer_booking_cancellation_alert' => $customer_booking_cancellation_alert
			));
		} else {
			// Handle the case where the alert message is not available
			$customer_booking_cancellation_alert = ""; // Set an empty string as default
			wp_localize_script('custom-script', 'custom_script_vars', array(
				'ajaxurl' => admin_url('admin-ajax.php'),
				'siteurl' => site_url(),
				'customer_booking_cancellation_alert' => $customer_booking_cancellation_alert
			));
		}



	}

}
