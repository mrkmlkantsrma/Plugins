<?php 
if (is_user_logged_in()) {
    wp_redirect(home_url('/profile')); // Change '/dashboard' to your desired redirect URL
    exit();
}else{ ?>
<div class="form-container">
    <div class="heading_form">
        <h3>يسجل </h3>
        <p>يرجى إدخال تفاصيل التسجيل الخاصة بك لبوابة الحجز</p>
    </div>
        
<form id="signin_form" class="register-form" method="post">
   <div class="input-fields_item reg_fields">
      <div class="input-field reg_field">
         <div class="input-field_lebel field_label">
            <label for="first_name">الاسم الأول</label>
         </div>
         <div class="input-field_input field_input">
            <input type="text" name="first_name" name="first_name" required>
         </div>
      </div>
      <div class="input-field reg_field">
         <div class="input-field_lebel field_label">
            <label for="last_name">اسم العائلة</label>
         </div>
         <div class="input-field_input field_input">
            <input type="text" name="last_name"  name="last_name">
         </div>
      </div>
   </div>
   <div class="input-fields_item reg_fields">
      <div class="input-field reg_field">
         <div class="input-field_lebel field_label">
            <label for="email">بريد إلكتروني</label>
         </div>
         <div class="input-field_input field_input">
            <input type="email" name="email" name="email" required>
         </div>
      </div>
      <div class="input-field reg_field">
         <div class="input-field_lebel field_label">
            <label for="phone">رقم الهاتف المحمول</label>
         </div>
         <div class="input-field_input field_input">
            <input type="text" name="phone" name="phone">
         </div>
      </div>
   </div>
   <div class="input-fields_footer reg_field_footer">
      <input type="submit" name="submit_registration" value="تسجيل جديد">
   </div>
</form>
</div>
<?php } ?>