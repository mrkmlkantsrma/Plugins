<?php
wp_head();
$events = get_posts(array(
    'post_type' => 'event',
    'posts_per_page' => -1,
));
?>
<div class="Edit_event_container">
    <div class="event-container">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Attraction Id</th>
                    <th>Attraction Name</th>
                    <th>Action</th>
                </tr>
            </thead>
                <tbody>
                    <?php
                    global $wpdb;
                    foreach ($events as $event) {
                        $event_id = $event->ID;
                        $query = $wpdb->prepare(
                            "SELECT * FROM $wpdb->postmeta WHERE post_id = $event_id AND meta_key = 'event_api_id'"
                        );
                        $postId_arr = $wpdb->get_results($query);
                        $postId = $postId_arr[0]->meta_value;
                        $event_title = $event->post_title;
                        $current_user_id = get_current_user_id();
                        $vendor_user_id = get_field('vendor', $event->ID);
                        if ($current_user_id === $vendor_user_id) {
                        ?>
                        <tr>
                            <td><?php echo $postId; ?></td>
                            <td><?php echo $event_title; ?></td>
                            <td><a class="edit-event-page" href="<?php echo home_url().'/wp-admin/post.php?post='.$event_id; ?>&action=edit">Edit</a></td>
                            <!-- <td><button class="edit-event" data-event-id="<?php // echo $event_id; ?>">Edit</button></td> -->
                        </tr>
                    <?php } } ?>
            </tbody>
        </table>
    </div>
    <!-- Popup container -->
    <div id="edit-event-popup" style="display: none;">
        <div class="popup-content">
            <div class="close_popup_btn"><button class="closePopup">X</button></div>
            <form id="edit-event-form">
                <!-- Repeater fields -->
                <div class="repeater-container">
                    <div class="repeater-fields">
                        <!-- Input fields will be populated dynamically using JavaScript -->
                    </div>
                    <!-- <button class="add-row">Add Field</button> -->
                </div>
                <input type="hidden" id="event-id" name="event_id" value="">
                <button type="submit">Save Changes</button>
            </form>
        </div>
    </div>
</div>






<?php
wp_footer();