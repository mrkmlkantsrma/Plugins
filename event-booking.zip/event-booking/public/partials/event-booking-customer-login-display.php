<?php 
if (is_user_logged_in()) {
    // echo "ufyoieuh"; die;
    wp_redirect(home_url('/profile')); // Change '/dashboard' to your desired redirect URL
    exit();
}else{ ?>
<div class="form-container">
        <div class="heading_form">
            <h3>Login</h3>
            <p>Please enter your details</p>
        </div>
        <form id="loginForm" class="login-form" method="post">
            <div class="input-fields_item reg_fields">
                <div class="input-field login_field">
                    <div class="input-field_lebel field_label">
                        <label for="usernameInput">Username:</label>
                    </div>
                    <div class="input-field_input field_input">
                        <input type="text" id="usernameInput" name="username" required>
                    </div>
                </div>
                <div class="input-field login_field">
                    <div class="input-field_lebel field_label">
                        <label for="passwordInput">Password:</label>
                    </div>
                    <div class="input-field_input field_input">
                        <input type="password" id="passwordInput" name="password" required><br>
                    </div>
                </div>
            </div>
            <div class="forget-rember-box">
                <div class="forget-rember-box_checkbox">
                    <input type="checkbox" id="remember_me" name="remember_me" value="1">
                    <label class="inline" for="remember_me"><span></span>Remember Me</label>
                </div>
                <div class="forget-rember-box-inner">
                    <a href="#" class="forget_btn">Forgot Password</a>
                </div>
            </div>
            <div class="input-fields_footer login_field_footer">
                <input type="submit" name="login" value="Login">
            </div>
        </form>
    </div>
<?php } ?>