<div class="card">
    <div class="content">
        <img src="<?php echo site_url(); ?>/wp-content/plugins/event-booking/public/dummy-user.png" alt="" title="" />
        <h3>Hello, <?php echo esc_html(wp_get_current_user()->user_login); ?></h3>
    </div>
</div>
