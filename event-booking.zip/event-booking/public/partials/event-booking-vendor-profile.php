  <?php if (is_user_logged_in()) { ?>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" type="text/css" media="all" />
        <link rel="stylesheet" href="https://bookings.sightscape.com/wp-content/plugins/event-booking/public/css/event-profile-public.css?v=<?php echo time(); ?>" type="text/css" media="all" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <?php $current_user = wp_get_current_user();
        if (current_user_can('vendor')) { ?>

          <div class="admin-panel">
            <div class="slidebar">
                <ul>
                  <li><a href="" name="tab2"><i class="fa fa-calendar"></i>Attractions</a></li>
                  <li><a href="" name="tab3"><i class="fa fa-wrench"></i>Edit Attractions</a></li>
                  <!-- <li><a href="" name="tab4"><i class="fa fa-picture-o"></i>Portfolio</a></li> -->
                  <!-- <li><a href="" name="tab5"><i class="fa fa-file-video-o"></i>Blog / News</a></li> -->
                  <li><a href="" id="logoutButton" ><i class="fa fa-sign-out"></i>Logout</a></li>
                </ul>
            </div>
            <div class="main">
                <div class="tab-div" id="tab2">
                  <section class="profile-section">
                      <h2 class="header">Attractions</h2>
                      <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-vendor-all-events.php'; ?></div>
                  </section>
                </div>
                <div class="tab-div" id="tab3">
                  <section class="profile-section">
                      <h2 class="header">Edit Attractions</h2>
                      <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-vendor-edit-events.php'; ?></div>
                  </section>
                </div>
                <!-- <div class="tab-div" id="tab4"><section class="profile-section"><h2 class="header">Portfolio</h2></section></div> -->
                <!-- <div class="tab-div" id="tab5"><section class="profile-section"><h2 class="header">Blog /news</h2></section></div> -->

            </div>
            <!-- <form id="logoutForm" method="post">
                <button type="submit"  name="logout">Logout</button>
                </form> -->
          </div>

<?php } else if(current_user_can('subscriber')){ ?>

           <div class="admin-panel">
              <div class="slidebar">
                  <ul>
                
                      <li><a href="" name="tab2"><i class="fa fa-calendar"></i>Approved Bookings</a></li>
                    <li><a href="" name="tab3"><i class="fa fa-calendar"></i>Pending Bookings</a></li>
                    <li><a href="" name="tab4"><i class="fa fa-calendar"></i>Cancled Bookings</a></li>
                    <li><a href="" id="logoutButton" ><i class="fa fa-sign-out"></i>Logout</a></li>
                  </ul>
              </div>
              <div class="main">
                  <div class="tab-div" id="tab2">
                    <section class="profile-section" id="approved-status">
                        <h2 class="header">Approved</h2>
                        <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-customer-all-bookings.php'; ?></div>
                    </section>
                  </div>
                  <div class="tab-div " id="tab3">
                    <section class="profile-section" id="pending-status" >
                       <h2 class="header">Pending Bookings</h2>
                       <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-customer-all-bookings.php'; ?></div>
                    </section>
                 </div>
                  <div class="tab-div" id="tab4">                
                    <section class="profile-section" id="cancel-status">
                       <h2 class="header">Cancled Bookings</h2>
                       <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-customer-all-bookings.php'; ?></div>
                    </section>
                 </div>
                 <div id="booking-selectedpersons-popup" class="modal">

                    <!-- Modal content -->
                    <div class="booking-selectedpersons-modal-content">
                      <span class="close">&times;</span>
                      <h2>Additional Person Info</h2>
                      
                    </div>

                  </div>

              </div>
              <!-- <form id="logoutForm" method="post">
                  <button type="submit"  name="logout">Logout</button>
                  </form> -->
            </div>
            <?php 
        }else if(current_user_can('administrator')){ ?>

          <div class="admin-panel">
          <div class="slidebar">
             <ul>
       
                <li><a href="" name="tab2"><i class="fa fa-calendar"></i>Approved Bookings</a></li>
                <li><a href="" name="tab3"><i class="fa fa-calendar"></i>Pending Bookings</a></li>
                <li><a href="" name="tab4"><i class="fa fa-calendar"></i>Cancled Bookings</a></li>
                <li><a href="" id="logoutButton" ><i class="fa fa-sign-out"></i>Logout</a></li>
             </ul>
          </div>
          <div class="main">

             <div class="tab-div" id="tab2">
              
                <section class="profile-section" id="approved-status">
                   <h2 class="header">Approved Bookings</h2>
                   <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-Admin-all-bookings.php'; ?></div>

                </section>
             </div>
              <div class="tab-div " id="tab3">
                <section class="profile-section" id="pending-status" >
                   <h2 class="header">Pending Bookings</h2>
                   <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-Admin-all-bookings.php'; ?></div>
                </section>
             </div>
              <div class="tab-div" id="tab4">
            
                <section class="profile-section" id="cancel-status">
                   <h2 class="header">Cancled Bookings</h2>
                   <div class="main-outer-dashbaord"><?php require event_booking_path. 'public/partials/event-booking-Admin-all-bookings.php'; ?></div>
                </section>
             </div>
             <div id="booking-selectedpersons-popup" class="modal">
                <div class="booking-selectedpersons-modal-content">
                  <span class="close">&times;</span>
                  <h2>Additional Person Info</h2>
                </div>
              </div>
              <div id="booking-edit-booking-popup" class="modal">
                <div class="booking-edit-booking-modal-content">
                  <span class="close">&times;</span>
                  <h2>Edit Booking Info</h2>
                </div>
              </div>
          </div>
          <!-- <form id="logoutForm" method="post">
             <button type="submit"  name="logout">Logout</button>
             </form> -->
       </div>
      <?php } ?>
<?php } else { ?>
<script>
  window.location.href = "<?php echo home_url('/login'); ?>";
</script>
<?php
} 

?>

<script>


    $(document).ready(function () {
        // Logout button click event
        $('#logoutButton').on('click', function () {
            console.log("ghdfdv");
            $.ajax({
              url: custom_script_vars.ajaxurl,
                type: 'POST',
                data: {
                    action: 'custom_logout',
                },
                success: function (response) {
                  window.location.href = '<?php echo home_url(); ?>';
                },
                error: function (error) {
                    // Handle the error
                    console.error('Error logging out:', error);
                }
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
  $(".main .tab-div").hide(); 
  // Cache tout les textes et les sous-menu

  $(".slidebar li:first").attr("id","active");

 var tab_name = $(".slidebar ul li:first-child a").attr('name');
    console.log(tab_name);
  // Ajoute la class active au premier menu
   var sectionId = $('#' + tab_name + ' section.profile-section').attr('id');

      $('.booking-list-table tbody tr').each(function() {
          var trId = $(this).attr('id');
       
         

          if (trId !== sectionId) {
             console.log('here');
              $('tr#' + trId).hide();
           } else if(trId == sectionId) {
              $('tr#' + trId).show();
          }else{

          } 
       
      });
  $(".main .tab-div:first").fadeIn(); 
  // Montre le premier texte à l'apparition de la page
  

  $('.slidebar a').click(function(e) {
      e.preventDefault();
     if ($(this).closest("li").attr("id") == "active"){ 
          //si le menu cliquer est déjà ouvert.
       return       
     }else{             
       $(".main .tab-div").hide(); 
          // Cache tous les éléments

        $(".slidebar li").attr("id","");  
          // Rénitialise tout les menu active
   
        $(this).parent().attr("id","active"); 
          // active le parent du li selectionner
      
      var tab_name = $(this).attr('name');
  
      var sectionId = $('#' + tab_name + ' section.profile-section').attr('id');

      $('.booking-list-table tbody tr').each(function() {
          var trId = $(this).attr('id');
         

          if (trId !== sectionId) {
           
              $('tr#' + trId).hide();
           } else if(trId == sectionId) {
              $('tr#' + trId).show();
          }else{

          } 
     
      });


        $('tr#'+sectionId+"-status").fadeIn();

        $('#' + $(this).attr('name')).fadeIn(); 
          // Montre le texte
        }
     
    
  });

});
</script>

