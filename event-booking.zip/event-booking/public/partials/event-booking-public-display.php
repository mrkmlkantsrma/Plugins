T<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Event_Booking
 * @subpackage Event_Booking/public/partials
 */
?>
<?php
$atts = shortcode_atts(
    array(
        'post_id' => '', // Default value
    ),
    $atts,
    'event-form'
);

// Get the post ID from the attribute
$post_id = $atts['post_id'];
echo '<pre>';
print_r($atts);
echo '</pre>';

$api_url =get_option('api_url');// 'https://sightscape.com/API/booking_system_API.php';
$auth_key =get_option('api_key'); //'c37e2cf8241123dc716a18c97f74c685dd2731132d6b72950d20f022c97fcceb';
// echo $auth_key; echo $auth_key;
$validation_result = validate_api_credentials($api_url, $auth_key);
// echo "hererhhgreu";

if($validation_result['success']) {

    $cities = $validation_result['data']['data']['city'];

    ?>
    <form id="eventForm">
        <div class="booking_form_outer">
            <div class="booking_form_inner">
                <div class="booking_form_item">
                    <div class="booking_form_item_inner">
                        <label for="city"><?php esc_html_e( 'City:', 'business-conference' ); ?></label>
                        <select id="city" name="city" required>
                            <option value=""><?php esc_html_e( 'Select City', 'business-conference' ); ?></option>
                            <?php foreach ($cities as $city) { ?>
                                <option value="<?php echo $city['city_id']; ?>"><?php echo $city['name_en']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="booking_form_item">
                    <div class="booking_form_item_inner" id="eventContainer" style="display: none;">
                        <label for="eventId"><?php esc_html_e( 'Event:', 'business-conference' ); ?></label>
                        <select id="eventId" name="eventId" required></select>
                    </div>
                </div>
                <div class="booking_form_item">
                    <div class="booking_form_item_inner">
                        <label for="datepicker"><?php esc_html_e( 'Date & Time:', 'business-conference' ); ?></label>
                        <input type="datetime-local" id="datepicker" name="datepicker" required>
                    </div>
                </div>
                <div class="booking_form_item">
                    <div class="booking_form_item_inner">
                        <label for="name"><?php esc_html_e( 'Username', 'business-conference' ); ?></label>
                        <input type="text" id="fname" name="fname" required>
                    </div>
                    <div class="booking_form_item_inner">
                        <label for="lname"><?php esc_html_e( 'Last Name:', 'business-conference' ); ?></label>
                        <input type="text" id="lname" name="lname" required>
                    </div>
                </div>
                <div class="booking_form_item">
                    <div class="booking_form_item_inner">
                        <label for="email"><?php esc_html_e( 'Email:', 'business-conference' ); ?></label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="booking_form_item_inner">
                        <label for="phone"><?php esc_html_e( 'Phone:', 'business-conference' ); ?></label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>
                </div>
                <div class="booking_form_footer booking_form_button">
                    <button type="submit"><?php esc_html_e( 'Submit', 'business-conference' ); ?></button>
                </div>
            </div>
        </div>
    </form>

    <div id="input_details"></div>
<?php } else {
    echo "Something went wrong. Please make sure you have added the API key and URL correctly, or check if your API key is valid.";
} ?>


