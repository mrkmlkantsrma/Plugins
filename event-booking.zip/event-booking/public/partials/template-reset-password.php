<?php wp_head(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.5/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.5/dist/sweetalert2.all.min.js"></script>

<style>
    div#wpadminbar {
    display: none !important;
}
#sidebar-label {
    display: none;
    padding: 10px 0 0 0;
}
#person-label {
    display: none;
}
.booking_form_item_inner_foot{
    text-align: center;
}
.booking_form_item_inner_foot input[type="submit"] {
    padding: 7px 10px 7px 10px;
    border-radius: 5px;
    background: #505ca4;
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    font-family: var(--ff-mont);
    width: auto;
    cursor: pointer;
}

#primary .reset-form-outer{
    max-width: 500px;
    margin: 0 auto;
    margin-top: 100px;
}

@media screen and (max-width: 600px) {
    #primary .reset-form-outer{
        max-width: 300px !important;
        margin: 0 auto;
        margin-top: 100px !important;
    }
    .booking_form_item_inner_foot input[type="submit"] {
    width: 90% !important;
}
.reset-form-outer .booking_form_outer {

    padding: 50px 20px;
}

.reset-password--page + .gtranslate_wrapper > .gt_switcher_wrapper {
    width: 100%;
    text-align: center;
    position: absolute !important;
    top: 30px !important;
}

}
.booking_form_inner.arabic h3{
    text-align:end;
}
/* div#sidebar {
    display: none;
} */
</style>
<?php
// Check if the reset key and email parameters are present in the URL
$key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
$email = isset($_GET['email']) ? sanitize_email($_GET['email']) : '';

if (empty($key) || empty($email)) {
    // Display an error message or redirect to the home page
    echo '<p>Error: Invalid reset link.</p>';
} else {
    // Display the password reset form
    ?>
    <div id="primary" class="content-area reset-password--page">
        <main id="main" class="site-main" role="main">
            <div id="event_booking_form_outer" class="event_booking_form_outer reset-form-outer" >
                <form id="reset-password-form">
                    <div class="booking_form_outer">
                        <div class="booking_form_inner">
                        <h3><?php esc_html_e( 'إعادة تعيين كلمة المرور', 'business-conference' ); ?></h3>
                        <div class="booking_form_item">
                            <div class="booking_form_item_inner">
                                <label for="new-password"><?php esc_html_e( 'كلمة المرور الجديدة', 'business-conference' ); ?></label>
                                <input type="password" name="new-password" id="new-password" required>
                                <input type="hidden" name="key" value="<?php echo esc_attr($key); ?>">
                                <input type="hidden" name="email" value="<?php echo esc_attr($email); ?>">
                            </div>
                            <div class="booking_form_item_inner_foot">
                                <input type="submit" value="إعادة تعيين كلمة المرور">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </main>
    </div>
    <?php
}
wp_footer(); ?>
