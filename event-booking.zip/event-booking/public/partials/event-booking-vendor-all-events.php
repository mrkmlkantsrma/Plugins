<?php
wp_head();
?>
<div class="Open-bookings-outer">
    <div id="tab-event" class="tab-content active">
        <?php
        // Query to get all posts of the 'event' post type
        $events_query = new WP_Query(array(
            'post_type' => 'event',
            'post_status' => 'publish',
            'posts_per_page' => -1, // Retrieve all posts
        ));

        // Check if there are any events
        if ($events_query->have_posts()) {
        ?>
        <div class="event-listing-box"> 
            <table class="event-list-table">
                <thead>
                    <tr>
                        <th>Attraction ID</th>
                        <th>Attraction Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($events_query->have_posts()) : $events_query->the_post(); 
                    
                    $current_user_id = get_current_user_id();
                    $vendor_user_id = get_field('vendor', get_the_ID());
                    if ($current_user_id === $vendor_user_id) {
                        $event_id = get_the_ID();
                        $query = $wpdb->prepare(
                            "SELECT * FROM $wpdb->postmeta WHERE post_id = $event_id AND meta_key = 'event_api_id'"
                        );
                        $postId_arr = $wpdb->get_results($query);
                        $postId = $postId_arr[0]->meta_value;
                    ?>
                    <tr class="event-list-items">
                        <td class="event-list-item id-item">
                            <?php echo $postId; ?>
                        </td>
                        <td class="event-list-item title-item" data-event-id="<?php echo get_the_ID(); ?>" >
                            <?php the_title(); ?>
                        </td>
                    <?php 
                    }
                    endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php } ?>


        <div id="event-details-container" style="display: none;">
             <ul class="tabs">
                <li><a href="#" data-status="approved">Approved</a></li>
                <li><a href="#" data-status="pending-to-attraction">Pending</a></li>
                <li><a href="#" data-status="cancel-not-avaliable">Canceled</a></li>
            </ul>
            <table id="user-data-table" class="user-data-table">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Date</th>
                        <th>Time </th>
                        <!-- <th>End event</th> -->
                        <!--             -->
                        <th>Selected persons</th>       
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- User data will be dynamically populated here -->
                </tbody>
            </table>
        </div>
    </div>
</div>
<div id="booking-selectedpersons-popup" class="modal">

  <!-- Modal content -->
  <div class="booking-selectedpersons-modal-content">
    <span class="close">&times;</span>
    <h2>Additional Person Info</h2>
  </div>

</div>

<div id="booking-edit-booking-popup" class="modal">
  <div class="booking-edit-booking-modal-content">
    <span class="close">&times;</span>
    <h2>Edit Booking Info</h2>
  </div>
</div>

<script>

     
    jQuery(document).ready(function () {
      
        // Event delegation for click events on tabs
        $('.tabs').on('click', 'a', function (e) {
            e.preventDefault();
            var status = $(this).data('status');

            filterRows(status);
              $('.tabs li').removeClass('active');
            // Add 'active' class to the parent <li> of the clicked <a>
            $(this).parent('li').addClass('active');
        });

        function filterRows(status) {
            $('#user-data-table tbody tr').each(function () {
                var row = $(this);
                if (status === 'All' || row.hasClass(status)) {
                    row.show();
                } else {
                    row.hide();
                }
            });
        }

    });

</script>
<style>
#event-details-container #user-data-table {
    width: 100%;
    text-align: left;
}
</style>