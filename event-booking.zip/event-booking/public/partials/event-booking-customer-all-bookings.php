<?php
wp_head();

$user_id = get_current_user_id();
$query = $wpdb->prepare(
    "SELECT * FROM $wpdb->prefix" . "booking_events WHERE user_id = %d",
    $user_id
);

$results = $wpdb->get_results($query);

?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="Open-bookings-outer">
    <div id="tab-booking" class="tab-content active">
        <div class="booking-listing-box"> 
            <div class="booking-list-items">
            <?php
                echo '<div class="all-booking-list-item">';
                echo '<table class="booking-list-table">';
                echo '<thead>';
                echo '<tr>';
                echo '<th>Attraction Name</th>';
                echo '<th>Name</th>';
                echo '<th>Email</th>';
                echo '<th>Phone</th>';
                echo '<th>Date</th>';
                echo '<th>Time</th>';
                // echo '<th>End Time</th>';
                echo '<th>Persons</th>';
                echo '<th>Status</th>';
                echo '<th>Action</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                foreach ($results as $item) {
                    $formatted_date = date("d M, Y", strtotime($item->selectedDate));
                    $start_time = date("h:i a", strtotime($item->start_event));
                    // $end_time = date("h:i a", strtotime($item->end_event));

                    $statusCls = 'no-status';
                    if(strtolower($item->isstatus) == 'approved'){
                        $statusCls = 'approved-status';
                    }else if(strtolower($item->isstatus) == 'pending-to-attraction' || strtolower($item->isstatus) == 'pending-pass-verify'){
                        $statusCls = 'pending-status';
                     }else if(strtolower($item->isstatus) == 'cancel-not-avaliable' || strtolower($item->isstatus) == 'cancel-no-pass'){    
                        $statusCls = 'cancel-status';
                    }
                    
                     if($item->user_id>0){
                    echo '<tr id="'.$statusCls.'">';
                    echo '<td>' . $item->event_name . '</td>';
                    echo '<td>' . $item->fname . ' '.$item->lname.'</td>';
                    echo '<td>' . $item->email . '</td>';
                    echo '<td>' . $item->phone . '</td>';
                    echo '<td>' . $formatted_date . '</td>';
                    echo '<td>' . $start_time . '</td>';
                    // echo '<td>' . $end_time . '</td>';
                   
                        echo '<td class="selectedpersons_details" id="'.$item->id.'">' . $item->selectedpersons . '<span class="eye-open"   ><i class="fa fa-eye"></i></td>';
                    
                 
                    echo '<td class="'.$statusCls.'"><p>' . $item->isstatus . '</p></td>';
                    if($statusCls == 'cancel-status'){
                        echo '<td class="cancel-booking"><button class="rejected-booking-btn" data-booking-id="'.$item->id.'" data-booking-id="'.$item->email.'"  data-post-id="'.$item->post_id.'" disabled>Rejected</button></td>';
                    }else{
                        echo '<td class="cancel-booking"><button class="cancel-booking-btn" data-booking-id="'.$item->id.'"  data-user-id="'.$item->user_id.'"  data-post-id="'.$item->post_id.'">Cancel</button></td>';
                    }
                    echo '</tr>';
                }
                }

                echo '</tbody>';
                echo '</table>';
                echo '</div>';
                ?>

            </div>
        </div>
    </div>
</div>



