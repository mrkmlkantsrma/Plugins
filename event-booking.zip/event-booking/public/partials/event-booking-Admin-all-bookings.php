<?php
wp_head();

// // UPDATE `wp_booking_events`SET `isstatus` = 'cancel-not-avaliable' WHERE `isstatus` LIKE 'Canceled';

// // UPDATE `wp_booking_events`SET `isstatus` = 'pending-pass-verify' WHERE `isstatus` LIKE 'Pending';

$user_id = get_current_user_id();
$query = $wpdb->prepare(
    "SELECT * FROM $wpdb->prefix" . "booking_events"
);

$results = $wpdb->get_results($query);

?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="Open-bookings-outer">
    <div id="tab-booking" class="tab-content active">
        <div class="booking-listing-box"> 
            <div class="booking-list-items">
            <?php
                echo '<div class="all-booking-list-item">';
                echo '<table class="booking-list-table">';
                echo '<thead>';
                echo '<tr>';
                echo '<th>Attraction Name</th>';
                echo '<th>Name</th>';
                echo '<th>Email</th>';
                echo '<th>Phone</th>';
                echo '<th>Date</th>';
                echo '<th>Time</th>';
                echo '<th>Edit Time</th>';
                echo '<th>Persons</th>';
                echo '<th>Status</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';
                $statusOptions = array('approved', 'pending-to-attraction', 'cancel-not-avaliable', 'pending-pass-verify', 'cancel-no-pass');
                foreach ($results as $item) {
                    $formatted_date = date("d M, Y", strtotime($item->selectedDate));
                    $start_time = date("h:i a", strtotime($item->start_event));
                    // $end_time = date("h:i a", strtotime($item->end_event));

                    $statusCls = 'no-status';
                    if(strtolower($item->isstatus) == 'approved'){
                        $statusCls = 'approved-status';
                    }else if(strtolower($item->isstatus) == 'pending-to-attraction' || strtolower($item->isstatus) == 'pending-pass-verify'){
                        $statusCls = 'pending-status';
                     }else if(strtolower($item->isstatus) == 'cancel-not-avaliable' || strtolower($item->isstatus) == 'cancel-no-pass'){    
                        $statusCls = 'cancel-status';
                    }

                    if($item->user_id>0){

                    
                        echo '<tr id="'.$statusCls.'">';
                        echo '<td>' . $item->event_name . '</td>';
                        echo '<td>' . $item->fname . ' '.$item->lname.'</td>';
                        echo '<td>' . $item->email . '</td>';
                        echo '<td>' . $item->phone . '</td>';
                        echo '<td>' . $formatted_date . '</td>';
                        echo '<td>' . $start_time . '</td>';
                        echo '<td class="edit_timedate_event" id="'.$item->id.'">Edit <span class="eye-pencil"   ><i class="fa fa-pencil"></i></td>';
                        echo '<td class="selectedpersons_details" id="'.$item->id.'">' . $item->selectedpersons . '<span class="eye-open"   ><i class="fa fa-eye"></i></td>';
                        echo '<td><select name="status"  data-booking-id="'.$item->id.'" data-user-id="'.$item->user_id.'"  data-post-id="'.$item->post_id.'"  >';
                        
                        foreach ($statusOptions as $option) {
                            echo '<option value="' . strtolower($option) . '"';
                            if (strtolower($item->isstatus) == $option) {
                                echo ' selected';
                            }
                            if(strtolower($option) == 'approved'){
                                $optionStatus = 'Approved';
                            }else if(strtolower($option) == 'pending-to-attraction'){
                                $optionStatus = 'Forward to attraction';
                            }else if(strtolower($option) == 'pending-pass-verify'){
                                $optionStatus = 'Pending Pass verify';
                            }else if(strtolower($option) == 'cancel-not-avaliable'){    
                                $optionStatus = 'Cancelled Not available';
                            }else if(strtolower($option) == 'cancel-no-pass'){    
                                $optionStatus = 'Cancelled No pass';
                            }

                            echo '>' . ucfirst($optionStatus) . '</option>';
                        }
                        echo '</select></td>';
                        echo '</tr>';
                    }
                }

                echo '</tbody>';
                echo '</table>';
                echo '</div>';
                ?>

            </div>
        </div>
    </div>
</div>




