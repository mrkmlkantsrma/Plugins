<?php
// get_header();

// while (have_posts()) : the_post();
//     // Your single event content goes here
//     the_title('<h1>', '</h1>');
//     the_content();
// endwhile;

// get_footer();