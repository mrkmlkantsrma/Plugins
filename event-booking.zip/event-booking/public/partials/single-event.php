
<?php echo do_blocks( '<!-- wp:template-part {"slug":"header","area":"header","tagName":"header"} /-->' ); ?>

<?php wp_head(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.5/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.5/dist/sweetalert2.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/ar.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/default.js"></script>


    <!-- <script src=<?php // echo plugin_dir_url( __FILE__ ) ."public/js/flatpickr-master/src/l10n/ar.ts" ?>></script> -->
   
<div class="header-sigle-event">
    <div class="profile-page">
        <?php 
        $profile_button_text_english = get_field('profile_button_text_english', 'option');
        $profile_button_text_arabic = get_field('profile_button_text_arabic', 'option');
        
        ?>
        <a class="profil-btn-eng notranslate" href="<?php  echo site_url();?>/profile"><?php echo $profile_button_text_english; ?></a>
        <a class="profil-btn-arabic notranslate" href="<?php  echo site_url();?>/profile"><?php echo $profile_button_text_arabic; ?></a>
    </div>
</div>
<style>
button.swal2-cancel.swal2-styled.swal2-default-outline,button.swal2-confirm.swal2-styled.swal2-default-outline{border-radius:5px;color:#fff;text-decoration:none;font-size:14px;font-family:var(--ff-mont);display:inline-block}.booking_form_item.arabic input,.booking_form_item_inner.arabic textarea#additional_note{text-align:end}.booking_form_bokking_content.arabic .arebic_content.arabic p{text-align:center}div#sidebar.arabic{flex-direction:row-reverse}#sidebar.english{justify-content:start}#sidebar.english.arabic{justify-content:end}div#wpadminbar{display:none!important}#sidebar-label{display:none;padding:10px 0 0}#person-label,.booking_form_bokking_content .arebic_content,.booking_form_bokking_content.arabic .engish_content.arabic,.booking_form_button .book-btn-arabic,.booking_form_button.arabic .book-btn-eng,.booking_form_item.arabic h5.en,.booking_form_item.english h5.ar,.booking_form_item_inner .field-label-arabic,.booking_form_item_inner .option-arabic,.booking_form_item_inner.arabic .field-label-english,.booking_form_item_inner.arabic .option-english,.profile-page .profil-btn-arabic,.profile-page.arabic .profil-btn-eng,header.wp-block-template-part nav{display:none}.booking_form_bokking_content.arabic .arebic_content.arabic,.booking_form_item.arabic h5.ar,.booking_form_item_inner.arabic .field-label-arabic,.booking_form_item_inner.arabic .option-arabic{display:block}.wp-block-columns.is-layout-flex.wp-container-core-columns-is-layout-4.wp-block-columns-is-layout-flex a{color:#fff}#input_details.arabic span.details-data span.tm_name,.time-slot span.tm_name{padding:0 5px 0 0}@media (min-width:600px){.gt_switcher_wrapper,.header-sigle-event{z-index:9999!important}}@media (max-width:600px){.header-sigle-event{top:92px!important;z-index:999!important}.gt_switcher_wrapper{top:85px!important;z-index:999!important}.wp-container-core-group-is-layout-2.wp-container-core-group-is-layout-2{justify-content:center}div#event_booking_form_outer{top:40px!important;z-index:9999999999!important;position:relative!important;margin-bottom:120px}:where(body .is-layout-flex){gap:1rem}.sociallinks-footer .wp-block-column.is-layout-flow.wp-block-column-is-layout-flow{flex-basis:11%!important}.wp-block-group.alignwide.is-layout-flow.wp-block-group-is-layout-flow,footer .wp-block-group.has-global-padding.is-layout-constrained.wp-block-group-is-layout-constrained{padding-top:0!important}.wp-block-columns.is-layout-flex.wp-container-core-columns-is-layout-4.wp-block-columns-is-layout-flex a{color:#fff}footer .wp-block-columns.is-layout-flex.wp-container-core-columns-is-layout-2.wp-block-columns-is-layout-flex{display:none}}.post-content.arebic_content.notranslate.arabic>*{text-align:-webkit-right;text-align:start}.booking_form_button.arabic .book-btn-arabic,.profile-page.arabic .profil-btn-arabic{display:inline}.booking_form_item.arabic .option-option,.booking_form_item_inner.arabic select#personDropdown{text-align:unset!important;text-align:-webkit-right!important}.booking_form_item.arabic select{text-align:unset!important;text-align:-webkit-right!important;direction:rtl}span.tm_nmbr{order:1}.time_ara{display:flex}#sidebar button.time-slot.time-slot-active{background:#4d5ba1!important}.loader--ellipsis div{background:#00539f;position:absolute;top:27px;animation-timing-function:cubic-bezier(0,1,1,0);border-radius:50%;height:11px;width:11px}.loader--ellipsis{display:inline-block;position:relative;height:64px;width:64px}.loader--ellipsis div:first-child{left:6px;animation:.6s infinite loader--ellipsis1}.loader--ellipsis div:nth-child(2){left:6px;animation:.6s infinite loader--ellipsis2}.loader--ellipsis div:nth-child(3){left:26px;animation:.6s infinite loader--ellipsis2}.loader--ellipsis div:nth-child(4){left:45px;animation:.6s infinite loader--ellipsis3}@keyframes loader--ellipsis1{0%{transform:scale(0)}100%{transform:scale(1)}}@keyframes loader--ellipsis3{0%{transform:scale(1)}100%{transform:scale(0)}}@keyframes loader--ellipsis2{0%{transform:translate(0,0)}100%{transform:translate(19px,0)}}button.swal2-cancel.swal2-styled.swal2-default-outline{background-color:red!important;margin-top:-2px;padding:7px 10px}button.swal2-confirm.swal2-styled.swal2-default-outline{padding:7px 10px;background:#505ca4!important}.swal2-icon.swal2-warning{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;color:#4d5ba1;border-color:#4d5ba1;font-size:23px;line-height:80px;text-align:center}
.details_head_ans .details-data-heading {
    font-weight: 700;
}
.question_list p {
    font-weight: 700;
    padding: 0 0 0 20px;
}
.question_list span {
    font-weight: 300;
}
.particpent_list p {
    display: grid;
    margin: 0;
    padding: 10px 0 0 30px;
}
.particpent_list p:after {
    content: "";
    border-bottom: 1px solid #c0bfbf;
    width: 100%;
}
#input_details.arabic .question_list p {
    padding: 0 20px 0 0px;
}
#input_details.arabic .particpent_list p {
    padding: 10px 30px 0 30px;
}

.booking_default_form_box{
    display: none;
}
.pass_avaliable_no_option {

}
.pass_avaliable_option {
    text-align: center;
}
.pass_avaliable_no_option_left {
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
button.button_pass_avaliable {
    padding: 8px 20px 8px 20px;
    border-radius: 5px;
    background: #505ca4;
    margin: 0 10px 5px 10px;
    color: #fff;
    border: none;
    text-decoration: none;
    font-size: 14px;
    cursor: pointer;
    font-family: var(--ff-mont);
}
.button_pass_avaliable.activated {
    background: #eda42e !important;
}
.booking_pass_form_item_inner #pass_phone {
    padding: 10px 15px;
    border-radius: 6px;
    width: 70%;
    margin: 2px 0px;
    border: 1px solid #505ca4;
    font-size: 16px;
    transition: all .3s ease;
}
.booking_pass_form_item_inner #pass_refer_time {
    padding: 10px 15px;
    border-radius: 6px;
    width: 100%;
    cursor: pointer;
    margin: 2px 0px;
    border: 1px solid #505ca4;
    font-size: 16px;
    transition: all .3s ease;
}
.pass_avaliable_heading_english.arabic {
    display: none;
}.pass_avaliable_buttons_english.arabic {
    display: none;
}
.field-label-english.arabic {
    display: none;
}
.pass_avaliable_no_heading_english.arabic {
    display: none;
}
.pass_avaliable_yes_heading_english.arabic {
    display: none;
}
.pass_avaliable_yes_form_english.english.arabic {
    display: none;
}
.pass_avaliable_yes_form_english.arabic {
    display: none;
}
.pass_avaliable_yes_form_arabic.arabic {
    display: block;
}
.pass_avaliable_yes_form_english.english {
    display: block;
}
.pass_avaliable_yes_form_arabic.english.arabic {
    display: block;
}
.pass_avaliable_yes_form_arabic.english {
    display: none;
}
.no_pass_submit.arabic .pass_request_btn_english {
    display: none;
}
.pass_avaliable_heading_arabic.english {
    display: none;
}
.pass_avaliable_heading_arabic.arabic {
    display: block;
    text-align: center;
}
.pass_avaliable_buttons_arabic.english {
    display: none;
}
.pass_avaliable_buttons_arabic.arabic {
    display: block;
    text-align: center;
}
.field-label-arabic.english {
    display: none;
}
.booking_pass_form_item label.arabic {
    text-align: center;
}
.field-label-arabic.arabic {
    display: block;
}
.pass_avaliable_no_heading_arabic.english {
    display: none;
}
.pass_avaliable_no_heading_arabic.arabic {
    display: block;
}
.pass_avaliable_no_heading_arabic.arabic {
    display: block;
}
.pass_avaliable_yes_heading_arabic.english {
    display: none;
}
.pass_avaliable_yes_heading_arabic.arabic {
    display: block;
}
.no_pass_submit.english .pass_request_btn_arabic {
    display: none;
}
.no_pass_submit.arabic .pass_request_btn_arabic {
    display: block;
}
.pass_avaliable_yes_form.arabic .pass_name_option_english {
    display: none;
}
.pass_avaliable_yes_form.english .pass_name_option_arabic {
    display: none;
}
.pass_avaliable_yes_form.arabic .pass_name_option_arabic {
    display: block;
}
.pass_avaliable_yes_form.english .pass_name_option_english  {
    display: block;
}
.pass_avaliable_no_option.pass_hide, .pass_avaliable_yes_option.pass_hide{
    display: none;
} 
.field-form-english.arabic {
    display: none;
}
.field-form-arabic.english{
    display: none;
}
.field-form-english.english {
    display: block;
}
.field-form-arabic.english.arabic {
    display: block;
}
.field-form-english.english.arabic {
    display: none;
}
.field-form-arabic.arabic{
    display: block;
}
.pass_avaliable_no_option.pass_show{
    display: block;
}
.pass_avaliable_yes_option.pass_show{
    display: block;
} 
.pass_avaliable_yes_form select {
    padding: 15px;
    border-radius: 6px;
    width: 100%;
    margin: 2px 0px;
    border: 1px solid #505ca4;
    font-size: 16px;
    transition: all .3s ease;
    height: 53px;
    background: #fff;
    color: #000000;
}
.booking_pass_item {
    padding: 0px 10px 30px 10px;
}
.booking_pass_form_item_inner {
    display: flex;
    justify-content: space-between;
    padding: 0 0 10px 0;
    position: relative;
    align-items: center;
}
.booking_pass_form_item .error {
    position: absolute;
    left: 30%;
    font-size: 10px;
    top: -13px;
    color: #f30000;
    font-weight: 600;
}
.submit_pass_request {
    padding: 7px 10px 7px 10px;
    border-radius: 5px;
    margin: 7px 0 7px 0;
    background: #15b731;
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    font-family: var(--ff-mont);
}
.pass_avaliable_yes_form.arabic select {
    text-align: -webkit-right !important;
    direction: rtl;
}
.booking_pass_item.arabic > * {
    text-align: -webkit-right !important;
    direction: rtl;
}
.no_pass_submit {
    display: flex;
    justify-content: space-between;
    width: 70%;
    gap: 15px;
    align-items: center;
}
.no_pass_submit input {
    padding: 10px 15px;
    border-radius: 6px;
    width: 33%;
    margin: 2px 0px;
    border: 1px solid #505ca4;
    font-size: 16px;
    transition: all .3s ease;
}
@media (max-width:500px){
    .booking_pass_form_item_inner{
        display:block;
    }
    .pass_avaliable_no_option_left{
        display:block;
    }
    .no_pass_submit{
        display:block;
        width: 100%;
    }
    .no_pass_submit input {
        width: 100%;
    }
    .booking_pass_form_item_inner #pass_phone {
        width: 100%;
    }
    .booking_pass_form_item.english {
        text-align: center;
    }
    .no_pass_submit input#pass_refer_end_time {
        margin-bottom: 40px;
    }
    .pass_avaliable_no_heading {
        text-align: center;
    }
}
</style>
<?php
$url = "http" . (isset($_SERVER['HTTPS']) ? "s" : "") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$url = rtrim($url, '/');

    if (preg_match('/(\d+)$/', $url, $matches)) {
        $event_id = $matches[1];
        global $wpdb;

        $query = $wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = 'event_api_id' AND meta_value = %s",
            $event_id
        );
        $postId = $wpdb->get_var($query);

            if ($postId) {

                $query = $wpdb->prepare(
                    "SELECT post_id,
                            MAX(CASE WHEN meta_key = 'event_city' THEN meta_value END) AS event_city,
                            MAX(CASE WHEN meta_key = 'vendor' THEN meta_value END) AS vendor,
                    FROM $wpdb->postmeta
                    WHERE post_id = %d
                    GROUP BY post_id",
                    $postId
                );
                
                // Execute the query
                $eventresults = $wpdb->get_results($query, ARRAY_A);

                $table_name = $wpdb->prefix . 'posts';
                // Custom SQL query to retrieve the post title by post ID
                $query = $wpdb->prepare("SELECT post_title FROM $table_name WHERE ID = %d", $postId);

                // Get the post title
                $post_title = $wpdb->get_var($query);


                $min_leadtime = get_field('lead_time_minimum_lead_time', $postId);
                $max_leadtime = get_field('lead_time_maximum_lead_time', $postId);
                $post_image_url = get_the_post_thumbnail_url($postId, 'full');
                $post_content = get_post_field('post_content', $postId);
                $event_name_english = get_post_meta($postId,'event_name_english');
                $attraction_type_arr = get_post_meta($postId,'attraction_type');
                $current_not_available_days = get_post_meta($postId, 'current_month_not_available_days');
                $attraction_type = 'public';
                if($attraction_type_arr){
                    $attraction_type = $attraction_type_arr[0];
                }

                // update_field('event_name_english', $excursion_name_en, $post_id);
                // Weekday names
                $daysOfWeek = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');

                // Array to store the week's values
                $weekValues = array();

                    // Loop through each day of the week
                    foreach ($daysOfWeek as $day) {
                        // Construct repeater field name based on the day
                        $repeaterField = "time_slots_event_{$day}_time_slot";

                        // Retrieve ACF repeater values for the specified post and day
                        $repeaterRows = get_field($repeaterField, $postId);

                        // Initialize an array to store time slot data for the day
                        $dayValues = array();

                        if ($repeaterRows) {
                            // Loop through each row of the repeater
                            foreach ($repeaterRows as $key => $row) {
                                // Retrieve values from each row with keys 0 and 1
                                $avaliable = $row["avaliable"];
                                $minPerson = $row["min_person"];
                                $maxPerson = $row["max_person"];
                                $startEvent = $row["start_event"];
                                // $endEvent = $row["end_event"];

                                // Store values for the time slot in the dayValues array
                                $dayValues[] = array(
                                    'avaliable' => $avaliable,
                                    'min_person' => $minPerson,
                                    'max_person' => $maxPerson,
                                    'start_event' => $startEvent,
                                    // 'end_event' => $endEvent,
                                );
                            }
                        }

                        // Store time slot data for the day in the weekValues array
                        $weekValues[$day] = $dayValues;

                    }

                   $person_data = get_persons_value($postId);
                   // dd($weekValues);

                   
                    $whatsapp_number = get_field('whatsapp_number', 'option');
                    $whatapp_title_text_english = get_field('whatapp_title_text_english', 'option');
                    $whatapp_title_text_arabic = get_field('whatapp_title_text_arabic', 'option');
                                    
                    $callback_title_text_english = get_field('callback_title_text_english', 'option');
                    $callback_title_text_arabic = get_field('callback_title_text_arabic', 'option');

                    $event_label_note = get_field('event_label_note', $postId);
                    $event_label_note_ar = get_field('event_label_note_arabic', $postId);
   

                    $question_answers_event = get_field('question_answers_event', $postId);
                    
                ?>
                <div id="primary" class="content-area">
                    <main id="main" class="site-main" role="main">
                        <div id="event_booking_form_outer" class="event_booking_form_outer" >
                            <form id="eventForm">
                                <div class="booking_form_outer">
                                    <div class="booking_form_inner">
                                        <div class="booking_form_bokking_title">
                                            <div class="bokking_title event_title ">
                                                <label class='event_arabic_name notranslate' for="city"><?php esc_html_e( $post_title, 'business-conference' ); ?></label>
                                                <span class='event_english_name no-translate notranslate'><?php echo $event_name_english[0]; ?></span>
                                            </div>
                                        </div>
                                        <div class="booking_form_bokking_title">
                                            <div class="post-image">
                                                <?php if ($post_image_url) : ?>
                                                    <img src="<?php echo esc_url($post_image_url); ?>" alt="<?php echo esc_attr($post_title); ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="booking_form_bokking_title booking_form_bokking_content">
                                            <div class="post-content arebic_content notranslate">
                                                <?php echo apply_filters('the_content', $post_content); ?>
                                            </div>
                                            <div class="post-content engish_content notranslate">
                                                <?php echo get_field('event_english_description', $postId); ?>
                                            </div>
                                        </div>
                                        <div class="booking_pass_item">
                                            <div class="pass_avaliable_option">  
                                                <div class="pass_avaliable_heading_arabic notranslate">
                                                    <p>هل لديك أي تصريح مرور؟</p>
                                                </div>
                                                <div class="pass_avaliable_heading_english notranslate">
                                                    <p>Do you have any Pass?</p>
                                                </div>                                          
                                                <div class="pass_avaliable_buttons_arabic">
                                                    <button class="button_pass_avaliable notranslate" type="button" data-set="yes">نعم</button>
                                                    <button class="button_pass_avaliable notranslate" type="button" data-set="no">لا يوجد</button>
                                                </div>
                                                <div class="pass_avaliable_buttons_english">
                                                    <button class="button_pass_avaliable notranslate" type="button" data-set="yes">Yes</button>
                                                    <button class="button_pass_avaliable notranslate" type="button" data-set="no">No</button>
                                                </div>
                                            </div>
                                            <div class="pass_avaliable_no_option pass_hide">  
                                                <div class="pass_avaliable_no_option_left">  
                                                    <div class="pass_avaliable_no_heading whatsapp_call">
                                                        <div class="pass_avaliable_no_heading_arabic notranslate"><p><?php echo $whatapp_title_text_arabic ;?></p></div>
                                                        <div class="pass_avaliable_no_heading_english notranslate"><p><?php echo $whatapp_title_text_english ;?></p></div>
                                                    </div>
                                                    <a class="whatsapp_link" target="_blank" href="https://wa.me/<?php echo $whatsapp_number; ?>"><img width="30" src="<?php echo event_booking_url; ?>/public/whatsapp_image.png"></a>
                                                </div>
                                                <div class="pass_avaliable_no_option_right">  
                                                    <div class="pass_avaliable_no_heading normal_callback">
                                                        <div class="pass_avaliable_no_heading_arabic notranslate"><p><?php echo $callback_title_text_arabic; ?></p></div>
                                                        <div class="pass_avaliable_no_heading_english notranslate"><p><?php echo $callback_title_text_english; ?></p></div>
                                                    </div>      
                                                    <?php
                                                        $pass_phone_label_english = get_field('phone_label_english', 'option');
                                                        $pass_phone_label_arabic = get_field('phone_label_arabic', 'option'); 
                                                    ?>                                   
                                                    <div class="pass_avaliable_no_form">
                                                        <div class="booking_pass_form_item">
                                                            <div class="booking_pass_form_item_inner">
                                                                <label for="pass_phone" class="field-label-english notranslate"><?php echo $pass_phone_label_english; ?></label>
                                                                <label for="pass_phone" class="field-label-arabic notranslate"><?php echo $pass_phone_label_arabic; ?></label>
                                                                <input type="number" id="pass_phone" name="pass_phone" value="">
                                                            </div>
                                                            <div class="booking_pass_form_item_inner">
                                                                <label for="pass_refer_time" class="field-label-arabic notranslate">الوقت</label>
                                                                <label for="pass_refer_time" class="field-label-english notranslate">Time</label>
                                                                <div class="no_pass_submit">
                                                                    <input type="time" id="pass_refer_start_time" name="pass_refer_start_time" value="">
                                                                    <div class="field-label-arabic notranslate">إلى</div>
                                                                    <div class="field-label-english notranslate">To</div>
                                                                    <input type="time" id="pass_refer_end_time" name="pass_refer_end_time" value="">
                                                                    <input type="hidden" id="pass_event_id" name="pass_event_id" value="<?php echo $event_id; ?>" readonly>
                                                                    <input type="hidden" id="pass_post_id" name="pass_post_id" value="<?php echo $postId; ?>" readonly>
                                                                    <a href="javascript:void(0);" class="submit_pass_request pass_request_btn_arabic notranslate">إرسال</a>
                                                                    <a href="javascript:void(0);" class="submit_pass_request pass_request_btn_english notranslate">Send</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="pass_avaliable_yes_option pass_hide">  
                                                <div class="pass_avaliable_yes_heading_arabic">
                                                    <p class="notranslate">ما نوع تصريح المرور؟</p>
                                                </div> 
                                                <div class="pass_avaliable_yes_heading_english">
                                                    <p class="notranslate">What type of pass?</p>
                                                </div>  
                                                <?php $attraction_english_passes = get_field('attraction_english_passes', $postId);  ?>  
                                                <?php if(!empty($attraction_english_passes) && $attraction_english_passes){ ?>                               
                                                    <div class="pass_avaliable_yes_form pass_avaliable_yes_form_english">
                                                        <select id="pass_english_name" name="pass_english_name">
                                                            <option value="" class="pass_name_option_english notranslate">Select Pass Name</option>
                                                            <?php foreach ($attraction_english_passes as $englishpassName){
                                                                echo '<option value="'.$englishpassName.'">'.$englishpassName.'</option>';
                                                            } ?>
                                                        </select>
                                                    </div>
                                                <?php } ?>
                                                <?php $attraction_arabic_passes = get_field('attraction_arabic_passes', $postId);  ?>  
                                                <?php if(!empty($attraction_arabic_passes) && $attraction_arabic_passes){ ?>                               
                                                    <div class="pass_avaliable_yes_form pass_avaliable_yes_form_arabic">
                                                        <select id="pass_arabic_name" name="pass_arabic_name">
                                                            <option value="" class="pass_name_option_arabic notranslate">اختر اسم المرور</option>
                                                            <?php foreach ($attraction_arabic_passes as $arabicpassName){
                                                                echo '<option value="'.$arabicpassName.'">'.$arabicpassName.'</option>';
                                                            } ?>
                                                        </select>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>

                                        <div class="booking_default_form_box">
                                            <?php
                                                $select_person_dropdown_label_english = get_field('select_person_dropdown_label_english', 'option');
                                                $select_person_dropdown_label_arabic = get_field('select_person_dropdown_label_arabic', 'option');
                                            ?>
                                            <div class="booking_form_item">
                                                <div class="booking_form_item_inner">                                           
                                                    <select id="personDropdown" name="personDropdown">
                                                        <option value="" selected disabled class="option-person notranslate"><?php echo $select_person_dropdown_label_arabic; ?></option>
                                                            <?php for ($i = $person_data['min_value']; $i <= $person_data['max_value']; $i++) {
                                                                echo "<option value=\"$i\">$i</option>";
                                                            }  ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <?php
                                                $select_date_for_booking_label_english = get_field('select_date_for_booking_label_english', 'option');
                                                $select_date_for_booking_label_arabic = get_field('select_date_for_booking_label_arabic', 'option');

                                            $request_notification = get_field('confirm_booking_request_notification', $postId);

                                            $request_label_english = '';
                                            $request_notification_english = '';
                                            $request_label_arabic = '';
                                            $request_notification_arabic = '';

                                            if($request_notification){
                                                $request_label_english = $request_notification['confirm_booking_label_english'];
                                                $request_notification_english = $request_notification['confirm_booking_request_notification_english'];
                                                $request_label_arabic = $request_notification['confirm_booking_label_arabic'];
                                                $request_notification_arabic = $request_notification['confirm_booking_request_notification_arabic'];
                                            }
                                            ?>

                                            <div class="booking_form_item" id="date_section" style="display:none;">
                                                <div class="booking_form_item_inner">
                                                    <label for="datepicker" class="option-english notranslate"><?php echo $select_date_for_booking_label_english; ?></label>
                                                    <label for="datepicker" class="option-arabic notranslate"><?php echo $select_date_for_booking_label_arabic; ?></label>
                                                    <input type="datetime-local" id="datepicker" name="datepicker" required>
                                                    <div id="sidebar-label">يرجى تحديد الوقت</div>
                                                    <div id="sidebarloader"></div>
                                                    <div id="sidebar"></div>
                                                    <!-- <div id="person-label">Please select Persons</div>
                                                    <div id="personinGroup"></div> -->
                                                    <input type="hidden" id="selectedDate" name="selectedDate" readonly>
                                                    <input type="hidden" id="start_event" name="start_event" readonly>
                                                    <!-- <input type="hidden" id="end_event" name="end_event" readonly> -->
                                                    <input type="hidden" id="min_person" name="min_person" readonly>
                                                    <input type="hidden" id="max_person" name="max_person" readonly>
                                                    <input type="hidden" id="selectedpersons" name="selectedpersons" readonly>
                                                    <input type="hidden" id="event_id" name="event_id" value="<?php echo $event_id; ?>" readonly>
                                                    <input type="hidden" id="post_id" name="post_id" value="<?php echo $postId; ?>" readonly>
                                                    <input type="hidden" id="language" name="language" value="" readonly>
                                                    <input type="hidden" id="request_label_english" name="request_label_english" value="<?php echo $request_label_english; ?>" readonly>
                                                    <input type="hidden" id="request_notification_english" name="request_notification_english" value="<?php echo $request_notification_english; ?>" readonly>
                                                    <input type="hidden" id="request_label_arabic" name="request_label_arabic" value="<?php echo $request_label_arabic; ?>" readonly>
                                                    <input type="hidden" id="request_notification_arabic" name="request_notification_arabic" value="<?php echo $request_notification_arabic; ?>" readonly>

                                                </div>
                                            </div>

                                            <div class="booking_form_item">
                                                <div class="booking_form_item_inner_display">
                                                    <div class="booking_form_display_item">
                                                        <!-- <label for="start_event_display"><?php //esc_html_e( 'Start Time', 'business-conference' ); ?></label> -->
                                                        <!-- <div class="start_event_display" id="start_event_display" ></div> -->
                                                    </div>
                                                    <div class="booking_form_display_item">
                                                        <!-- <label for="end_event_display"><?php // esc_html_e( 'End Time', 'business-conference' ); ?></label> -->
                                                        <!-- <div class="end_event_display" id="end_event_display" ></div> -->
                                                    </div> 
                                                    <div class="booking_form_display_item">
                                                        <!-- <label for="min_person_display"><?php //esc_html_e( 'Minimum people', 'business-conference' ); ?></label> -->
                                                        <!-- <div class="min_person_display" id="min_person_display" ></div> -->
                                                    </div>
                                                    <div class="booking_form_display_item">
                                                        <!-- <label for="max_person_display"><?php //esc_html_e( 'Maximum people', 'business-conference' ); ?></label> -->
                                                        <!-- <div class="max_person_display" id="max_person_display" ></div> -->
                                                    </div>
                                                </div>
                                            </div>
                                            <?php 
                                                $first_name = '';
                                                $last_name = '';
                                                $email = '';
                                                $phone = '';
                                                $readonly='';
                                            if (is_user_logged_in()) {
                                                    $current_user = wp_get_current_user();
                                                    $userdata = $current_user->data;
                                                    $user_id = get_current_user_id();
                                                    $first_name = get_user_meta($user_id, 'first_name', true);
                                                    $last_name = get_user_meta($user_id, 'last_name', true);
                                                    $email = $userdata->user_email;
                                                    $phone = get_user_meta($user_id, 'phone_number', true);
                                                    if(empty($first_name)){ $first_name = ''; } 
                                                    if(empty($last_name)){ $last_name = ''; } 
                                                    if(empty($email)){ $email = ''; $readonly='';}else{$readonly='readonly';} 
                                                    if(empty($phone)){ $phone = ''; } 
                                                }
                                            ?>
                                            <?php
                                                $first_name_label_english = get_field('first_name_label_english', 'option');
                                                $first_name_label_arabic = get_field('first_name_label_arabic', 'option');
                                                $last_name_label_english = get_field('last_name_label_english', 'option');
                                                $last_name_label_arabic = get_field('last_name_label_arabic', 'option');
                                                $email_label_english = get_field('email_label_english', 'option');
                                                $email_label_arabic = get_field('email_label_arabic', 'option');
                                                $phone_label_english = get_field('phone_label_english', 'option');
                                                $phone_label_arabic = get_field('phone_label_arabic', 'option');
                                                $additional_note_label_english = get_field('additional_note_label_english', 'option');
                                                $additional_note_label_arabic = get_field('additional_note_label_arabic', 'option');
                                            
                                                if (!empty($question_answers_event)) {
                                                    if (have_rows('question_answers_event')) :
                                                        $counter = 1;
                                                        while (have_rows('question_answers_event')) : the_row();
                                                            $event_question = get_sub_field('event_question');
                                                            $event_answers = get_sub_field('event_answer');
                                                            $quesLanguage = get_sub_field('language');
                                                            
                                                            $select_class = 'select-' . sanitize_title($event_question);
                                                            $select_name = 'question_ans' . $counter;
                                                            $selected_answer = isset($_POST[$select_name]) ? $_POST[$select_name] : '';
                                                            $question_name = 'question_name' . $counter; 
                                                            ?>
                                                             <?php
                                                                if(strtolower($quesLanguage) == 'arabic'){
                                                                    $fieldCLS = "notranslate field-form-arabic";
                                                                    $optionSelect = 'اختر الإجابة';
                                                                }
                                                                if(strtolower($quesLanguage) == 'english'){
                                                                    $fieldCLS = "notranslate field-form-english";
                                                                    $optionSelect = 'Select Answer';
                                                                
                                                                }?>

                                                                <div class="booking_form_item <?php echo $fieldCLS; ?>">
                                                                    <div class="booking_form_item_inner">

                                                                        <label for="<?php echo esc_attr($select_class); ?>" class="field-label notranslate"><?php echo esc_html($event_question); ?></label>
                                                                        <select class="<?php echo esc_attr($select_class); ?>" name="<?php echo esc_attr($select_name); ?>">
                                                                            <option value=""><?php echo $optionSelect; ?></option>
                                                                            <?php
                                                                            if (is_array($event_answers)) :
                                                                                foreach ($event_answers as $answer) :
                                                                                    $answer_value = $answer['answer']; 
                                                                                    $selected = ($answer_value === $selected_answer) ? 'selected' : ''; // Mark selected option
                                                                                    if (!empty($answer_value)) :
                                                                                        ?>
                                                                                        <option value="<?php echo esc_attr($answer_value); ?>" <?php echo $selected; ?>><?php echo esc_html($answer_value); ?></option>
                                                                                        <?php
                                                                                    endif;
                                                                                endforeach;
                                                                            endif;
                                                                            ?>
                                                                        </select>
                                                                        <input type="hidden" name="<?php echo esc_attr($question_name); ?>" value="<?php echo esc_attr($event_question); ?>" />
                                                                    </div>
                                                                </div>
                                                            <?php
                                                            $counter++;
                                                        endwhile;
                                                    endif;
                                                }
                                                ?>
                                                
                                            
                                         
                                            <div class="booking_form_item">
                                                <div class="booking_form_item_inner">
                                                    <label for="name" class="field-label-english notranslate"><?php echo $first_name_label_english; ?></label>
                                                    <label for="name" class="field-label-arabic notranslate"><?php echo $first_name_label_arabic; ?></label>
                                                    <input type="text" id="fname" name="fname" value="<?php echo $first_name; ?>"  required>
                                                </div>
                                                <div class="booking_form_item_inner">
                                                    <label for="lname" class="field-label-english notranslate"><?php echo $last_name_label_english; ?></label>
                                                    <label for="lname" class="field-label-arabic notranslate"><?php echo $last_name_label_arabic; ?></label>
                
                                                    <input type="text" id="lname" name="lname" value="<?php echo $last_name; ?>"  required>
                                                </div>
                                            </div>
                                            <div class="booking_form_item">
                                                <div class="booking_form_item_inner">
                                                    <label for="email" class="field-label-english notranslate"><?php echo $email_label_english; ?></label>
                                                    <label for="email" class="field-label-arabic notranslate"><?php echo $email_label_arabic; ?></label>
    
                                                    <input type="email" id="email" name="email" value="<?php echo $email; ?>" <?php echo $readonly; ?> required>
                                                </div>
                                                <div class="booking_form_item_inner">
                                                    <label for="phone" class="field-label-english notranslate"><?php echo $phone_label_english; ?></label>
                                                    <label for="phone" class="field-label-arabic notranslate"><?php echo $phone_label_arabic; ?></label>
    
                                                    <input type="tel" id="phone" name="phone" value="<?php echo $phone; ?>"  required>
                                                </div>
                                                <div class="booking_form_item_inner">
                                                    <label for="additional_note" class="field-label-english notranslate"><?php echo $additional_note_label_english; ?></label>
                                                    <label for="additional_note" class="field-label-arabic notranslate"><?php echo $additional_note_label_arabic; ?></label>
        
                                                    <textarea id="additional_note" name="additional_note" rows="4" cols="50"></textarea>
                                                </div>
                                            </div>
                                            <div class="booking_form_item" id="other_persons_data">
                                        
                                            </div>
                                            <?php
                                                $book_now_button_text_english = get_field('book_now_button_text_english', 'option');
                                                $book_now_button_text_arabic = get_field('book_now_button_text_arabic', 'option');
                                            ?>
                                            <div class="booking_form_footer booking_form_button">
                                                <button type="submit" id="submit_booking" class="book-btn-eng notranslate"><?php echo $book_now_button_text_english; ?></button>
                                                <button type="submit" id="submit_booking" class="book-btn-arabic notranslate"><?php echo $book_now_button_text_arabic; ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div id="input_details"></div>
                        </div>
                    </main>
                </div>
            <?php
        } else { ?>
        <div id="primary" class="content-area">
                <main id="main" class="site-main" role="main">
                </main>
            </div>
        <?php     }
    }else{ ?>
        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">
            </main>
        </div>
    <?php } ?>

<?php wp_footer(); ?>
<?php echo do_blocks( '<!-- wp:template-part {"slug":"footer","area":"footer","tagName":"footer"} /-->' ); ?>

<?php
    $select_person_dropdown_label_english = get_field('select_person_dropdown_label_english', 'option');
    $select_person_dropdown_label_arabic = get_field('select_person_dropdown_label_arabic', 'option');
    //  $event_label_note = get_field('event_label_note', 'option'); 

?>

<script>
   var laugage_switch = 0;

   function updateFlatpickrLocale(locale) {
        // if (locale) {
        //     flatpickr.localize(flatpickr.l10ns.ar); // Localize globally for all instances
        // } else {
        //     flatpickr.localize(flatpickr.l10ns.default); // Reset to default locale
        // }
    }   

    var weekValues = <?php echo json_encode($weekValues); ?>;


    var min_leadtime = '<?php echo $min_leadtime; ?>';
    var max_leadtime = '<?php echo $max_leadtime; ?>';

  
    var minleadTimeValue = parseInt(min_leadtime);
    if (minleadTimeValue == '') {
        minleadTimeValue = 40;
    }

    var maxleadTimeValue = parseInt(max_leadtime);
    if (maxleadTimeValue == '') {
        maxleadTimeValue = 40;
    }

    var selectedPersons = this.value;

    document.getElementById("personDropdown").addEventListener("change", function () {
        selectedPersons = this.value;

        document.getElementById("selectedDate").value = '';
        document.getElementById("start_event").value = '';
        document.getElementById("min_person").value = '';
        document.getElementById("max_person").value = '';

        document.getElementById("sidebar-label").style.display = 'none';
        document.getElementById("sidebar").innerHTML = '';

        var date_section = document.getElementById("date_section"); 
        var language = document.getElementById("language"); 
        var locale=null;
        if(language.value=="arabic"){
            locale = flatpickr.l10ns.ar;
             flatpickr.l10ns.ar.firstDayOfWeek = 0;

        }else{
            locale= flatpickr.l10ns.default;
        }

        if (selectedPersons !== "") {
            updateSelectedPersons(selectedPersons);
            flatpickr("#datepicker", {
                dateFormat: "Y-m-d",
                locale: locale, 
                minDate: "today",
                maxDate: new Date().setDate(new Date().getDate() + maxleadTimeValue),
                disable: getDisabledDates(selectedPersons),

                onChange: function(selectedDates, dateStr, instance) {
                    // Handle date selection
                    var selectedDay = getDayOfWeek(selectedDates[0]);
                    var selectedTimeSlots = weekValues[selectedDay];
                   
                    displayTimeSlots(selectedTimeSlots, selectedPersons);
                },
                onDayCreate: function(d, data ,instance) {
                     if(language.value=="arabic"){
                          instance.calendarContainer.classList.add("arbic_calender");

                    }else{
                         instance.calendarContainer.classList.remove("arbic_calender");
                    }
                  

                    if (d.date) {
                        var dateStr = d.date.toISOString().split('T')[0];
                        var dayInfo = weekValues[dateStr];

                        if (dayInfo && dayInfo.length > 0) {
                            var tooltip = document.createElement("span");
                            tooltip.className = "tooltip";
                            tooltip.textContent = getTimeSlotInfo(dayInfo);

                            data.day.appendChild(tooltip);


                            tooltip.addEventListener('click', function() {
        
                                var selectedTimeSlot = prompt("Select a time slot:", dayInfo.map(slot => `${slot.start_event}`).join(', '));

                                    if (selectedTimeSlot) {
                                        // Perform further actions with the selected time slot
                                        handleSelectedTimeSlot(selectedTimeSlot);
                                    }

                            });
                        }
                    }
                },
                // "locale": {
                    
                // "firstDayOfWeek": 0 // Start the week with Sunday
                // }
            });

            
            date_section.style.display = "block";
        } else {
            date_section.style.display = "none";
        }


       
    });

    function isEventSlotValid(eventDate, eventTime, leadTime) {
        const currentDateTime = new Date();
        // const eventDateTime = new Date(`${eventDate} ${eventTime}`);
        const [year, month, day] = eventDate.split('-').map(Number);
        const [hour, minute] = eventTime.match(/\d+/g).map(Number);
        const adjustedHour = eventTime.includes('pm') && hour !== 12 ? hour + 12 : hour;
        const eventDateTime = new Date(year, month - 1, day, adjustedHour, minute);
    // alert("eventDateTime" + eventDateTime);
        // alert("eventDateTime"+eventDateTime);
        // alert('eventdate '+eventDate+' eventtime '+eventTime+' leadTime'+leadTime);
        // Extract numerical value from leadTime string
        const leadTimeValue = parseInt(leadTime);
       
        if (isNaN(leadTimeValue)) {
            // Invalid leadTime format
            return false;
        }

        // Calculate the valid time by subtracting lead time
        const validTimeInMilliseconds = eventDateTime.getTime() - leadTimeValue * 60 * 60 * 1000;
      
        // Check if the current time is before the calculated valid time
        return currentDateTime.getTime() < validTimeInMilliseconds;
    }

    // function displayTimeSlots(selectedTimeSlots, selectedPersons) {
    //     console.log(selectedTimeSlots);
    //     var selectedDate = document.getElementById("datepicker").value;
    //     var sidebar = document.getElementById("sidebar");
    //     var sidebarloader = document.getElementById("sidebarloader");

    //     var attraction_type = '<?php echo $attraction_type; ?>';
    //     // alert(selectedDate);
    //     // Remove existing sidebar content
    //     sidebar.innerHTML = "";
    //     sidebarloader.innerHTML = "<div class='loader--ellipsis'><div></div><div></div><div></div><div></div></div>";
    //     console.log("selectedTimeSlots.length = "+selectedTimeSlots.length);
        
    //     if (selectedTimeSlots && selectedTimeSlots.length > 0) {      
    //         // Display all available time slots for the selected date in the sidebar
    //         var timeSlotsText = getTimeSlotInfo(selectedTimeSlots);
    //         // var sidebarContent = document.getElementById("timeslot_sidebar");
    //         let count = 0;
    //         var timeout = 100;
    //         // Add click event listeners to each time slot for selection
    //         selectedTimeSlots.forEach(function (timeSlot) {
    //             if(count == 0){
    //                 timeout = 100;
    //             }else{
    //                 timeout = 500;
    //             }
    //             var privateTimeSlot = '';
    //             if(attraction_type == 'private'){
    //                 var dataToSend = {
    //                     selectedDate: selectedDate,
    //                     start_event: timeSlot.start_event,
    //                     min_person: timeSlot.min_person,
    //                     max_person: timeSlot.max_person
    //                 };
    //                 setTimeout(() => {
    //                     $.ajax({
    //                         url: custom_script_vars.ajaxurl, 
    //                         type: 'POST',
    //                         data: dataToSend,
    //                         data: {
    //                             dataToSend: dataToSend,
    //                             action: 'private_attarction_call',
    //                         },
    //                         success: function(response) {
    //                             var res =JSON.parse(response);
                                
    //                             if (res.match == true ) {
    //                                 privateTimeSlot = 'no';
    //                             } else {
    //                                 privateTimeSlot = '';
    //                             }

    //                             var eventStartTime = timeSlot.start_event;
    //                             if(language.value=="arabic"){
    //                                 var parts = timeSlot.start_event.split(" ");
    //                                 var eventStartTime = parts[1]+" "+ parts[0];

    //                                 }

    //                             var result = isEventSlotValid(selectedDate, eventStartTime, min_leadtime);
    //                             if(privateTimeSlot == ''){
    //                                 if(timeSlot.avaliable == 'yes' && result == true && parseInt(timeSlot.min_person) <= selectedPersons && parseInt(timeSlot.max_person) >= selectedPersons){
    //                                     var timeSlotButton = document.createElement("button");

    //                                     if(language.value=="arabic"){
    //                                     var parts = timeSlot.start_event.split(" ");
    //                                     if(parts[1]=='pm'){
    //                                         console.log("pm");
    //                                         var partname= "مساءً";
    //                                     }else if(parts[1]=='am'){
    //                                         var partname= "صباحاً";
    //                                     }else{

    //                                     }
    //                                         var start_event = "<span class='tm_name'>" + partname + " </span> <span class='tm_nmbr'>" + parts[0] + "</span>";
    //                                     timeSlotButton.innerHTML = start_event;
    //                                     }else{
    //                                         var start_event=timeSlot.start_event ;
    //                                         timeSlotButton.textContent = start_event;
    //                                     }
                                    
    //                                     timeSlotButton.classList.add("time-slot");
    //                                     timeSlotButton.type = "button"; 
    //                                     timeSlotButton.addEventListener('click', function (event) {
    //                                         event.preventDefault();
    //                                         handleSelectedTimeSlot(timeSlot, selectedDate);
    //                                     });
                                        
    //                                     // alert(timeSlotButton);
    //                                     sidebar.appendChild(timeSlotButton);
    //                                 }
    //                             }
    //                         },
    //                         error: function(xhr, status, error) {
    //                             console.error('Error:', error);
    //                         }
    //                     });
    //                 }, timeout);
    //             }else{
    //                 var eventStartTime = timeSlot.start_event;
    //                  if(language.value=="arabic"){
    //                    var parts = timeSlot.start_event.split(" ");
    //                    var eventStartTime = parts[1]+" "+ parts[0]; 
    //                 }
    //                 var result = isEventSlotValid(selectedDate, eventStartTime, min_leadtime);
    //                 if(timeSlot.avaliable == 'yes' && result == true && parseInt(timeSlot.min_person) <= selectedPersons && parseInt(timeSlot.max_person) >= selectedPersons){
    //                     var timeSlotButton = document.createElement("button");
    //                     if(language.value=="arabic"){
    //                                    var parts = timeSlot.start_event.split(" ");
                                       
                                     
    //                                 if(parts[1]=='pm'){
    //                                     console.log("pm");
    //                                     var partname= "مساءً";
    //                                 }else if(parts[1]=='am'){
    //                                     var partname= "صباحاً";
    //                                 }else{

                                      
    //                                 }
    //                       var start_event ="<span class='tm_name'>" +partname+" </span><span class='tm_nmbr'>"+ parts[0] + "</span>";
    //                          timeSlotButton.innerHTML = start_event;
    //                         }else{
    //                             var start_event=timeSlot.start_event ;
    //                              timeSlotButton.textContent = start_event;
    //                         }
                            
                                   
    //                     timeSlotButton.classList.add("time-slot");
    //                     timeSlotButton.type = "button"; 
    //                     timeSlotButton.addEventListener('click', function (event) {
    //                         event.preventDefault();
    //                         timeSlotButton.classList.remove("time-slot-active");
    //                         timeSlotButton.classList.add("time-slot-active");
    //                         handleSelectedTimeSlot(timeSlot, selectedDate);
    //                     });
                        
    //                     // alert(timeSlotButton);
    //                     sidebar.appendChild(timeSlotButton);
    //                     sidebarloader.innerHTML = "";
    //                 }
    //             }
    //             count++;
    //             $(document).ajaxStop(function() {
    //                 if ($.active === 0) {
    //                     console.log(count);
    //                     sidebarloader.innerHTML = "";
    //                 }
    //             });
                
    //         });

    //         // sidebar.appendChild(sidebarContent);
    //         // sidebar.style.display = 'block';
    //         document.getElementById("sidebar-label").style.display = 'block';

    //     } else {
    //         sidebarloader.innerHTML = "";
    //         // Handle the case where no time slots are available for the selected day
    //         console.log("No time slots available for the selected day.");
    //     }
    // }

    async function displayTimeSlots(selectedTimeSlots, selectedPersons) {

        var selectedDate = document.getElementById("datepicker").value;
        var sidebar = document.getElementById("sidebar");
        var sidebarloader = document.getElementById("sidebarloader");

        var attraction_type = '<?php echo $attraction_type; ?>';
        // Remove existing sidebar content
        sidebar.innerHTML = "";
        sidebarloader.innerHTML = "<div class='loader--ellipsis'><div></div><div></div><div></div><div></div></div>";

        if (selectedTimeSlots && selectedTimeSlots.length > 0) {
            // Display all available time slots for the selected date in the sidebar
            var timeSlotsText = getTimeSlotInfo(selectedTimeSlots);
            var count = 0;
            // Process each time slot in sequence
            for (let i = 0; i < selectedTimeSlots.length; i++) {
                const timeSlot = selectedTimeSlots[i];
                if (attraction_type === 'private') {
                    await performAjaxCall(timeSlot);
                } else {
                    handleTimeSlotWithoutAjax(timeSlot);
                }
                count++;
                $(document).ajaxStop(function() {
                    setTimeout(() => {
                        
                        if ($.active === 0) {
                            console.log(count);
                            sidebarloader.innerHTML = "";
                        }
                    }, 1000);
                });
            }

            document.getElementById("sidebar-label").style.display = 'block';
        } else {
            sidebarloader.innerHTML = "";
            console.log("No time slots available for the selected day.");
        }
    }

    function performAjaxCall(timeSlot) {
        return new Promise((resolve, reject) => {
            var selectedDate = document.getElementById("datepicker").value;
            var sidebar = document.getElementById("sidebar");
            
            var dataToSend = {
                selectedDate: selectedDate,
                start_event: timeSlot.start_event,
                min_person: timeSlot.min_person,
                max_person: timeSlot.max_person
            };

            $.ajax({
                url: custom_script_vars.ajaxurl,
                type: 'POST',
                data: {
                    dataToSend: dataToSend,
                    action: 'private_attarction_call',
                },
                success: function (response) {
                    var res = JSON.parse(response);
                    var privateTimeSlot = res.match === true ? 'no' : '';
                    var eventStartTime = timeSlot.start_event;

                    if (language.value === "arabic") {
                        var parts = timeSlot.start_event.split(" ");
                        eventStartTime = parts[1] + " " + parts[0];
                    }

                    var result = isEventSlotValid(selectedDate, eventStartTime, min_leadtime);
                    
                    if (privateTimeSlot === '') {

                        if (timeSlot.avaliable == 'yes' && result == true && parseInt(timeSlot.min_person) <= selectedPersons && parseInt(timeSlot.max_person) >= selectedPersons) {

                            var timeSlotButton = document.createElement("button");
                            
                            if (language.value === "arabic") {
                                var parts = timeSlot.start_event.split(" ");
                                var partname = parts[1] === 'pm' ? "مساءً" : "صباحاً";
                                var start_event = "<span class='tm_name'>" + partname + " </span> <span class='tm_nmbr'>" + parts[0] + "</span>";
                                timeSlotButton.innerHTML = start_event;
                            } else {
                                var start_event = timeSlot.start_event;
                                timeSlotButton.textContent = start_event;
                            }

                            timeSlotButton.classList.add("time-slot");
                            timeSlotButton.type = "button";
                            timeSlotButton.addEventListener('click', function (event) {
                                event.preventDefault();
                                handleSelectedTimeSlot(timeSlot, selectedDate);
                            });
                            
                            sidebar.appendChild(timeSlotButton);
                        }
                    }
                    resolve();
                },
                error: function (xhr, status, error) {
                    console.error('Error:', error);
                    reject(error);
                }
            });
        });
    }

    function handleTimeSlotWithoutAjax(timeSlot) {
        var selectedDate = document.getElementById("datepicker").value;
        var sidebar = document.getElementById("sidebar");
        var eventStartTime = timeSlot.start_event;

        if (language.value == "arabic") {
            var parts = timeSlot.start_event.split(" ");
            eventStartTime = parts[1] + " " + parts[0];
        }
        var result = isEventSlotValid(selectedDate, eventStartTime, min_leadtime);
        if (timeSlot.avaliable == 'yes' && result == true && parseInt(timeSlot.min_person) <= selectedPersons && parseInt(timeSlot.max_person) >= selectedPersons) {
            var timeSlotButton = document.createElement("button");
            if (language.value == "arabic") {
                var parts = timeSlot.start_event.split(" ");
                var partname = parts[1] == 'pm' ? "مساءً" : "صباحاً";
                var start_event = "<span class='tm_name'>" + partname + " </span> <span class='tm_nmbr'>" + parts[0] + "</span>";
                timeSlotButton.innerHTML = start_event;
            } else {
                var start_event = timeSlot.start_event;
                timeSlotButton.textContent = start_event;
            }

            timeSlotButton.classList.add("time-slot");
            timeSlotButton.type = "button";
            timeSlotButton.addEventListener('click', function (event) {
                event.preventDefault();
                timeSlotButton.classList.remove("time-slot-active");
                timeSlotButton.classList.add("time-slot-active");
                handleSelectedTimeSlot(timeSlot, selectedDate);
            });

            sidebar.appendChild(timeSlotButton);
            sidebarloader.innerHTML = "";
        }
    }

    // Helper function to introduce a delay
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }


    function handleSelectedTimeSlot(selectedTimeSlot, selectedDate) {

        // Store selected time slot values in hidden input fields
        document.getElementById("selectedDate").value = selectedDate;
        document.getElementById("start_event").value = selectedTimeSlot.start_event;
        // document.getElementById("end_event").value = selectedTimeSlot.end_event;
        document.getElementById("min_person").value = selectedTimeSlot.min_person;
        document.getElementById("max_person").value = selectedTimeSlot.max_person;
        // document.getElementById("start_event_display").innerHTML = selectedTimeSlot.start_event;
        // document.getElementById("end_event_display").innerHTML = selectedTimeSlot.end_event;
        // document.getElementById("min_person_display").innerHTML = selectedTimeSlot.min_person;
        // document.getElementById("max_person_display").innerHTML = selectedTimeSlot.max_person;

        var elements = document.getElementsByClassName("booking_form_display_item");
        for (var i = 0; i < elements.length; i++) {
            elements[i].style.display = 'block';
        }

        // createPersonDropdown(selectedTimeSlot.min_person, selectedTimeSlot.max_person);


        // document.getElementById("person-label").style.display = 'block';

        // var dropdown = document.getElementById("personDropdown");
        // dropdown.addEventListener("change", function() {
        //     updateSelectedPersons(this.value);
        // });

    }

    function updateSelectedPersons(selectedValue) {

        var language = document.getElementById("language"); 
        var title='يعالج ...';
        var text='يرجى الانتظار بينما نقوم بإضافة الحقول.';
        if(language.value!="arabic"){
            title= 'Processing...';
            text= 'Please wait while we add the fields.';
           
        }else{
            title='يعالج ...';
            text='يرجى الانتظار بينما نقوم بإضافة الحقول.';
        }
        // Display a SweetAlert processing modal
        Swal.fire({
            title:title,
            text:text ,
            allowOutsideClick: false,
            showCancelButton: false,
            showConfirmButton: false,
            didOpen: () => {
             Swal.showLoading();
            }
        });


        setTimeout(() => {
            // Update the hidden input field with the selected value
            var selectedPersonsInput = document.getElementById("selectedpersons");
            selectedPersonsInput.value = selectedValue;


            generateOtherPersonsHtml(selectedValue);

            Swal.close();
        }, 2000);
    }

   
   
    
 
    function generateOtherPersonsHtml(numPersons) {
        var language = document.getElementById("language"); 
    // alert('test');
    if(language.value!="arabic"){
        var eventLabelNote = <?php echo json_encode($event_label_note); ?>;
    }else{
        var eventLabelNote = <?php echo json_encode($event_label_note_ar); ?>;
    }
    var inputDetailsContainer = document.getElementById("other_persons_data");
    inputDetailsContainer.innerHTML = ""; // Clear previous content
    numPersons = numPersons - 1;

    for (var i = 1; i <= numPersons; i++) {
        var personHtml = `
        <div class="booking_form_item">
            <h5 class="ar">مرافق</h5>
            <h5 class="en">Secondary Guests</h5>
            <div class="booking_form_item_inner">
                <label for="other_fname${i}" class="no-translate saaaa"><?php esc_html_e('الاسم الأول', 'business-conference'); ?></label>
                <input type="text" id="other_fname${i}" name="other_fname${i}" required>
            </div>
            <div class="booking_form_item_inner">
                <label for="other_lname${i}" class="no-translate"><?php esc_html_e('اسم العائلة', 'business-conference'); ?></label>
                <input type="text" id="other_lname${i}" name="other_lname${i}" required>
            </div>

            ${eventLabelNote ? `
            <div class="booking_form_item_inner">
                <label for="other_custom_note${i}" class="no-translate">${eventLabelNote}</label>
                <input type="text" id="other_custom_note${i}" name="other_custom_note${i}" required>
            </div>` : ''}
        </div>`;

        inputDetailsContainer.innerHTML += personHtml;
    }
}




    // function createPersonDropdown(minValue, maxValue, containerId) {
    //     var dropdown = document.createElement("select");
    //     dropdown.id = "personDropdown";

    //     for (var i = parseInt(minValue); i <= parseInt(maxValue); i++) {
    //         var option = document.createElement("option");
    //         option.value = i;
    //         option.text = i;
    //         dropdown.appendChild(option);
    //     }

    //     // Append the dropdown to the specified container in your HTML
    //     // var dropdownContainer = document.getElementById('personinGroup');
    //     // dropdownContainer.innerHTML = ""; // Clear previous content
    //     // dropdownContainer.appendChild(dropdown);
    // }

    function getDayOfWeek(date) {
        var daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        var dayIndex = date.getDay();

        return daysOfWeek[dayIndex];
    }


      function getDisabledDates(selectedPersons) {
    
        var disabledDates = [];
        var currentDate = getMondayOfCurrentWeek(new Date());
        var disableDays = [];
        var daysOfWeek2 = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        var currentDate = new Date();
        var currentDateString = currentDate.toISOString().split('T')[0];
        var currentTime = new Date();
        var hours = currentTime.getHours();
        var minutes = currentTime.getMinutes();
        var seconds = currentTime.getSeconds();
        var formattedTime = hours + ':' + minutes + ':' + seconds
        var currentday = '';

        for (var day of Object.keys(weekValues)) {
            var isWeekdayAvailable = false;

            // Check each time slot within the day
            for (var i = 0; i < weekValues[day].length; i++) {
                var timeSlot = weekValues[day][i];
         
                if (
                    timeSlot['avaliable'].length === 1 &&
                    parseInt(timeSlot.min_person) <= selectedPersons &&
                    parseInt(timeSlot.max_person) >= selectedPersons
                ) {

                    if (timeSlot.start_event) {
                        if(currentDate <= new Date().setDate(new Date().getDate() + 7)) {
                            var eventStartTime = timeSlot.start_event;
                            var minBookingTime = calculateBookingDateTime(day, eventStartTime, min_leadtime);
                            var maxBookingTime = calculateBookingDateTimeWithDays(day, eventStartTime, max_leadtime);
                            
                            var result = isBookingAllowed(minBookingTime, maxBookingTime);
                            
                            if (result) {
                                isWeekdayAvailable = true;
                                break;
                            }
                                currentday = day;
                            }
                    }
                }
            }

            if (!isWeekdayAvailable) {

                disableDays.push(day); // Add the day to the list of disabled days
               
            }
        }
        // console.log(disableDays);
            for (var disabledDay of disableDays) {
                currentDate = getMondayOfCurrentWeek(new Date()); // Reset to the current week's Monday
                while (currentDate.getDay() !== daysOfWeek2.indexOf(disabledDay)) {
                    currentDate.setDate(currentDate.getDate() + 1); // Move to the correct day of the week
                }
                
                while (currentDate <= new Date().setDate(new Date().getDate() + maxleadTimeValue)) {
                    var disabledDate = currentDate.toISOString().split('T')[0];
                    
                    disabledDates.push(disabledDate);
                    currentDate.setDate(currentDate.getDate() + 7); // Move to the next week
                }
            }


        var variableDay = currentday; // Replace with your variable day

        var currentDate = new Date();
        var currentDay = currentDate.toLocaleString('en-US', { weekday: 'long' });

        var indexOfVariableDay = daysOfWeek2.indexOf(variableDay.toLowerCase());

        var filteredDates = disabledDates.filter(function (date) {
            var dateObj = new Date(date);
            var dateDay = dateObj.toLocaleString('en-US', { weekday: 'long' });

            // Check if it's not the current day or it's not in the current week
            return dateDay !== currentDay || dateObj < currentDate || dateObj.getDay() !== indexOfVariableDay;
        });

        var new_avaliable_days ='<?php echo json_encode($current_not_available_days); ?>';

        new_avaliable_days = JSON.parse(new_avaliable_days);

        if(new_avaliable_days.length > 0){
            var available_days = new_avaliable_days[0];

            var currentDate = new Date();
            var year = currentDate.getFullYear();
            var currentDay = currentDate.getDate();

            var new_dates = available_days.map(function(day) {
                var month = ("0" + (currentDate.getMonth() + 1)).slice(-2);
                if(day <= currentDay){
                    if(month == 12){
                        year = parseInt(year) + 1;
                        month = 01;
                    }else{
                        month = parseInt(month) + 1;
                    }
                }
                return year + '-' + month + '-' + day;
            });

            // Add new dates to the existing dates array
            filteredDates = filteredDates.concat(new_dates);

            console.log(filteredDates);
        }

        // console.log(new_avaliable_days);

        // if (new_avaliable_days.length > 0) {
        //     var currentDate = new Date();
        //     var currentYear = currentDate.getFullYear();
        //     var currentMonth = ("0" + (currentDate.getMonth() + 1)).slice(-2); // Adding leading zero
        //     var currentDay = currentDate.getDate();
            
        //     var new_dates_current_month = [];
        //     var new_dates_next_month = [];
            
        //     new_avaliable_days.forEach(function(day) {
        //         console.log(currentDay);
        //         console.log(day);
        //         day = parseInt(day); // Convert the day to an integer
        //         var formattedDay = ("0" + day).slice(-2); // Adding leading zero

        //         if (day >= currentDay) {
        //             // For days greater than or equal to today, stay in the current month
        //             new_dates_current_month.push(currentYear + '-' + currentMonth + '-' + formattedDay);
        //         } else {
        //             // For days less than today, assume they belong to the next month
        //             var nextMonthDate = new Date(currentYear, currentDate.getMonth() + 1, 1);
        //             var nextMonth = ("0" + (nextMonthDate.getMonth() + 1)).slice(-2);
        //             new_dates_next_month.push(currentYear + '-' + nextMonth + '-' + formattedDay);
        //         }
        //     });

        //     // Combine the dates from current and next month into the filteredDates array
        //     filteredDates = filteredDates.concat(new_dates_current_month, new_dates_next_month);

        //     console.log(filteredDates);
        // }



        return filteredDates;
    }

    function calculateBookingDateTimeWithDays(currentDay, eventStartTime, leadTime) {
        const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

        // Find the index of the current day in daysOfWeek
        const currentDayIndex = daysOfWeek.indexOf(currentDay.toLowerCase());
        if (currentDayIndex === -1) {
            // Invalid day provided
            return null;
        }

        // Extract numerical value from leadTime string
        const leadTimeValue = parseInt(leadTime);
        if (isNaN(leadTimeValue)) {
            // Invalid leadTime format
            return null;
        }

        // Convert eventStartTime to hours
        const eventTimeMatch = eventStartTime.match(/(\d{1,2}):(\d{2})\s*(am|pm)?/i);
        if (!eventTimeMatch) {
            // Invalid time format
            return null;
        }

        let eventHours = parseInt(eventTimeMatch[1]);
        const eventMinutes = parseInt(eventTimeMatch[2]);
        const eventPeriod = eventTimeMatch[3] ? eventTimeMatch[3].toLowerCase() : '';

        if (eventHours === 12) {
            eventHours = eventPeriod === 'am' ? 0 : 12;
        } else {
            eventHours += eventPeriod === 'pm' ? 12 : 0;
        }

        const eventTimeInHours = eventHours + eventMinutes / 60;

        // Calculate booking time by adding lead time to the event time
        const bookingTimeInHours = eventTimeInHours + leadTimeValue;

        // Set the date to the next occurrence of the event day
        const currentDate = new Date();
        currentDate.setDate(currentDate.getDate() + (currentDayIndex - currentDate.getDay() + 7) % 7);

        // Add the calculated lead time in days to the current date
        currentDate.setDate(currentDate.getDate() + Math.floor(bookingTimeInHours / 24));

        // Set the time to the calculated booking time
        currentDate.setHours(Math.floor(bookingTimeInHours) % 24, (bookingTimeInHours % 1) * 60, 0, 0);

        return currentDate;
    }

    function calculateBookingDateTime(currentDay, eventStartTime, leadTime) {
        const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

        // Find the index of the current day in daysOfWeek
        const currentDayIndex = daysOfWeek.indexOf(currentDay.toLowerCase());
        if (currentDayIndex === -1) {
            // Invalid day provided
            return null;
        }

        // Extract numerical value from leadTime string
        const leadTimeValue = parseInt(leadTime);
        if (isNaN(leadTimeValue)) {
            // Invalid leadTime format
            return null;
        }

        // Convert eventStartTime to hours
        const eventTimeMatch = eventStartTime.match(/(\d{1,2}):(\d{2})\s*(am|pm)?/i);
        if (!eventTimeMatch) {
            // Invalid time format
            return null;
        }

        let eventHours = parseInt(eventTimeMatch[1]);
        const eventMinutes = parseInt(eventTimeMatch[2]);
        const eventPeriod = eventTimeMatch[3] ? eventTimeMatch[3].toLowerCase() : '';

        if (eventHours === 12) {
            eventHours = eventPeriod === 'am' ? 0 : 12;
        } else {
            eventHours += eventPeriod === 'pm' ? 12 : 0;
        }

        const eventTimeInHours = eventHours + eventMinutes / 60;

        // Calculate booking time by subtracting lead time from the event time
        const bookingTimeInHours = eventTimeInHours - leadTimeValue;

        // Set the date to the next occurrence of the event day
        const currentDate = new Date();
        currentDate.setDate(currentDate.getDate() + (currentDayIndex - currentDate.getDay() + 7) % 7);

        // Set the time to the calculated booking time
        currentDate.setHours(Math.floor(bookingTimeInHours), (bookingTimeInHours % 1) * 60, 0, 0);

        return currentDate;
    }



    function getTimeSlotInfo(dayInfo) {
        var infoText = "";

        for (var i = 0; i < dayInfo.length; i++) {
            var timeSlot = dayInfo[i];
            infoText += timeSlot.start_event+"\n";
        }

        return infoText;
    }


    function isBookingAllowed(minBookingTime, maxBookingTime) {
        const currentDate = new Date();

        // Check if current date is greater than minBookingTime
        if (currentDate > minBookingTime) {
            return false;
        }

        // Check if current date is greater than maxBookingTime for the same weekday
        const maxBookingTimeForSameWeekday = new Date(maxBookingTime);
        maxBookingTimeForSameWeekday.setDate(minBookingTime.getDate() + 7);

        if (currentDate > maxBookingTimeForSameWeekday) {
            return false;
        }

        return true;
    }




    // function isBookingAllowed(eventStartTime, minBookingTime, maxBookingTime) {
    //     const now = new Date();
    //     const currentDay = now.toISOString().split('T')[0];

    //     const eventTime = `${currentDay} ${eventStartTime}`;
    //     const eventDateTime = new Date(eventTime);

    //     // Make a copy of the eventDateTime object
    //     const minBookingDateTime = new Date(eventDateTime.getTime());
    //     minBookingDateTime.setUTCHours(eventDateTime.getUTCHours() - minBookingTime);

    //     // Make another copy of the eventDateTime object
    //     const maxBookingDateTime = new Date(eventDateTime.getTime());
    //     maxBookingDateTime.setUTCHours(eventDateTime.getUTCHours() - maxBookingTime);

    //     console.log(minBookingDateTime);
    //     console.log(maxBookingDateTime);
    //     console.log(now >= minBookingDateTime && now <= maxBookingDateTime);
    //     return now >= minBookingDateTime && now <= maxBookingDateTime;
    // }


    function getMondayOfCurrentWeek(date) {
        var currentDayOfWeek = date.getDay();
        var daysToMonday = currentDayOfWeek === 0 ? 1 : (1 - currentDayOfWeek + 7) % 7;

        var mondayOfCurrentWeek = new Date(date);
        mondayOfCurrentWeek.setDate(date.getDate() - daysToMonday);

        return mondayOfCurrentWeek;
    }



    $(document).ready(function () {

        // Function to check if a field is empty
        function isEmpty(fieldValue) {
            return fieldValue.trim() === '';
        }

        // Function to add error message span
        function addErrorMessage(elementId, errorMessage) {
            var errorSpan = $('<span>', {
                class: 'error-message',
                html: errorMessage,
                id: elementId + '-error'
            });

            $('#' + elementId).parent().append(errorSpan);
        }

        // Function to remove error message span
        function removeErrorMessage(elementId) {
            $('#' + elementId + '-error').remove();
        }


        // Add event listeners for keyup on the specified fields
        var fieldsToCheck = ['fname', 'lname', 'email', 'phone'];
        fieldsToCheck.forEach(function (fieldId) {
            $('#' + fieldId).on('keyup', function () {
                var fieldValue = $(this).val();
                // Remove existing error message
                removeErrorMessage(fieldId);

                // Check if the field is empty and add error message if necessary
                if (isEmpty(fieldValue)) {
                addErrorMessage(fieldId, 'This field is required');
            }
            });
        });

        $('#datepicker').on('change', function () {

            var fieldValue = $('#selectedDate').val();
            
            $('#start_event').val('');
            // $('#end_event').val('');
            $('#min_person').val('');
            $('#max_person').val('');
            // $('#selectedpersons').val('');

            removeErrorMessage('selectedDate');

            // Check if the field is empty and add error message if necessary
            // if (isEmpty(fieldValue)) {
            //     addErrorMessage('sidebar-label', 'Please select a time slot');
            // }
        });

       
    });

    jQuery(document).ready(function () {


        jQuery('#sidebar').on('click', '.time-slot', function() {
            // Remove the 'time-slot-active' class from all time slots
            jQuery('#sidebar .time-slot').removeClass('time-slot-active');
            
            // Add the 'time-slot-active' class to the clicked time slot
            jQuery(this).addClass('time-slot-active');
        });
        
        var originalcontentarebicText = jQuery('.booking_form_bokking_content .arebic_content').html();
        var originalText = jQuery('.no-translate').text();
        
        setTimeout(() => {
            jQuery('.event_english_name.no-translate').text(originalText);
        }, 200);
        // setInterval(() => {
        //     jQuery('.booking_form_bokking_content .arebic_content').html(originalcontentarebicText);
        // }, 100);
        // Function to update the #language hidden input based on the selected value
        

        function updateLanguageDropdown(selectedValue) {
            jQuery('#personDropdown').val('');
            var date_section = document.getElementById("date_section"); 
            date_section.style.display = "none";
            jQuery('#datepicker').val('');
            jQuery('#sidebar-label').hide();
            // jQuery('#sidebar').hide();
            jQuery('#sidebar button').remove();

            
            var languageInput = jQuery('#language');
            if (selectedValue === 'ar|ar') {
                // Set the value to 'arabic' if selected value is 'en|ar'
                languageInput.val('arabic');
                jQuery('#personDropdown .option-person').text('<?php echo $select_person_dropdown_label_arabic; ?>');
                updateFlatpickrLocale("ar");
            } else {
                // Set the value to 'english' for other cases
                languageInput.val('english');
                jQuery('#personDropdown .option-person').text('<?php echo $select_person_dropdown_label_english; ?>');
                updateFlatpickrLocale(null);

            }
            jQuery('body').find('div, label, input').addClass('arabic');
        }

        // Initial update based on the initial selected value
        var initialSelectedValue = jQuery('.gt_selector').val();

        updateLanguageDropdown(initialSelectedValue);

        
        // Check if the selected value is 'en|ar' initially
        if (initialSelectedValue === 'ar|ar') {
        
            // Add 'arabic' class to elements with class 'translate-label' and 'translate-input'
            jQuery('body').find('div, label, input').addClass('arabic');
        }else{
            jQuery('body').find('div, label, input').addClass('english');

        }

        // Attach a change event listener to the language selector
        jQuery('.gt_selector').on('change', function () {
            // Get the selected value
            var selectedValue = jQuery(this).val();

            // Update the #language hidden input value
            updateLanguageDropdown(selectedValue);
            jQuery('#other_persons_data').html('');
            // Remove 'arabic' class from elements
            jQuery('body').find('div, label, input').removeClass('arabic');

            // Check if the selected value is 'ar|ar'
            if (selectedValue === 'ar|ar') {
                jQuery('#personDropdown .option-person').text('<?php echo $select_person_dropdown_label_arabic; ?>');
                // Add 'arabic' class to elements within the body
                jQuery('body').find('div, label, input').addClass('arabic');
                // setInterval(() => {
                //     jQuery('.booking_form_bokking_content .arebic_content').html(originalcontentarebicText);
                // }, 100);

                var selectedValue = '';
                selectedValue = jQuery('#pass_arabic_name').val();
                if (selectedValue !== "") {
                    jQuery('.booking_default_form_box').show();
                } else {
                    jQuery('.booking_default_form_box').hide();
                }
                
            }else{
                jQuery('body').find('div, label, input').addClass('english');
                jQuery('#personDropdown .option-person').text('<?php echo $select_person_dropdown_label_english; ?>');

                var selectedValue = '';
                selectedValue = jQuery('#pass_english_name').val();
                
                if (selectedValue !== "") {
                    jQuery('.booking_default_form_box').show();
                } else {
                    jQuery('.booking_default_form_box').hide();
                }
                
            }
        });

        jQuery('.button_pass_avaliable').on('click', function() {
            var dataSetValue = jQuery(this).attr('data-set');
            jQuery('.button_pass_avaliable').removeClass('activated');
            jQuery(this).addClass('activated');
            if(dataSetValue == 'yes'){
                var selectedValue = '';
                jQuery('.pass_avaliable_no_option').addClass('pass_hide');
                jQuery('.pass_avaliable_no_option').removeClass('pass_show');
                jQuery('.pass_avaliable_yes_option ').addClass('pass_show');
                jQuery('.pass_avaliable_yes_option ').removeClass('pass_hide');
                if(language == 'arabic'){
                    selectedValue = jQuery('#pass_arabic_name').val();
                }else{
                    selectedValue = jQuery('#pass_english_name').val();
                }
                if (selectedValue !== "") {
                    jQuery('.booking_default_form_box').show();
                } else {
                    jQuery('.booking_default_form_box').hide();
                }
                
            }else{
                jQuery('.pass_avaliable_yes_option ').addClass('pass_hide');
                jQuery('.pass_avaliable_yes_option ').removeClass('pass_show');
                jQuery('.pass_avaliable_no_option ').addClass('pass_show');
                jQuery('.pass_avaliable_no_option ').removeClass('pass_hide');
                jQuery('.booking_default_form_box').hide();
            }
        });

        jQuery('#pass_english_name').on('change', function() {
            var selectedValue = jQuery(this).val();
            if (selectedValue !== "") {
                jQuery('.booking_default_form_box').show();
            } else {
                jQuery('.booking_default_form_box').hide();
            }
        });
        jQuery('#pass_arabic_name').on('change', function() {
            var selectedValue = jQuery(this).val();
            if (selectedValue !== "") {
                jQuery('.booking_default_form_box').show();
            } else {
                jQuery('.booking_default_form_box').hide();
            }
        });
});


</script>








