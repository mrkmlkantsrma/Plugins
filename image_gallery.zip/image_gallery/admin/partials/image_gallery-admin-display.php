<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Image_gallery
 * @subpackage Image_gallery/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<!-- shotcode -->
<form>
    <h3>You can use this shortcode to show the image gallery.</h3>
    <ul>
        <li><b><input type = "text" value="[gallery_images]" readonly></b></li>
    </ul>
</form>

<!-- get custom post type data and fetch dynamic custom code -->
<?php 

$args = array(
    'post_type' => 'image_gallery',
    'posts_per_page' => -1 // Get all posts
);

$query = new WP_Query( $args );

if ( $query->have_posts() ) 
{
    while ( $query->have_posts() ) 
    {
        $query->the_post();
        $post_id = get_the_ID();
        $title   =  get_the_title();
    ?>
    <h3><a href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo $post_id; ?>&action=edit"><?php echo $title; ?></a> </h3>
    <?php 
    }
}

wp_reset_postdata();


// $posts = get_posts($args);
// foreach ($posts as $post) 
// {
//    echo '<pre>';
//    print_r($post);
//    echo '</pre>';
// }





