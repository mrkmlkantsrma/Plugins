<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://https://techytrion.com/
 * @since             1.0.0
 * @package           Image_gallery
 *
 * @wordpress-plugin
 * Plugin Name:       Image Gallery
 * Plugin URI:        https://http://localhost/wordpress/wp-admin/
 * Description:       Image gallery 
 * Version:           1.0.0
 * Author:            Techytrion
 * Author URI:        https://https://techytrion.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       image_gallery
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'IMAGE_GALLERY_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-image_gallery-activator.php
 */
function activate_image_gallery() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-image_gallery-activator.php';
	Image_gallery_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-image_gallery-deactivator.php
 */
function deactivate_image_gallery() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-image_gallery-deactivator.php';
	Image_gallery_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_image_gallery' );
register_deactivation_hook( __FILE__, 'deactivate_image_gallery' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-image_gallery.php';


/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */



/******************* add custom menu *************************** */  
//  add_action('admin_menu', 'image_gallery');

//  function image_gallery()
//  {
// 	 add_menu_page('Image Gallery Title', 'Image Gallery', 'manage_options', 'img-gallery-menu', 'images', 'dashicons-format-gallery' );

// 	 add_submenu_page('img-gallery-menu', 'Submenu Page Gallery', 'Add Gallery', 'manage_options', 'img-gallery-menu-1', 'img_submenu1');

// 	 add_submenu_page('img-gallery-menu', 'Submenu Page Gallery', 'All Settings', 'manage_options', 'img-gallery-menu-2', 'img_submenu2' );
//  }

// function images()
// {
// 	echo '111111111111111';
// }
// function img_submenu1()
// {
// 	echo '222222222222';
// }
// function img_submenu2()
// {
// 	echo '3333333333';
// }


// function image_submenu()
// {
// 	require plugin_dir_path(__FILE__) . 'admin/partials/image_gallery-admin-display.php';
// }


// function create_img_gallery_taxonomy() 
// {
//     register_taxonomy('tags','img_gallery',array(
//         'hierarchical' => false,
//         'labels' => array(
//             'name' => _x( 'Tags', 'taxonomy general name' ),
//             'singular_name' => _x( 'Tag', 'taxonomy singular name' ),
//             'menu_name' => __( 'Tags' ),
//             'all_items' => __( 'All Tags' ),
//             'edit_item' => __( 'Edit Tag' ), 
//             'update_item' => __( 'Update Tag' ),
//             'add_new_item' => __( 'Add Tag' ),
//             'new_item_name' => __( 'New Tag' ),
//         ),
//     'show_ui' => true,
//     'show_in_rest' => true,
//     'show_admin_column' => true,
//     ));
//     register_taxonomy('categories','img_gallery',array(
//         'hierarchical' => false,
//         'labels' => array(
//             'name' => _x( 'Categories', 'taxonomy general name' ),
//             'singular_name' => _x( 'Category', 'taxonomy singular name' ),
//             'menu_name' => __( 'Categories' ),
//             'all_items' => __( 'All Categories' ),
//             'edit_item' => __( 'Edit Category' ), 
//             'update_item' => __( 'Update Category' ),
//             'add_new_item' => __( 'Add Category' ),
//             'new_item_name' => __( 'New Category' ),
//         ),
//     'show_ui' => true,
//     'show_in_rest' => true,
//     'show_admin_column' => true,
//     ));
// }
// add_action( 'init', 'create_img_gallery_taxonomy', 0 );


// function create_Standard_gallery_taxonomy() 
// {
//     register_taxonomy('cuisines','image_gallery',array(
//         'hierarchical' => false,
//         'labels' => array(
//             'name' => _x( 'Cuisines', 'taxonomy general name' ),
//             'singular_name' => _x( 'Cuisine', 'taxonomy singular name' ),
//             'menu_name' => __( 'Cuisines' ),
//             'all_items' => __( 'All Cuisines' ),
//             'edit_item' => __( 'Edit Cuisine' ), 
//             'update_item' => __( 'Update Cuisine' ),
//             'add_new_item' => __( 'Add Cuisine' ),
//             'new_item_name' => __( 'New Cuisine' ),
//         ),
//     'show_ui' => true,
//     'show_in_rest' => true,
//     'show_admin_column' => true,
//     ));
//     register_taxonomy('ingredients','image_gallery',array(
//         'hierarchical' => false,
//         'labels' => array(
//             'name' => _x( 'Ingredients', 'taxonomy general name' ),
//             'singular_name' => _x( 'Ingredient', 'taxonomy singular name' ),
//             'menu_name' => __( 'Ingredients' ),
//             'all_items' => __( 'All Ingredients' ),
//             'edit_item' => __( 'Edit Ingredient' ), 
//             'update_item' => __( 'Update Ingredient' ),
//             'add_new_item' => __( 'Add Ingredient' ),
//             'new_item_name' => __( 'New Ingredient' ),
//         ),
//     'show_ui' => true,
//     'show_in_rest' => true,
//     'show_admin_column' => true,
//     ));
// }

// require_once plugin_dir_path(__FILE__) . 'public/partials/image_gallery-public-display.php';

/************ custom post type ***************/
function img_gallery_post_type() 
{
    register_post_type( 'image_gallery',
        array(
            'labels' => array(
                'name' => __( 'Image Gallery' ),
                'singular_name' => __( 'image_gallery' )
            ),
            'public' => true,
            'show_in_rest' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'has_archive' => true,
        'rewrite'   => array( 'slug' => 'image_gallery'), 
        'menu_position' => 5,
        'menu_icon' => 'dashicons-format-gallery',
        //'taxonomies' => array('tags', 'post_tag', 'category') // this is IMPORTANT
        )
    );
}
add_action( 'init', 'img_gallery_post_type');

function coupon_register_submenu_page() 
{  
    add_submenu_page('edit.php?post_type=image_gallery', 'Gallery Settings', 'Gallery Settings', "manage_options", 'gallery_configuration', 'galleryconfiguration', 10);
}
add_action('admin_menu', 'coupon_register_submenu_page');


function galleryconfiguration()
{
	require plugin_dir_path(__FILE__) . 'admin/partials/image_gallery-admin-display.php';
}

function run_image_gallery() 
{
	$plugin = new Image_gallery();
	$plugin->run();
}

run_image_gallery();


/*************** gallery img shortcode ************************/
add_shortcode('gallery_images', 'gallery_img_shortcode');
function gallery_img_shortcode()
{
    ob_start();
    require_once plugin_dir_path(__FILE__) . 'public/partials/image_gallery-public-display.php';
    return ob_get_clean();
}





        





