<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://techytrion.com/
 * @since      1.0.0
 *
 * @package    Image_gallery
 * @subpackage Image_gallery/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Image_gallery
 * @subpackage Image_gallery/includes
 * @author     Techytrion <testingemailer1212@gmail.com>
 */
class Image_gallery_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
